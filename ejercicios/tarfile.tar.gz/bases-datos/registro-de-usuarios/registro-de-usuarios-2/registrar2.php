<?php
/**
 * Registro de usuarios 2 - registrar2.php
 *
 * @author    BartolomÃ© Sintes Marco <bartolome.sintes+mclibre@gmail.com>
 * @copyright 2013 BartolomÃ© Sintes Marco
 * @license   http://www.gnu.org/licenses/agpl.txt AGPL 3 or later
 * @version   2013-03-10
 * @link      http://www.mclibre.org
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

require_once "biblioteca.php";
session_start();
if (isset($_SESSION['id'])) {
    header("Location:index.php");
    exit();
} else {

    $db = conectaDb();

    $usuario   = recoge("usuario");
    $password  = recoge("password");
    $password2 = recoge("password2");

    if (!$usuario) {
        header("Location:registrar1.php?aviso=Error: Nombre de usuario no permitido");
        exit();
    } elseif ($password != $password2) {
        header("Location:registrar1.php?aviso=Error: Las contraseÃ±as no coinciden");
        exit();
    } else {
        $consulta = "SELECT COUNT(*) FROM $dbUsuarios
            WHERE usuario='$usuario'";
        $result = $db->query($consulta);
        if (!$result) {
            cabecera("Registrar nuevo usuario 2", MENU_VOLVER, CABECERA_SIN_CURSOR);
            print "<p>Error en la consulta.</p>";
        } elseif ($result->fetchColumn() != 0) {
            header("Location:registrar1.php?aviso=Error: El nombre de usuario ya estÃ¡ registrado");
            exit();
        } else {
            $consulta = "SELECT COUNT(*) FROM $dbUsuarios";
            $result = $db->query($consulta);
            if (!$result) {
                cabecera("Registrar nuevo usuario 2", MENU_VOLVER, CABECERA_SIN_CURSOR);
                print "<p>Error en la consulta.</p>";
            } elseif ($result->fetchColumn() >= MAX_REG_USUARIOS) {
                header("Location:registrar1.php?aviso=Error: Se ha alcanzado el nÃºmero mÃ¡ximo de usuarios");
                exit();
            } else {
                $consulta = "INSERT INTO $dbUsuarios
                    VALUES (NULL, '$usuario', '" . md5($password) . "')";
                if (!$db->query($consulta)) {
                    cabecera("Registrar nuevo usuario 2", MENU_VOLVER, CABECERA_SIN_CURSOR);
                    print "<p>Error al crear el registro.<p>\n";
                } else {
                    cabecera("Registrar nuevo usuario 2", MENU_VOLVER, CABECERA_SIN_CURSOR);
                    print "  <p>Bienvenido/a, <strong>$usuario</strong>. Se ha "
                        . "registrado su nombre y contraseÃ±a..</p>\n";
                    print "  <p>Vuelva a la pÃ¡gina de inicio.</p>\n";
                }
            }
            $db = null;
            pie();
        }
    }
}
?>
