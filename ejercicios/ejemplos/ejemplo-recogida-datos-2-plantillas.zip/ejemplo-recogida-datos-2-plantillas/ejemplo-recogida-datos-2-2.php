﻿<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>Ejemplo de recogida y comprobación de datos (Resultado). Ejemplo de ejercicio.
  Escribe tu nombre</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link href="mclibre-php-soluciones.css" rel="stylesheet" type="text/css" title="Color" />
</head>

<body>
  <h1>Ejemplo de recogida y comprobación de datos (Resultado)</h1>

<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
  <p><a href="ejemplo-recogida-datos-2-1.php">Volver al formulario.</a></p>

    <footer>
      <p>Escribe tu nombre</p>
    </footer>
  </body>
  </html>