<?php
header("location:misterio_1.php");
print "output_buffering=" . ini_get("output_buffering");
print "<p>Estoy en A</p>\n";
print "<p><a href=\"misterio_1.php\">Volver a UNO</a></p>";
?>