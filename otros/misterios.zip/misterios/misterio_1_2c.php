﻿<?php
ini_set("output_buffering", 0);
header("location:misterio_1.php");
print "output_buffering=" . ini_get("output_buffering");
print "<p>Estoy en DOS C</p>\n";
print "<p>Este archivo UTF-8 sí tiene BOM</p>\n";
print "<p><a href=\"misterio_1.php\">Volver a UNO</a></p>";
?>