<?php
print "<p><a href=\"misterio_1_2a.php\">Ir a A</a></p>";
print "<p><a href=\"misterio_1_2b.php\">Ir a B</a></p>";
// exit();
print "<p><a href=\"misterio_1_2c.php\">Ir a C</a></p>";
print "<p><a href=\"misterio_1_2d.php\">Ir a D</a></p>";
?>
