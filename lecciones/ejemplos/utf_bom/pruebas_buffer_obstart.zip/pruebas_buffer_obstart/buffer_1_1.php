<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8" />
    <title>Buffer y redirecciones</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  </head>

  <body>
    <p><a href="buffer_1_2.php">Probar programa</a></p>
  </body>
</html>