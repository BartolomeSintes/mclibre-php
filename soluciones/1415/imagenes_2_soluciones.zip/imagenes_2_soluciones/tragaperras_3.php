<?php
/**
 * Im�genes - tragaperras_2.php
 *
 * @author    Bartolom� Sintes Marco <bartolome.sintes+mclibre@gmail.com>
 * @copyright 2014 Bartolom� Sintes Marco
 * @license   http://www.gnu.org/licenses/agpl.txt AGPL 3 or later
 * @version   2014-10-28
 * @link      http://www.mclibre.org
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

print "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>\n";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
       "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Tragaperras 3. Im�genes. Ejercicios. PHP. Bartolom� Sintes Marco</title>
<link href="mclibre_php_soluciones.css" rel="stylesheet" type="text/css"
  title="Color" />
</head>
<body>

<h1>Tragaperras (3)</h1>

<?php
// Funciones auxiliares
function recoge($var)
{
    $tmp = (isset($_REQUEST[$var]))
    ? trim(htmlspecialchars($_REQUEST[$var], ENT_QUOTES, "ISO-8859-1"))
    : "";
    return $tmp;
}

// Recogida de datos
$apuesta = recoge("apuesta");   // Cantidad apostada
$moneda  = recoge("moneda");    // Se ha insertado una moneda
$jugar   = recoge("jugar");     // Se juega
$a       = recoge("a");         // Imagen 1
$b       = recoge("b");         // Imagen 2
$c       = recoge("c");         // Imagen 3

$simbolosNumero = 6;   // N�mero de ficheros de im�genes distintas

// Validaci�n de datos recibidos

// Si no llega una cantidad apostada correcta, la cantidad ser� 0
if ($apuesta == "" || !is_numeric($apuesta) || !ctype_digit($apuesta)
    || $apuesta < 0) {
    $apuesta = 0;
}

// Se comprueba que las im�genes que han llegado son valores entre 1 y $simbolosNumero
$abcOk = true;
if ($a == "" || !is_numeric($a) || !ctype_digit($a) || $a < 1 || $a > $simbolosNumero ||
    $b == "" || !is_numeric($b) || !ctype_digit($b) || $b < 1 || $b > $simbolosNumero ||
    $c == "" || !is_numeric($c) || !ctype_digit($c) || $c < 1 || $c > $simbolosNumero) {
    $abcOk = false;
}
// Si no han llegado im�genes (por ejemplo, la primera vez que se llama el programa),
// se genera una combinaci�n nueva
if (!$abcOk) {
    $a = rand(1, $simbolosNumero);
    $b = rand(1, $simbolosNumero);
    $c = rand(1, $simbolosNumero);
}

// Cuerpo del programa

// Si se ha insertado moneda, se aumenta la cantidad apostada
if ($moneda != "") {
    $apuesta += 1;
}

// Si se ha jugado, se genera una combinaci�n nueva
if ($jugar != "") {
    $a = rand(1, $simbolosNumero);
    $b = rand(1, $simbolosNumero);
    $c = rand(1, $simbolosNumero);
}

// Si se ha jugado, se pierde todo
if ($jugar != "") {
    $apuesta = 0;
}

// Se genera el formulario
print "<form action=\"$_SERVER[PHP_SELF]\" method=\"get\">\n\n";

print "<table style=\"margin-left: auto; margin-right: auto; border: black 4px solid; border-spacing: 10px;\">\n";
print "  <tbody>\n";
print "    <tr>\n";
// Se muestran las tres im�genes de la combinaci�n actual
print "      <td style=\"border: black 4px solid; padding: 10px\">"
    . "<img src=\"img/tragaperras/$a.svg\" width=\"160\" alt=\"Imagen\" /></td>\n";
print "      <td style=\"border: black 4px solid; padding: 10px\">"
    . "<img src=\"img/tragaperras/$b.svg\" width=\"160\" alt=\"Imagen\" /></td>\n";
print "      <td style=\"border: black 4px solid; padding: 10px\">"
    . "<img src=\"img/tragaperras/$c.svg\" width=\"160\" alt=\"Imagen\" /></td>\n";
print "      <td style=\"vertical-align: top; text-align: center\">\n";
// Se muestra la cantidad actual apostada
print "        <p style=\"margin: 0; font-size: 300%; border: black 4px solid; padding: 2px\">$apuesta</p>\n";
print "        <p><input type=\"submit\" name=\"moneda\" value=\"Meter moneda\" /></p>\n";
print "        <p><input type=\"submit\" name=\"jugar\" value=\"Jugar\" /></p>\n";
print "      </td>\n";
print "    </tr>\n";
print "  </tbody>\n";
print "</table>\n\n";

// Controles ocultos: la apuesta y la combinaci�n actual
print "<p><input type=\"hidden\" name=\"apuesta\" value=\"$apuesta\" />\n";
print "  <input type=\"hidden\" name=\"a\" value=\"$a\" />\n";
print "  <input type=\"hidden\" name=\"b\" value=\"$b\" />\n";
print "  <input type=\"hidden\" name=\"c\" value=\"$c\" /></p>\n\n";
print "</form>\n";
?>

<p class="ultmod">�ltima modificaci�n de esta p�gina: 28 de octubre de 2014</p>

<p class="licencia">
Este programa forma parte del curso <strong><span xmlns:dct="http://purl.org/dc/terms/" 
xmlns:property="dct:title">P�ginas web con PHP</span></strong> por
<a xmlns:cc="http://creativecommons.org/ns#" href="http://www.mclibre.org/"
rel="cc:attributionURL">Bartolom� Sintes Marco</a>.<br />
El programa PHP que genera esta p�gina est� bajo
<a rel="license" href="http://www.gnu.org/licenses/agpl.txt">licencia AGPL 3 o
posterior</a></p>
</body>
</html>