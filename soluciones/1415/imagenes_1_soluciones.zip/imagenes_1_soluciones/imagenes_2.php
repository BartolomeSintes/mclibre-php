<?php
/**
 * Im�genes - imagenes_2.php
 *
 * @author    Bartolom� Sintes Marco <bartolome.sintes+mclibre@gmail.com>
 * @copyright 2014 Bartolom� Sintes Marco
 * @license   http://www.gnu.org/licenses/agpl.txt AGPL 3 or later
 * @version   2014-11-01
 * @link      http://www.mclibre.org
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

print "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>\n";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
       "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
  <title>Im�genes 2. Im�genes. 
  Ejercicios. PHP. Bartolom� Sintes Marco</title>
  <link href="mclibre_php_soluciones.css" rel="stylesheet" type="text/css"
  title="Color" />
</head>
<body>

<h1>Pieter Bruegel el viejo</h1>

<?php
// Funciones auxiliares
function recoge($var)
{
    $tmp = (isset($_REQUEST[$var]))
        ? trim(htmlspecialchars($_REQUEST[$var], ENT_QUOTES, "ISO-8859-1"))
        : "";
    return $tmp;
}

// Recogida de datos
$cuadro             = recoge("cuadro");
$detalle            = recoge("detalle");

// Variables auxiliares
$valorMinimoDetalle = 1;
$valorMaximoDetalle = 5;
$valorMinimoCuadro  = 1;
$valorMaximoCuadro  = 3;

// Validaci�n de datos recibidos

// Si no llega n�mero de cuadro, se mostrar� el primero
if ($cuadro == "" || !is_numeric($cuadro) || !ctype_digit($cuadro)) {
    $cuadro = $valorMinimoCuadro;
// Si el n�mero de cuadro es inferior al 1, se mostrar� la primera imagen
} elseif ($cuadro < $valorMinimoCuadro) {
    $cuadro = $valorMinimoCuadro;
// Si el n�mero de cuadro es superior a 3, se mostrar� la �ltima imagen
} else if($cuadro > $valorMaximoCuadro) {
    $cuadro = $valorMaximoCuadro;
}        

// Si no llega n�mero de detalle, se mostrar� el primero
if ($detalle == "" || !is_numeric($detalle) || !ctype_digit($detalle)) {
    $detalle = $valorMinimoDetalle;
// Si el n�mero de detalle es inferior al 1, se mostrar� la primera imagen
} elseif ($detalle < $valorMinimoDetalle) {
    $detalle = $valorMinimoDetalle;
// Si el n�mero de detalle es superior a 5, se mostrar� la �ltima imagen
} else if($detalle > $valorMaximoDetalle) {
    $detalle = $valorMaximoDetalle;
}        

// Cuerpo del programa

// Se genera el formulario del cuadro
print "<form action=\"$_SERVER[PHP_SELF]\" method=\"get\">\n";
print "<table style=\"margin-left: auto; margin-right: auto\">\n";
print "  <tbody>\n";
print "    <tr>\n";
print "      <td><button type=\"submit\" name=\"cuadro\" value=\""
    . ($cuadro - 1)."\"><img src=\"img/arrow-left-b.svg\" "
    . "height=\"80\" alt=\"anterior\" /></button></td>\n";
print "      <td><img src=\"img/bruegel/bruegel_$cuadro.jpg\" "
    . "alt=\"Cuadro de Pieter Bruegel el viejo\" /></td>\n";
print "      <td><button type=\"submit\" name=\"cuadro\" value=\""
    . ($cuadro + 1)."\"><img src=\"img/arrow-right-b.svg\" height=\"80\" " 
    . "alt=\"siguiente\" /></button></td>\n";
print "    </tr>\n";
print "  </tbody>\n";
print "</table>\n";
print "</form>\n\n";

// Se genera el formulario del detalle del cuadro
print "<form action=\"$_SERVER[PHP_SELF]\" method=\"get\">\n";
print "<table style=\"margin-left: auto; margin-right: auto\">\n";
print "  <tbody>\n";
print "    <tr>\n";
print "      <td><button type=\"submit\" name=\"detalle\" value=\""
    . ($detalle - 1)."\"><img src=\"img/arrow-left-b.svg\" "
    . "height=\"80\" alt=\"anterior\" /></button></td>\n";
// $cuadro debe ponerse entre llaves (o sacarse de la cadena). Si no se ponen, 
// PHP piensa que la variable se llama $cuadro_ y genera un aviso
print "      <td><img src=\"img/bruegel/bruegel_{$cuadro}_$detalle.jpg\" "
    . "alt=\"Detalle\" /></td>\n";
print "      <td><button type=\"submit\" name=\"detalle\" value=\""
    . ($detalle + 1)."\"><img src=\"img/arrow-right-b.svg\" height=\"80\" "
    . "alt=\"siguiente\" /></button></td>\n";
print "    </tr>\n";
print "  </tbody>\n";
print "</table>\n";
// El n�mero de cuadro se env�a en un control oculto
print "<p><input type=\"hidden\" name=\"cuadro\" value=\"$cuadro\" /></p>\n";
print "</form>\n";

?>

<p class="ultmod">�ltima modificaci�n de esta p�gina: 1 de noviembre de 2014</p>

<p class="licencia">
Este programa forma parte del curso <strong><span xmlns:dct="http://purl.org/dc/terms/" 
xmlns:property="dct:title">P�ginas web con PHP</span></strong> por
<a xmlns:cc="http://creativecommons.org/ns#" href="http://www.mclibre.org/"
rel="cc:attributionURL">Bartolom� Sintes Marco</a>.<br />
El programa PHP que genera esta p�gina est� bajo
<a rel="license" href="http://www.gnu.org/licenses/agpl.txt">licencia AGPL 3 o
posterior</a></p>
</body>
</html>
