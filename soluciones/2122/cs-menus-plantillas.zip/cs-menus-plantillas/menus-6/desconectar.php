<?php
/**
 * Menús 6 - desconectar.php
 *
 * @author Escriba aquí su nombre
 *
 */

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";
