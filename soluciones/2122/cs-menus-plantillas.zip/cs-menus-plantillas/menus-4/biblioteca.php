<?php
/**
 * Menús 4 - biblioteca.php
 *
 * @author Escriba aquí su nombre
 *
 */

 // Ejercicio incompleto

function cabecera($texto)
{
    print "<!DOCTYPE html>\n";
    print "<html lang=\"es\">\n";
    print "<head>\n";
    print "  <meta charset=\"utf-8\">\n";
    print "  <title>\n";

    print "    Ejercicio incompleto.\n";

    print "    Menús 4. Menús.\n";
    print "    Escriba aquí su nombre\n";
    print "  </title>\n";
    print "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n";
    print "  <link rel=\"stylesheet\" href=\"mclibre-php-proyectos.css\" title=\"Color\">\n";
    print "</head>\n";
    print "\n";
    print "<body>\n";
    print "  <header>\n";

    print "    <p class=\"aviso\">Ejercicio incompleto</p>\n";

    print "\n";
    print "    <nav>\n";
    print "      <ul>\n";

    print "        <li>Ejercicio incompleto</li>\n";

    print "      </ul>\n";
    print "    </nav>\n";
    print "  </header>\n";
    print "\n";
    print "  <main>\n";
}

function pie()
{
    print "  </main>\n";
    print "\n";
    print "  <footer>\n";
    print "    <p>Escriba aquí su nombre</p>\n";
    print "  </footer>\n";
    print "</body>\n";
    print "</html>";
}
