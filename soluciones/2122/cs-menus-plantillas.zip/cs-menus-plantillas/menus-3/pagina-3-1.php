<?php
/**
 * Menús 3 - pagina-3-1.php
 *
 * @author Escriba aquí su nombre
 *
 */

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";
