<?php
/**
 * @author Escriba aquí su nombre
 */


require_once "biblioteca.php";

cabecera("Inicio", MENU_PRINCIPAL);

pie();
