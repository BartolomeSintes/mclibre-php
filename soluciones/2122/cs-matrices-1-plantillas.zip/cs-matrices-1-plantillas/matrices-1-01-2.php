<?php
/**
 * Sesiones Matrices (1) 1 - matrices-1-01-2.php
 *
 * @author Escriba aquí su nombre
 *
 */

print "    <p class=\"aviso\">Ejercicio incompleto</p>\n";
