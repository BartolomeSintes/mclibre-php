<?php
/**
 * Memorión (1) - memorion-1-1.php
 *
 * @author Escriba aquí su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Memoríón (1).
    Memorión. Sesiones.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Memorión (1)</h1>

  <form action="memorion-1-2.php">
    <p>
      <button type="submit" name="accion" value="nueva">Nueva partida</button>
    </p>

    <p style="font-size: 400%;">
<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
    </p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
