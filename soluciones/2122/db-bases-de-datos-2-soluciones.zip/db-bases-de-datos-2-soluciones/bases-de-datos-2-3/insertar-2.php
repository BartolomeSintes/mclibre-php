<?php
/**
 * @author    Bartolomé Sintes Marco - bartolome.sintes+mclibre@gmail.com
 * @license   https://www.gnu.org/licenses/agpl-3.0.txt AGPL 3 or later
 * @link      https://www.mclibre.org
 */

require_once "biblioteca.php";

$pdo = conectaDb();

cabecera("Añadir 2", MENU_VOLVER);

$nombre    = recoge("nombre");
$apellidos = recoge("apellidos");
$telefono  = recoge("telefono");
$correo    = recoge("correo");

$nombreOk    = false;
$apellidosOk = false;
$telefonoOk  = false;
$correoOk    = false;

if (mb_strlen($nombre, "UTF-8") > $cfg["dbPersonasTamNombre"]) {
    print "    <p class=\"aviso\">El nombre no puede tener más de $cfg[dbPersonasTamNombre] caracteres.</p>\n";
    print "\n";
} else {
    $nombreOk = true;
}

if (mb_strlen($apellidos, "UTF-8") > $cfg["dbPersonasTamApellidos"]) {
    print "    <p class=\"aviso\">Los apellidos no pueden tener más de $cfg[dbPersonasTamApellidos] caracteres.</p>\n";
    print "\n";
} else {
    $apellidosOk = true;
}

if (mb_strlen($telefono, "UTF-8") > $cfg["dbPersonasTamTelefono"]) {
    print "    <p class=\"aviso\">El teléfono no puede tener más de $cfg[dbPersonasTamTelefono] caracteres.</p>\n";
    print "\n";
} else {
    $telefonoOk = true;
}

if (mb_strlen($correo, "UTF-8") > $cfg["dbPersonasTamCorreo"] ) {
    print "    <p class=\"aviso\">El correo no puede tener más de $cfg[dbPersonasTamCorreo]  caracteres.</p>\n";
    print "\n";
} else {
    $correoOk = true;
}

if ($nombreOk && $apellidosOk && $telefonoOk && $correoOk) {
    if ($nombre == "" && $apellidos == "" && $telefono == "" && $correo == "") {
        print "    <p class=\"aviso\">Hay que rellenar al menos uno de los campos. No se ha guardado el registro.</p>\n";
    } else {
        $consulta  = "SELECT COUNT(*) FROM $cfg[dbPersonasTabla]";
        $resultado = $pdo->query($consulta);

        if (!$resultado) {
            print "    <p class=\"aviso\">Error en la consulta.</p>\n";
        } elseif ($resultado->fetchColumn() >= $cfg["dbPersonasmaxReg"]) {
            print "    <p class=\"aviso\">Se ha alcanzado el número máximo de registros que se pueden guardar.</p>\n";
            print "\n";
            print "    <p class=\"aviso\">Por favor, borre algún registro antes de insertar un nuevo registro.</p>\n";
        } else {
            $consulta = "SELECT COUNT(*) FROM $cfg[dbPersonasTabla]
                         WHERE nombre=:nombre
                         AND apellidos LIKE :apellidos
                         AND telefono LIKE :telefono
                         AND correo LIKE :correo";
            $resultado = $pdo->prepare($consulta);
            $resultado->execute([":nombre" => "$nombre", ":apellidos" => "$apellidos", ":telefono" => "$telefono", ":correo" => "$correo"]);

            if (!$resultado) {
                print "    <p class=\"aviso\">Error en la consulta.</p>\n";
            } elseif ($resultado->fetchColumn() > 0) {
                print "    <p class=\"aviso\">El registro ya existe.</p>\n";
            } else {
                $consulta = "INSERT INTO $cfg[dbPersonasTabla]
                             (nombre, apellidos, telefono, correo)
                             VALUES (:nombre, :apellidos, :telefono, :correo)";
                $resultado = $pdo->prepare($consulta);

                if (!$resultado->execute([":nombre" => "$nombre", ":apellidos" => "$apellidos", ":telefono" => "$telefono", ":correo" => "$correo"])) {
                    print "    <p class=\"aviso\">Error al crear el registro / {$pdo->errorInfo()[2]}</p>\n";
                } else {
                    print "    <p>Registro creado correctamente.</p>\n";
                }
            }
        }
    }
}

$pdo = null;

pie();
