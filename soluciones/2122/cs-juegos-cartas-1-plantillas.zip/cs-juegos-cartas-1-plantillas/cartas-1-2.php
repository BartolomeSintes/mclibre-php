<?php
/**
 *
 * @author Escriba aquí su nombre
 */

print "<p>Ejercicio incompleto</p>\n";

?>
