<?php
/**
 *
 * @author Escriba aquí su nombre
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Distribuye cartas.
    Juegos de cartas (1). Sesiones.
    Ejercicios. PHP. Bartolomé Sintes Marco. www.mclibre.org
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Distribuye cartas</h1>

  <form action="cartas-1-2.php" method="get">
    <p>Haga clic en los botones para añadir la carta a uno de los montones:</p>
<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

    <p><input type="submit" name="accion" value="reiniciar"></p>

  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
