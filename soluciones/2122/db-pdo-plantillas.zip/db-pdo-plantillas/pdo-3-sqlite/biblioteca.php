<?php
/**
 *
 * @author Escriba aquí su nombre
 */

// SQLITE: FUNCIÓN DE CONEXIÓN CON LA BASE DE DATOS

function conectaDb()
{
}

// FUNCIÓN DE BORRADO DE TABLA

function borraTabla()
{
}

// SQLITE: FUNCIÓN DE CREACIÓN DE TABLA

function creaTabla()
{
}

// FUNCIÓN DE INSERCIÓN DE REGISTRO

function insertaRegistro($nombre, $apellidos)
{
}

// FUNCIÓN DE CONTEO DE REGISTROS

function cuentaRegistros()
{
}

// FUNCIÓN DE SELECCIÓN DE TODOS LOS REGISTROS

function muestraRegistros()
{
}

// FUNCIÓN DE MODIFICACIÓN DE REGISTRO

function modificaRegistro($id, $nombre, $apellidos)
{
}

// FUNCIÓN DE BORRADO DE REGISTROS

function borraRegistros($id)
{
}
