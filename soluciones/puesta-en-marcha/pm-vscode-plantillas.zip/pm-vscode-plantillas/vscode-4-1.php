﻿<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>BOM y redirecciones</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>

<body>
  <p>Esta es la página 1.</p>

  <p><a href="vscode-4-2.php">Enlace a la página 2 (que redirige a la página 3)</a></p>
</body>
</html>
