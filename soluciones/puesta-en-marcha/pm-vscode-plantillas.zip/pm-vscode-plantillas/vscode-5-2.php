<?php

print "<!DOCTYPE html>\n";
print "<html lang=\"es\">\n";
print "<head>\n";
print "  <meta charset=\"utf-8\">\n";
print "  <title>Visual Studio Code 5. Puesta en marcha</title>\n";
print "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n";
print "  <link rel=\"stylesheet\" href=\"vscode-1.css\">\n";
print "</head>\n";
print "\n";
print "<body>\n";
print "  Puesta en marcha. Visual Studio Code 5\n";
print "\n";
print "  <p>Esta página web es una página HTML válida.\n";
print "</body>\n";
print "</html>\n";
print "\n";
