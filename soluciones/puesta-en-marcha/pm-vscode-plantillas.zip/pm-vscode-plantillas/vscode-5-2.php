﻿<?php
header("Location:vscode-5-3.php");
?>
<p>Esta es la página 2.</p>

<p>Si ve esta página es que tiene la configuración recomendada para desarrollo recomendada en estos apuntes.</p>

<p>Debe ver un aviso <strong>Warning</strong> al principio de esta página.</p>

<p><a href="vscode-5-1.php">Volver al principio</a></p>
