<?php
print "<!DOCTYPE html>
<html lang=\"es\">

<body>
  <p>Esta página es una página HTML 5 válida.</p>
</body>
</html>\n";

?>
