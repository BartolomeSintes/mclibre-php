<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Visual Studio Code 6. Puesta en marcha</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="vscode-1.css">
</head>

<body>
  Puesta en marcha. Visual Studio Code 6

  Esta página web es una página HTML válida.
</body>
</html>
