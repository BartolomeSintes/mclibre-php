<?php
// Ejercicio incompleto
