<?php

print "<p>¡Funciona!</p>\n";
