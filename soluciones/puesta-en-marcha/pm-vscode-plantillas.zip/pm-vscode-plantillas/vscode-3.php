<?php
function test($a = [], $b) {}
