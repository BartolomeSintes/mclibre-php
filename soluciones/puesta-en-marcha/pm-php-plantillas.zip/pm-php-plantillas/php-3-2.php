<p>Esta es la página 2.</p>

<?php
header("Location:php-3-3.php");
?>

<p>Si ve esta página es que <strong>SÍ</strong> tiene la configuración de la directiva <strong>output_buffering</strong> en php.ini recomendada en estos apuntes para desarrollo.</p>

<p>Debe ver un aviso <strong>Warning</strong> tras el primer párrafo de esta página.</p>

<p><a href="php-3-1.php">Volver al principio</a></p>
