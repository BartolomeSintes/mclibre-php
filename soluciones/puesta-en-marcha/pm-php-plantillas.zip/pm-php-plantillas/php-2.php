<?php
function siguiente($a = 1, $b) { return $a + $b; }
