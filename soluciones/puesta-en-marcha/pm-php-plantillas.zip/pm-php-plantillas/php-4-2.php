﻿<?php
header("Location:php-4-3.php");
?>
<p>Esta es la página 2.</p>

<p>Si no cambia el juego de caracteres de esta página, verá esta página aunque tenga la configuración recomendada en estos apuntes para desarrollo.</p>

<p>Debe ver un aviso <strong>Warning</strong> al principio de esta página.</p>

<p><a href="php-4-1.php">Volver al principio</a></p>
