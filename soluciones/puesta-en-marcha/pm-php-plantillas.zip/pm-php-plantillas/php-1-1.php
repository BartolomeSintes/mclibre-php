<?php

// El código fuente de un programa no debería verse en el navegador
// porque al navegador se le envía la salida del programa
// normalmente generada por instrucciones print.
// Si se ve el código fuente del programa quiere decir que el
// programa no se ha ejecutado en el servidor.

print "<p>Hola</p>";
