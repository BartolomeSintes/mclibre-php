<?php

// print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Nombre (1). Sesiones 2. Sesiones.
    Ejercicios. PHP. Bartolomé Sintes Marco. www.mclibre.org</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
<h1>Nombre (1)</h1>

<?php

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

<form action="nombre_2.php" method="get">
  <fieldset>
    <legend>Formulario</legend>

    <p>Escriba su nombre:</p>

    <p><strong>Nombre:</strong> <input type="text" name="nombre" size="20" maxlength="20"></p>

    <p><input type="submit" value="Guardar">
      <input type="reset" value="Borrar"></p>
  </fieldset>
</form>

<p><a href="index.html">Volver al inicio.</a></p>

<footer>
  <p class="ultmod">
    Última modificación de esta página:
    <time datetime="2015-11-15">15 de noviembre de 2015</time></p>
</footer>
</body>
</html>