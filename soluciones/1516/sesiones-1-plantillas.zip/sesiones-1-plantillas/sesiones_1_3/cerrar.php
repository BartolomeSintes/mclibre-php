<?php

print "<!-- Ejercicio incompleto -->\n";

?>