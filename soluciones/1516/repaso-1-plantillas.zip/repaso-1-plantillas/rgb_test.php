<?php

// print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>RGB Test. Repaso (1).
  Ejercicios. PHP. Bartolomé Sintes Marco. www.mclibre.org</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
  <style>
    form span { font-size: 300%; display: block; width: 100px; height: 100px; }
  </style>
</head>

<body>
<h1>RGB Test</h1>

<?php

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

<footer>
  <p class="ultmod">
    Última modificación de esta página:
    <time datetime="2015-11-18">18 de noviembre de 2015</time></p>
</footer>
</body>
</html>
