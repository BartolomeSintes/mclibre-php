<?php
/**
 * Hombres y mujeres (Resultado 2) - foreach-1-4-3.php
 *
 * @author    Escriba su nombre
 *
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Hombres y mujeres (Resultado 2).
    foreach (1).
    Escriba su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Hombres y mujeres (Resultado 2)</h1>

<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>


  <p><a href="foreach-1-4-1.php">Volver al formulario inicial.</a></p>

  <footer>
    <p>Escriba su nombre</p>
  </footer>
</body>
</html>