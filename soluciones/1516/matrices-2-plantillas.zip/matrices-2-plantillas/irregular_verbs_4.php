<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>Irregular verbs 4. Matrices (2). 
    Ejercicios. Programación web en PHP. Bartolomé Sintes Marco</title>
  <link href="mclibre_php_soluciones.css" rel="stylesheet" type="text/css" title="Color" />
</head>

<body>
<h1>Irregular verbs 4</h1>

<form action="irregular_verbs_4.php" method="get">

<?php

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
        
  <p><input type="submit" value="Corregir" /> 
    <input type="reset" value="Borrar" name="Reset" /></p>
</form>

<p><a href="irregular_verbs_4.php"><button>Reiniciar</button></a></p>

<footer>
  <p class="ultmod">
    Última modificación de esta página: 
    <time datetime="2015-11-12">12 de noviembre de 2015</time></p>
</footer>
</body>
</html>