<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Irregular verbs 1 (Formulario). Matrices (2).
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Irregular verbs 1</h1>

<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
  <p><a href="irregular_verbs_1.php"><button>Mostrar otro</button></a></p>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>