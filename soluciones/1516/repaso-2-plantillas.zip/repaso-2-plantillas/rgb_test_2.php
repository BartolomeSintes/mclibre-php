<?php

// print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    RGB Test 2. Repaso (2).
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
  <style>
    form span { font-size: 300%; display: block; width: 100px; height: 100px; }
  </style>
</head>

<body>
<h1>RGB Test 2</h1>

<?php

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

<footer>
  <p>Escriba aquí su nombre</p>
</footer>
</body>
</html>