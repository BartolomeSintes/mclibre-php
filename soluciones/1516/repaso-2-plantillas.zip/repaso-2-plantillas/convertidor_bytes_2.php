<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>Convertidor de bytes 2 (Resultado). Repaso (2).
  Ejercicios. PHP. Bartolomé Sintes Marco</title>
  <link href="mclibre_php_soluciones.css" rel="stylesheet" type="text/css" title="Color" />
</head>

<body>
<h1>Convertidor de bytes 2 (Resultado)</h1>

<?php

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

<p><a href="convertidor_bytes_2.html">Volver al formulario.</a></p>

<footer>
  <p class="ultmod">
    Última modificación de esta página: 
    <time datetime="2015-11-18">18 de noviembre de 2015</time></p>
</footer>
</body>
</html>