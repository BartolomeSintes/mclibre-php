<?php

// print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>Borrar datos (1). Sesiones. 
    Ejercicios. PHP. Bartolomé Sintes Marco</title>
  <link href="mclibre_php_soluciones.css" rel="stylesheet" type="text/css"  title="Color" />
</head>

<body>
<h1>Borrar datos (1)</h1>

<?php

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

<form action="apellidos_2.php" method="get">
  <fieldset>
    <legend>Formulario</legend>

    <p>Escriba sus apellidos:</p>

    <p><strong>Apellidos:</strong> <input type="text" name="apellidos" size="30" maxlength="30" /></p>

    <p><input type="submit" value="Guardar" />
      <input type="reset" value="Borrar" /></p>
  </fieldset>
</form>

<p><a href="index.html">Volver al inicio.</a></p>

<footer>
  <p class="ultmod">
    Última modificación de esta página: 
    <time datetime="2015-11-15">15 de noviembre de 2015</time></p>
</footer>
</body>
</html>