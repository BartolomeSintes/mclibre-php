<?php

// print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>Nombre y apellidos (Inicio). Sesiones 3. Sesiones. 
    Ejercicios. PHP. Bartolomé Sintes Marco</title>
  <link href="mclibre_php_soluciones.css" rel="stylesheet" type="text/css" title="Color" />
</head>

<body>
<h1>Nombre y apellidos (Inicio)</h1>

<?php

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

<p>Elija una opción:</p>

<ul>
  <li><a href="nombre_1.php">Escribir su nombre</a></li>
  <li><a href="apellidos_1.php">Escribir sus apellidos</a></li>
  <li><a href="cerrar.php">Borrar la información</a></li>
</ul>

<footer>
  <p class="ultmod">
    Última modificación de esta página: 
    <time datetime="2015-11-15">15 de noviembre de 2015</time></p>
</footer>
</body>
</html>