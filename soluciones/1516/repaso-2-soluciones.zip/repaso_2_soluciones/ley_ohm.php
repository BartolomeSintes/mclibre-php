<?php
/**
 * Ley de Ohm - ley_ohm.php
 *
 * @author    Bartolomé Sintes Marco <bartolome.sintes+mclibre@gmail.com>
 * @copyright 2015 Bartolomé Sintes Marco
 * @license   http://www.gnu.org/licenses/agpl.txt AGPL 3 or later
 * @version   2015-11-18
 * @link      http://www.mclibre.org
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>Ley de Ohm (Formulario). Repaso (2)
  Ejercicios. PHP. Bartolomé Sintes Marco</title>
  <link href="mclibre_php_soluciones.css" rel="stylesheet" type="text/css" title="Color" />
</head>

<body>
<h1>Ley de Ohm (Resultado)</h1>

<?php
// Funciones auxiliares
function recoge($var)
{
    $tmp = (isset($_REQUEST[$var]))
        ? trim(htmlspecialchars($_REQUEST[$var], ENT_QUOTES, "UTF-8"))
        : "";
    return $tmp;
}

// Recogida de datos
$tension       = recoge("tension");
$intensidad    = recoge("intensidad");
$resistencia   = recoge("resistencia");
$tensionOk     = false;
$intensidadOk  = false;
$resistenciaOk = false;

// Comprobación de que hay al menos dos datos
if (($tension == "" && $intensidad == "") || ($tension == "" && $resistencia == "")
    || ($intensidad == "" && $resistencia == "")) {
    print "<p class=\"aviso\">Se necesitan al menos rellenar dos datos.</p>\n";
} else {
// Comprobación de $tension
if ($tension == "") {
        $tensionOk = true;
    } elseif (!is_numeric($tension)) {
        print "<p class=\"aviso\">No ha escrito la tensión como número.</p>\n";
    } else {
        $tensionOk = true;
    }

// Comprobación de $intensidad
    if ($intensidad == "") {
        $intensidadOk = true;
    } elseif (!is_numeric($intensidad)) {
        print "<p class=\"aviso\">No ha escrito la intensidad como número.</p>\n";
    } else {
        $intensidadOk = true;
    }

// Comprobación de $resistencia
    if ($resistencia == "") {
        $resistenciaOk = true;
    } elseif (!is_numeric($resistencia)) {
        print "<p class=\"aviso\">No ha escrito la resistencia como número.</p>\n";
    } elseif ($resistencia<0) {
        print "<p class=\"aviso\">La resistencia no puede ser negativa.</p>\n";
    } else {
        $resistenciaOk = true;
    }
}

// Si los valores recibidos son correctos ...
if ($tensionOk && $intensidadOk && $resistenciaOk) {
    if ($tension != "" && $intensidad != "" && $resistencia != "") {
        if ($tension == $intensidad * $resistencia) {
            print "<p>Los valores introducidos son correctos:</p>\n\n";
        } else {
            print "<p>Los valores introducidos <span class=\"aviso\">no</span> son posibles:</p>\n\n";
        }
        print "<ul>\n"
            . "  <li>Tensión: $tension V</li>\n"
        	. "  <li>Intensidad: $intensidad A</li>\n"
            . "  <li>Resistencia: $resistencia &Omega;</li>\n"
            . "</ul>\n\n";
    } elseif ($tension * $intensidad < 0) {
        print "<p class=\"aviso\">Tensión e intensidad no pueden tener signos distintos.</p>\n";
    } elseif ($tension != "" && $intensidad != "" && $tension == 0 && $intensidad==0) {
        print "<p class=\"aviso\">Si la tensión y la intensidad son nulas, la resistencia puede tomar cualquier valor.</p>\n";
    } elseif ($tension != "" && $resistencia != "" && $tension == 0 && $resistencia == 0) {
        print "<p class=\"aviso\">Si la tensión y la resistencia son nulas, la intensidad puede tomar cualquier valor.</p>\n";
    } elseif ($resistencia != "" && $tension != 0 && $resistencia == 0) {
        print "<p class=\"aviso\">Si la resistencia es nula, la tensión no puede ser no nula.</p>\n";
    } elseif ($intensidad != "" && $tension !=0 && $intensidad == 0) {
        print "<p class=\"aviso\">Si la intensidad es nula, la tensión no puede ser no nula.</p>\n";
    } else {
        print "<p>Valores calculados:</p>\n\n";
        if ($tension == "") {
            $tension = $resistencia * $intensidad;
        } elseif ($intensidad == "") {
            $intensidad = $tension / $resistencia;
        } else {
            $resistencia = $tension / $intensidad;
        }
        print "<ul>\n"
            . "  <li>Tensión: $tension V</li>\n"
            . "  <li>Intensidad: $intensidad A</li>\n"
            . "  <li>Resistencia: $resistencia &Omega;</li>\n"
            . "</ul>\n";
    }
}

?>

<p><a href="ley_ohm.html">Volver al formulario.</a></p>

<footer>
  <p class="ultmod">
    Última modificación de esta página: 
    <time datetime="2015-11-18">18 de noviembre de 2015</time></p>

  <p class="licencia">
    Este programa forma parte del curso <a href="http://www.mclibre.org/consultar/php/">
    <cite>Programación web en PHP</cite></a> por <cite>Bartolomé Sintes Marco</cite>.<br />
    El programa PHP que genera esta página está bajo
    <a rel="license" href="http://www.gnu.org/licenses/agpl.txt">licencia AGPL 3 o posterior</a></p>
</footer>
</body>
</html>