<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>Multiplicar 1 (Resultado). Minijuegos (1) 
    Ejercicios. Programación web en PHP. Bartolomé Sintes Marco</title>
  <link href="mclibre_php_soluciones.css" rel="stylesheet" type="text/css" title="Color" />
  <style type="text/css">table { text-align: right; }</style>
</head>

<body>
<h1>Multiplicar 1 (Resultado)</h1>

<?php

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

<p><a href="multiplicar_1_1.php">Volver al formulario.</a></p>

<footer>
  <p class="ultmod">
    Última modificación de esta página: 
    <time datetime="2015-10-27">27 de octubre de 2015</time></p>
</footer>
</body>
</html>