<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>Dividir 1 (Formulario). Minijuegos (1) 
    Ejercicios. Programación web en PHP. Bartolomé Sintes Marco</title>
  <link href="mclibre_php_soluciones.css" rel="stylesheet" type="text/css" title="Color" />
  <style type="text/css">input { text-align: right; }</style>
</head>

<body>
<h1>Dividir 1 (Formulario)</h1>

<form action="dividir_1_2.php" method="get">
  <p>Escriba el resultado de la siguiente división:</p>

<?php

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
        
  <p><input type="submit" value="Corregir" /> 
    <input type="reset" value="Borrar" name="Reset" /></p>
</form>

<footer>
  <p class="ultmod">
    Última modificación de esta página: 
    <time datetime="2015-10-27">27 de octubre de 2015</time></p>
</footer>
</body>
</html>