<?php
/**
 * Palabras repetidas (Resultado 1) - foreach-1-2-2.php
 *
 * @author    Escriba su nombre
 *
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Palabras repetidas (Resultado 1).
    foreach (1).
    Escriba su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Palabras repetidas (Resultado 1)</h1>

<?php
// Funciones auxiliares
function recoge($var)
{
    $tmp = (isset($_REQUEST[$var]))
        ? trim(htmlspecialchars($_REQUEST[$var], ENT_QUOTES, "UTF-8"))
        : "";
    return $tmp;
}

// Recogida de datos
$numero       = recoge("numero");
$numeroOk     = false;
$numeroMinimo = 1;
$numeroMaximo = 10;

// Comprobación de $numero (entero entre 1 y 20)
if ($numero == "") {
    print "  <p class=\"aviso\">No ha escrito el tamaño de la tabla.</p>\n";
} elseif (!ctype_digit($numero)) {
    print "  <p class=\"aviso\">No ha escrito el tamaño de la tabla "
        . "como número entero positivo.</p>\n";
} elseif ($numero < $numeroMinimo || $numero > $numeroMaximo) {
    print "  <p class=\"aviso\">El tamaño de la tabla debe estar entre "
        . "$numeroMinimo y $numeroMaximo.</p>\n";
} else {
    $numeroOk = true;
}

// Si el número recibido es correcto ...
if ($numeroOk) {
    // Formulario que envía los datos a la página 3
    print "  <p>Escriba una palabra en cada caja de texto y le diré si ha repetido alguna.</p>\n";
    print "\n";
    print "  <form action=\"foreach-1-2-3.php\" method=\"get\">\n";
    print "    <table>\n";
    print "      <tbody>\n";
    // Bucle para generar las cajas de texto
    for ($i = 1; $i <= $numero; $i++) {
        print "        <tr>\n";
        print "          <td>$i</td>\n";
        // El nombre del control es una matriz (c[])
        print "          <td><input type=\"text\" name=\"c[$i]\" size=\"30\"></td>\n";
        print "        </tr>\n";
    }
    print "      </tbody>\n";
    print "    </table>\n";
    print "\n";

    // Se añade un control oculto con el número recibido para que le llegue a la página 3
    print "    <p><input type=\"hidden\" name=\"numero\" value=\"$numero\"></p>\n";
    print "\n";

    print "    <p>\n";
    print "      <input type=\"submit\" value=\"Contar\">\n";
    print "      <input type=\"reset\" value=\"Borrar\">\n";
    print "    </p>\n";
    print "  </form>\n";
}
?>

  <p><a href="foreach-1-2-1.php">Volver al formulario.</a></p>

  <footer>
    <p>Escriba su nombre</p>
  </footer>
</body>
</html>