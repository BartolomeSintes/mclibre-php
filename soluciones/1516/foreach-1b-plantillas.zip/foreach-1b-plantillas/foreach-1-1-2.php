<?php
/**
 * Tabla con casillas de verificación (Resultado 1) - foreach-1-1-2.php
 *
 * @author    Escriba su nombre
 *
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Tabla de una fila con casillas de verificación (Resultado 1).
    foreach (1).
    Escriba su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Tabla de una fila con casillas de verificación (Resultado 1)</h1>

<?php
// Funciones auxiliares
function recoge($var)
{
    $tmp = (isset($_REQUEST[$var]))
        ? trim(htmlspecialchars($_REQUEST[$var], ENT_QUOTES, "UTF-8"))
        : "";
    return $tmp;
}

// Recogida de datos
$numero       = recoge("numero");
$numeroOk     = false;
$numeroMinimo = 1;
$numeroMaximo = 20;

// Comprobación de $numero (entero entre 1 y 20)
if ($numero == "") {
    print "  <p class=\"aviso\">No ha escrito el tamaño de la tabla.</p>\n";
} elseif (!ctype_digit($numero)) {
    print "  <p class=\"aviso\">No ha escrito el tamaño de la tabla "
        . "como número entero positivo.</p>\n";
} elseif ($numero < $numeroMinimo || $numero > $numeroMaximo) {
    print "  <p class=\"aviso\">El tamaño de la tabla debe estar entre "
        . "$numeroMinimo y $numeroMaximo.</p>\n";
} else {
    $numeroOk = true;
}

// Si el número recibido es correcto ...
if ($numeroOk) {
    print "  <p>Marque las casillas de verificación que quiera y contaré cuántas ha marcado.</p>\n";
    print "\n";

    // Formulario que envía los datos a la página 3
    print "  <form action=\"foreach-1-1-3.php\" method=\"get\">\n";
    print "    <table class=\"conborde\">\n";
    print "      <tbody>\n";
    print "        <tr>\n";
    // Bucle para generar las casillas de verificación
    for ($i = 1; $i <= $numero; $i++) {
        // El nombre del control es una matriz (c[])
        print "          <td><label><input type=\"checkbox\" name=\"c[$i]\"> $i</label></td>\n";
    }
    print "        </tr>\n";
    print "      </tbody>\n";
    print "    </table>\n";
    print "\n";

    // Se añade un control oculto con el número recibido para que le llegue a la página 3
    print "    <p><input type=\"hidden\" name=\"numero\" value=\"$numero\"></p>\n";
    print "\n";

    print "    <p>\n";
    print "      <input type=\"submit\" value=\"Contar\">\n";
    print "      <input type=\"reset\" value=\"Borrar\">\n";
    print "    </p>\n";
    print "  </form>\n";
}
?>

  <p><a href="foreach-1-1-1.php">Volver al formulario.</a></p>

  <footer>
    <p>Escriba su nombre</p>
  </footer>
</body>
</html>