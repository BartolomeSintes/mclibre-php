<?php

// print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>Almacenamiento de datos en sesión. Sesiones (2). 
    Ejercicios. PHP. Bartolomé Sintes Marco</title>
  <link href="mclibre_php_soluciones.css" rel="stylesheet" type="text/css" title="Color" />
</head>

<body>
<h1>Almacenamiento de datos en sesión</h1>

<form action="sesiones_2_2_2.php" method="get">
  <fieldset>
    <legend>Formulario</legend>
    
    <p>Escriba algún nombre: <input type="text" name="nombre" size="30" maxlength="30" /></p>

    <p><input type="submit" value="Añadir" /> 
      <input type="reset" value="Borrar" name="Reset" /></p>
  </fieldset>
</form>

<?php

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

<footer>
  <p class="ultmod">
    Última modificación de esta página: 
    <time datetime="2015-11-16">16 de noviembre de 2015</time></p>
</footer>
</body>
</html>