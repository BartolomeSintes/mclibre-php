<?php
/**
 * Matrices 1 - matrices_1.php
 *
 * @author    Bartolomé Sintes Marco <bartolome.sintes+mclibre@gmail.com>
 * @copyright 2015 Bartolomé Sintes Marco
 * @license   http://www.gnu.org/licenses/agpl.txt AGPL 3 or later
 * @version   2015-11-11
 * @link      http://www.mclibre.org
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>Matrices 1. Matrices (1) 
    Ejercicios. Programación web en PHP. Bartolomé Sintes Marco</title>
  <link href="mclibre_php_soluciones.css" rel="stylesheet" type="text/css" title="Color" />
</head>

<body>
<h1>Matrices 1</h1>

<?php
$numeroValores = rand(5, 15);

print "<h2>Datos iniciales</h2>\n\n";

print "<p>Número de valores en la matriz: $numeroValores</p>\n\n";

print "<p>Valores elegidos al azar entre 0 y 10.</p>\n\n";

// Crea la matriz inicial
$matriz = array();
for ($i = 0; $i < $numeroValores; $i++) {
    $matriz[] = rand(0, 10);
}    

print "<h2>Matriz de valores</h2>\n\n";

print "<pre>\n"; print_r($matriz); print "</pre>\n\n";

?>
        
<footer>
  <p class="ultmod">
    Última modificación de esta página: 
    <time datetime="2015-11-11">11 de noviembre de 2015</time></p>

  <p class="licencia">
    Esta página forma parte del curso <a href="http://www.mclibre.org/consultar/php/">
    <cite>Programación web en PHP</cite></a> por <cite>Bartolomé Sintes Marco</cite>.<br />
    y se distribuye bajo una <a rel="license" href="https://creativecommons.org/licenses/by-sa/4.0/deed.es_ES">
    Licencia Creative Commons Reconocimiento-CompartirIgual 4.0 Internacional (CC BY-SA 4.0)</a>.</p>
</footer>
</body>
</html>