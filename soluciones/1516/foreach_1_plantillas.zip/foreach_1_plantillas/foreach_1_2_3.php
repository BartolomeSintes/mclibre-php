<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>Palabras repetidas (Resultado 2). foreach (1). 
    Ejercicios. PHP. Bartolomé Sintes Marco</title>
  <link href="mclibre_php_soluciones.css" rel="stylesheet" type="text/css" title="Color" />
</head>

<body>
<h1>Palabras repetidas (Resultado 2)</h1>

<?php

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

<p><a href="foreach_1_2_1.html">Volver al formulario inicial.</a></p>

<footer>
  <p class="ultmod">
    Última modificación de esta página: 
    <time datetime="2015-11-05">5 de noviembre de 2015</time></p>
</footer>
</body>
</html>