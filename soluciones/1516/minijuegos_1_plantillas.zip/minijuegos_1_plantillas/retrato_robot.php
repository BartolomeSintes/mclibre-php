<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>Retato Robot (Formulario). Minijuegos (1) 
    Ejercicios. Programación web en PHP. Bartolomé Sintes Marco</title>
  <link href="mclibre_php_soluciones.css" rel="stylesheet" type="text/css" title="Color" />
  <style type="text/css">
    table { border-collapse: collapse; ; margin-left: auto; margin-right: auto; }
    td { padding: 0; }
    img { vertical-align: bottom; }
  </style>
</head>
<body>

<h1>Retrato Robot</h1>

<?php

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

<footer>
  <p class="ultmod">
    Última modificación de esta página: 
    <time datetime="2015-10-29">29 de octubre de 2015</time></p>
</footer>
</body>
</html>
