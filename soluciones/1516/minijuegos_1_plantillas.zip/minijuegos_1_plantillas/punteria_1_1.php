<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>Puntería 1 (Formulario). Minijuegos (1) 
    Ejercicios. Programación web en PHP. Bartolomé Sintes Marco</title>
  <link href="mclibre_php_soluciones.css" rel="stylesheet" type="text/css" title="Color" />
</head>

<body>
<h1>Puntería 1 (Formulario)</h1>

<form action="punteria_1_2.php" method="get">
  <p>Haga clic en el punto negro:</p>

<?php

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
        
</form>

<footer>
  <p class="ultmod">
    Última modificación de esta página: 
    <time datetime="2015-10-29">29 de octubre de 2015</time></p>

  <p class="licencia">
    Esta página forma parte del curso <a href="http://www.mclibre.org/consultar/php/">
    <cite>Programación web en PHP</cite></a> por <cite>Bartolomé Sintes Marco</cite>.<br />
    y se distribuye bajo una <a rel="license" href="https://creativecommons.org/licenses/by-sa/4.0/deed.es_ES">
    Licencia Creative Commons Reconocimiento-CompartirIgual 4.0 Internacional (CC BY-SA 4.0)</a>.</p>
</footer>
</body>
</html>