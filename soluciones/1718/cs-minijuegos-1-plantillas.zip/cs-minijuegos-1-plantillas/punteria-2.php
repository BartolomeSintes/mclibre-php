<?php
/**
 * Puntería 2 - punteria-2.php
 *
 * @author    Escribe tu nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>Puntería 2. Minijuegos (1).
    Escribe tu nombre</title> 
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link href="mclibre-php-soluciones.css" rel="stylesheet" type="text/css" title="Color" />
</head>

<body>
  <h1>Puntería 2</h1>

  <form action="punteria-2.php" method="get">
    <p>Haga clic en el punto negro:</p>

    <p><input type="image" name="dibujo" src="punteria-dibujo.php" alt="punteria" /></p>
  </form>
  
<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
  <footer>
    <p>Escribe tu nombre</p>
  </footer>
</body>
</html>
