<?php
/**
 * Puntería 1-1 - punteria-1-1.php
 *
 * @author    Escribe tu nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>Puntería 1 (Formulario). Minijuegos (1).
    Escribe tu nombre</title> 
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link href="mclibre-php-soluciones.css" rel="stylesheet" type="text/css" title="Color" />
</head>

<body>
  <h1>Puntería 1 (Formulario)</h1>

  <form action="punteria-1-2.php" method="get">
    <p>Haga clic en el punto negro:</p>

    <p><input type="image" name="dibujo" src="punteria-1-dibujo.php" alt="punteria" /></p>
  </form>

  <footer>
    <p>Escribe tu nombre</p>
  </footer>
</body>
</html>
