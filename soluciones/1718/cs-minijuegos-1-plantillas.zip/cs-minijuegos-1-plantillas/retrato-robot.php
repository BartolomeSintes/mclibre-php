<?php
/**
 * Retrato Robot - retrato-robot.php
 *
 * @author    Escribe tu nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>Retato Robot. Minijuegos (1).
    Escribe tu nombre</title> 
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link href="mclibre-php-soluciones.css" rel="stylesheet" type="text/css" title="Color" />
  <style type="text/css">
    table { border-collapse: collapse; ; margin-left: auto; margin-right: auto; }
    td { padding: 0; }
    img { vertical-align: bottom; }
  </style>
</head>
<body>

  <h1>Retrato Robot</h1>

  <form action="retrato-robot.php" method="get">
    <table>
      <tbody>
<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
      </tbody>
    </table>
  </form>

  <footer>
    <p>Escribe tu nombre</p>
  </footer>
</body>
</html>
