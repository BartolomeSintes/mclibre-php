<?php
/**
 * Puntería 1-1 - punteria-1-dibujo.php
 *
 * @author    Escribe tu nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
