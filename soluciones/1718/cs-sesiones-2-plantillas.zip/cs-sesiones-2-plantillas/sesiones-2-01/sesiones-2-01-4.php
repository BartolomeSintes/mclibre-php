<?php
/**
 * Sesiones (2) 01 - sesiones-2-01-4.php
 *
 * @author    Escribe tu nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>Formulario en tres pasos (Resultado). Sesiones (2) 01. Sesiones.
    Escribe tu nombre</title> 
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link href="mclibre-php-soluciones.css" rel="stylesheet" type="text/css" title="Color" />
</head>

<body>
  <h1>Formulario en tres pasos (Resultado)</h1>
	
<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

  <p><a href="sesiones-2-01-1.php">Volver a la primera página.</a></p>

  <footer>
    <p>Escribe tu nombre</p>
  </footer>
</body>
</html>
