<?php
/**
 * Sesiones (2) 03 - cerrar.php
 *
 * @author    Escribe tu nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
