<?php
/**
 * Sesiones (2) 04 - borrar-2.php
 *
 * @author    Escribe tu nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>Borrar datos (2). Sesiones (2) 04. Sesiones.
    Ejercicios. PHP. Bartolomé Sintes Marco</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link href="mclibre-php-soluciones.css" rel="stylesheet" type="text/css" title="Color" />
</head>

<body>
  <h1>Borrar datos (2)</h1>

  <p class="aviso">Se ha producido un problema. No se ha borrado ningún dato.</p>

  <p><a href="borrar-1.php">Volver al formulario.</a></p>

  <footer>
    <p>Escribe tu nombre</p>
  </footer>
</body>
</html>
