<?php
/**
 * Sesiones (2) 04 - cerrar.php
 *
 * @author    Escribe tu nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
