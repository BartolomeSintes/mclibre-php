<?php
/**
 * Sesiones (2) 12 - sesiones-2-12-2.php
 *
 * @author    Escribe tu nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
