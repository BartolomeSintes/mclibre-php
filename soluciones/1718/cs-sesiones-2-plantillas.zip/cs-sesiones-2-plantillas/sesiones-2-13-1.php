<?php
/**
 * Sesiones (2) 13 - sesiones-2-13-1.php
 *
 * @author    Escribe tu nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>Almacenamiento de datos en sesión. Sesiones (2) 013. Sesiones.
    Ejercicios. PHP. Bartolomé Sintes Marco</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link href="mclibre-php-soluciones.css" rel="stylesheet" type="text/css" title="Color" />
</head>

<body>
  <h1>Almacenamiento de datos en sesión</h1>

  <form action="sesiones-2-13-2.php" method="get">
    <p>Escriba algún nombre: <input type="text" name="nombre" size="30" maxlength="30" /></p>

    <p>
      <input type="submit" value="Añadir" />
      <input type="reset" value="Borrar" />
    </p>
  </form>
	
<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

  <footer>
    <p>Escribe tu nombre</p>
  </footer>
</body>
</html>
