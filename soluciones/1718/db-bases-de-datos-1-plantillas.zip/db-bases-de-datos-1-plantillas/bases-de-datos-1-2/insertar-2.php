<?php
/**
 * Bases de datos 1-2 - insertar-2.php
 *
 * @author    Escribe tu nombre
 *
 */

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";
