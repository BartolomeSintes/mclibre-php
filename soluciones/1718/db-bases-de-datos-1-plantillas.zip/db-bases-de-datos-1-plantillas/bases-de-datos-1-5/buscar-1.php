<?php
/**
 * Bases de datos 1-5 - buscar-1.php
 *
 * @author    Escribe tu nombre
 *
 */

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";
