<?php
/**
 * Bases de datos 1-6 - modificar-2.php
 *
 * @author    Escribe tu nombre
 *
 */

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";
