<?php
/**
 * Memorión (2) - memorion-2-4.php
 *
 * @author    Escribe tu nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
