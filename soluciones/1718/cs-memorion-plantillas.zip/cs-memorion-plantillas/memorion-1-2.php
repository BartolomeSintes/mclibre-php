<?php
/**
 * Memorión (1) - memorion-1-2.php
 *
 * @author    Escribe tu nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>