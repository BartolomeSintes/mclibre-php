﻿<?php
/**
 * Controles en formularios (1) 7-2 - controles-formularios-1-7-2.php
 *
 * @author    Escribe tu nombre
 *
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>Colores 2 (Resultado). Controles en formularios (1).
    Escribe tu nombre</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link href="mclibre-php-soluciones.css" rel="stylesheet" type="text/css" title="Color" />
<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
</head>

<body>
  <h1>Colores 2 (Resultado)</h1>

  <p>Se han cambiado los colores elegidos.</p>

  <p><a href="controles-formularios-1-7-1.php">Volver al formulario.</a></p>

  <footer>
    <p>Escribe tu nombre</p>
  </footer>
</body>
</html>
