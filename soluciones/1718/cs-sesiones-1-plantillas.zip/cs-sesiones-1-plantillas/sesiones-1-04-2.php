<?php
/**
 * Sesiones (1) 04 - sesiones-1-04-2.php
 *
 * @author    Escribe tu nombre
 *
 */

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";
