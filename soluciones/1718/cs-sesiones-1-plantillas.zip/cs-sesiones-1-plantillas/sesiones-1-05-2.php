<?php
/**
 * Sesiones (1) 05 - sesiones-1-05-2.php
 *
 * @author    Escribe tu nombre
 *
 */

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";
