<?php
/**
 * Sesiones (1) 12 - sesiones-1-12-2.php
 *
 * @author    Escribe tu nombre
 *
 */

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";
