<?php
/**
 * Sesiones (1) 06 - sesiones-1-06-2.php
 *
 * @author    Escribe tu nombre
 *
 */

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";
