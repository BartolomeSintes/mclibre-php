<?php
/**
 * Bases de datos 2-3 - config.php
 *
 * @author    Escribe tu nombre
 *
 */

// Base de datos utilizada por el programa: MYSQL o SQLITE

$dbMotor = SQLITE;     // Valores posibles: MYSQL o SQLITE

// Configuración para MYSQL

define("MYSQL_HOST",     "mysql:host=localhost");   // Nombre de host
define("MYSQL_USSER",    "root");                   // Nombre de usuario
define("MYSQL_PASSWORD", "");                       // Contraseña de usuario
define("MYSQL_DATABASE", "mclibre_base_datos_2_3"); // Nombre de la base de datos
define("MYSQL_TABLA",    "tabla");                  // Nombre de la tabla

// Configuración para SQLite

define("SQLITE_DATABASE", "/tmp/mclibre/mclibre_base-datos-2-3.sqlite"); // Ubicación de la base de datos
define("SQLITE_TABLA",   "tabla");                                       // Nombre de la tabla

// Configuración Tabla Agenda

define("MAX_REG_TABLA",  20); // Número máximo de registros en la tabla
$tamNombre    = 40;           // Tamaño del campo Nombre
$tamApellidos = 60;           // Tamaño del campo Apellidos
$tamTelefono  = 10;           // Tamaño del campo Teléfono
$tamCorreo    = 50;           // Tamaño del campo Correo

// Método de envío de formularios

define("FORM_METHOD",    GET);     // Valores posibles: GET o POST
