<?php
/**
 * Bases de datos 2-1 - borrar-todo-2.php
 *
 * @author    Escribe tu nombre
 *
 */

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";
