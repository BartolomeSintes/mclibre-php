<?php
/**
 * Bases de datos 2-1 - insertar-1.php
 *
 * @author    Escribe tu nombre
 *
 */
 
print "<p class=\"aviso\">Ejercicio incompleto</p>\n";
