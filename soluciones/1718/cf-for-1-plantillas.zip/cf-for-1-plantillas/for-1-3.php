<?php
/**
 * Sucesiones aritméticas 3 - for-1-3.php
 *
 * @author    Escribe tu nombre
 *
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>Sucesiones aritméticas (3). for (1).
    Escribe tu nombre</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link href="mclibre-php-soluciones.css" rel="stylesheet" type="text/css" title="Color" />
</head>

<body>
  <h1>Sucesiones aritméticas (3)</h1>

  <p>Valores generados por bucles que imprimen $i:</p>

<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

  <footer>
    <p>Escribe tu nombre</p>
  </footer>
</body>
</html>
