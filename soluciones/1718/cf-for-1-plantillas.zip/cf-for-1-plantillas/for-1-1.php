<?php
/**
 * Sucesiones aritméticas 1 - for-1-1.php
 *
 * @author    Escriba su nombre
 *
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Sucesiones aritméticas (1). for (1).
    Escriba su nombre</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Sucesiones aritméticas (1)</h1>

  <p>Valores generados por bucles que empiezan en 1 y suben de 1 en 1:</p>

<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

  <footer>
    <p>Escriba su nombre</p>
  </footer>
</body>
</html>
