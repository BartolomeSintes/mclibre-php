<?php
/**
 * Sucesiones numéricas - for-1-4.php
 *
 * @author    Escribe tu nombre
 *
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>Sucesiones numéricas. for (1).
    Escribe tu nombre</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link href="mclibre-php-soluciones.css" rel="stylesheet" type="text/css" title="Color" />
</head>

<body>
  <h1>Sucesiones numéricas</h1>

  <p>Valores generados por bucles que suben de 1 en 1:</p>

<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

  <footer>
    <p>Escribe tu nombre</p>
  </footer>
</body>
</html>
