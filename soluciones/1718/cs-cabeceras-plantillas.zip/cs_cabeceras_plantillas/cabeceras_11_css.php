<?php

print "    <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
footer {
  border-top: black 1px solid;
  margin-top: 2em;
}

footer cite {
  font-weight: bold;
}