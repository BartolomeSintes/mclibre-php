<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>Hoja de estilo. Cabeceras.
    Escribe tu nombre</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link href="cabeceras-11-css.php" rel="stylesheet" type="text/css" title="Color" />
</head>

<body>
  <h1>Título de la página</h1>

  <p>Texto de la página</p>

  <footer>
    <p>Escribe tu nombre</p>
  </footer>
</body>
</html>
