<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>Imagen. Cabeceras.
    Escribe tu nombre</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link href="mclibre-php-soluciones.css" rel="stylesheet" type="text/css" title="Color" />
</head>

<body>
  <h1>Imagen</h1>

  <p><img src="cabeceras-12-svg.php" alt="imagen" width="150" height="150" /></p>

  <footer>
    <p>Escribe tu nombre</p>
  </footer>
</body>
</html>
