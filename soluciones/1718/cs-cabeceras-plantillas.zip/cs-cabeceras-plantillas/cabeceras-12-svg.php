<?php
/**
 * Imagen - cabeceras-12-svg.php
 *
 * @author    Escribe tu nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
