<?php
/**
 * Imagen - cabeceras-12-svg.php
 *
 * @author    Escribe tu nombre
 *
 */

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
