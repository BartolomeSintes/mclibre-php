<?php
/**
 * Menús 6 - conectar.php
 *
 * @author    Escribe tu nombre
 *
 */

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";
