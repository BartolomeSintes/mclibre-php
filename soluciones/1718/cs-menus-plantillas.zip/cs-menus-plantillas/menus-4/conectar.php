<?php
/**
 * Menús 4 - conectar.php
 *
 * @author    Escribe tu nombre
 *
 */

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";
