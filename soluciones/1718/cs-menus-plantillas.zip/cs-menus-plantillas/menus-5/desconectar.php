<?php
/**
 * Menús 5 - desconectar.php
 *
 * @author    Escribe tu nombre
 *
 */

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";
