﻿<?php
/**
 * Rectángulo de estrellas 1 (Resultado) - for-2-1-2.php
 *
 * @author    Escribe tu nombre
 *
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>Rectángulo de estrellas 1 (Resultado). for (2).
    Ejercicios. PHP. Bartolomé Sintes Marco</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link href="mclibre-php-soluciones.css" rel="stylesheet" type="text/css" title="Color" />
</head>

<body>
  <h1>Rectángulo de estrellas 1 (Resultado)</h1>

<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

  <p><a href="for-2-1-1.php">Volver al formulario.</a></p>

  <footer>
    <p>Escribe tu nombre</p>
  </footer>
</body>
</html>