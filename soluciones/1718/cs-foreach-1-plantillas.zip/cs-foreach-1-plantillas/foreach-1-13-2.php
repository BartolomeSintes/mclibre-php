<?php
/**
 * Encuesta (Resultado) - foreach-1-13-2.php
 *
 * @author    Escribe tu nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>Encuesta (Resultado). foreach (1). Sesiones.
    Escribe tu nombre</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link href="mclibre-php-soluciones.css" rel="stylesheet" type="text/css" title="Color" />
</head>

<body>
  <h1>Encuesta (Resultado)</h1>

<?php

print "/* Ejercicio incompleto */\n";

?>
  <p><a href="foreach-1-13-1.php">Volver al formulario.</a></p>

  <footer>
    <p>Escribe tu nombre</p>
  </footer>
</body>
</html>