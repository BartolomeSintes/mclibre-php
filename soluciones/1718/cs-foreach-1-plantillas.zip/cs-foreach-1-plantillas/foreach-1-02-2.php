<?php
/**
 * Seleccione dibujos - foreach-1-02-2.php
 *
 * @author    Escribe tu nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";
