<?php
/**
 * Encuesta (Formulario) - foreach-1-3-1.php
 *
 * @author    Escribe tu nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>Encuesta (Formulario). foreach (1). Sesiones.
    Escribe tu nombre</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link href="mclibre-php-soluciones.css" rel="stylesheet" type="text/css" title="Color" />
</head>

<body>
  <h1>Encuesta (Formulario)</h1>

<?php

print "/* Ejercicio incompleto */\n";

?>

  <form action="foreach-1-3-2.php" method="get">
    <table>
      <tbody>

<?php

print "/* Ejercicio incompleto */\n";

?>
      </tbody>
    </table>

    <p>
      <input type="submit" value="Contar" />
      <input type="reset" value="Borrar" />
    </p>
  </form>

  <footer>
    <p>Escribe tu nombre</p>
  </footer>
</body>
</html>