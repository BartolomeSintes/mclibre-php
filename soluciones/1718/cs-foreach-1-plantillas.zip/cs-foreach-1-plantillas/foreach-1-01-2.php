<?php
/**
 * Elimine dibujos - foreach-1-01-2.php
 *
 * @author    Escribe tu nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";
