<?php
/**
 * Elimine dibujos en orden - foreach-1-03-1.php
 *
 * @author    Escribe tu nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>Elimine dibujos. foreach (1). Sesiones.
    Escribe tu nombre</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link href="mclibre-php-soluciones.css" rel="stylesheet" type="text/css" title="Color" />
  <style type="text/css">
  button { background-color: hsl(240, 100%, 98%); padding: 0; border: none;}
  </style>
</head>

<body>
<?php

print "/* Ejercicio incompleto */\n";

?>

  <footer>
    <p>Escribe tu nombre</p>
  </footer>
</body>
</html>
