<?php
/**
 * Elimine dibujos en orden - foreach-1-03-2.php
 *
 * @author    Escribe tu nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";
