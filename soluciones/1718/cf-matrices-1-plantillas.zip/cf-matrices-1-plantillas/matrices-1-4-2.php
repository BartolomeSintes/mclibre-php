﻿<?php
/**
 * Matrices 4-2 - matrices_4_2.php
 *
 * @author    Escribe tu nombre
 *
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>Eliminar elemento de matriz (Resultado). Matrices (1).
    Ejercicios. Programación web en PHP. Bartolomé Sintes Marco</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link href="mclibre-php-soluciones.css" rel="stylesheet" type="text/css" title="Color" />
</head>

<body>
  <h1>Eliminar elemento de matriz (Resultado)</h1>

<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

  <p><a href="matrices-1-4-1.php">Volver al formulario.</a></p>

  <footer>
    <p>Escribe tu nombre</p>
  </footer>
</body>
</html>
