<?php

/**
 * Sesiones (2) 3-2 - sesiones-2-3-2.php
 *
 * @author Escriba aquí su nombre
 */

print "<!-- Ejercicio incompleto -->\n";
