<?php
/**
 * Sesiones (2) 5-1 - sesiones-2-5-1.php
 *
 * @author Escriba aquí su nombre
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Formulario en dos pasos (Formulario 1).
    Sesiones (2). Sesiones.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Formulario en dos pasos (Formulario 1)</h1>

  <form action="sesiones-2-5-2.php" method="get">
    <p>Escriba su nombre:</p>

    <p>
      <label>
        Nombre:
        <input type="text" name="nombre" size="20" maxlength="20">
      </label>
<?php

print "      <span class=\"aviso\">Ejercicio incompleto</span>\n";

?>
    </p>

    <p>
      <input type="submit" value="Siguiente">
      <input type="reset">
    </p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
