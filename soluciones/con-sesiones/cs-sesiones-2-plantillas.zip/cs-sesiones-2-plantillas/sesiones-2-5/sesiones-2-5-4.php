<?php

/**
 * Sesiones (2) 5-4 - sesiones-2-5-4.php
 *
 * @author Escriba aquí su nombre
 */

print "<!-- Ejercicio incompleto -->\n";
