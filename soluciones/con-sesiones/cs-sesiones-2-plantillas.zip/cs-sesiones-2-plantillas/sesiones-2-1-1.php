<?php
/**
 * Sesiones (2) 1-1 - sesiones-2-1-1.php
 *
 * @author Escriba aquí su nombre
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Formulario Texto 1 (Formulario).
    Sesiones (2). Sesiones.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Formulario Texto 1 (Formulario)</h1>

<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";
print "\n";

?>
  <form action="sesiones-2-1-2.php" method="get">
    <p>
      <label>
        Escriba texto:
        <input type="text" name="texto" size="20" maxlength="20">
      </label>
    </p>

    <p>
      <input type="submit" value="Siguiente">
      <input type="reset">
    </p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
