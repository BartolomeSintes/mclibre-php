<?php
/**
 * Sesiones (2) 03 - nombre-2.php
 *
 * @author Escriba aquí su nombre
 *
 */

print "    <p class=\"aviso\">Ejercicio incompleto</p>\n";
