<?php

/**
 * Sesiones (2) 02 - sesiones-2-6-2.php
 *
 * @author Escriba aquí su nombre
 */

print "<!-- Ejercicio incompleto -->\n";
