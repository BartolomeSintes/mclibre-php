<?php

/**
 * Sesiones (2) 4-2 - sesiones-2-4-2.php
 *
 * @author Escriba aquí su nombre
 */

print "<!-- Ejercicio incompleto -->\n";
