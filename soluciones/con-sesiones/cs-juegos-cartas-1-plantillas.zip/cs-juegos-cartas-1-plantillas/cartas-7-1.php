<?php
/**
 *
 * @author Escriba aquí su nombre
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Cambio de cartas (1).
    Juegos de cartas (1). Sesiones.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Cambio de cartas (1)</h1>

  <p>La puntuación total es la suma de los valores de las cartas. Las cartas repetidas valen el doble, las repetidas tres veces el triple y las repetidas cuatro veces valen cuatro veces más.</p>

  <p>Puede cambiar hasta cinco cartas. Haga clic en la carta que desee cambiar:</p>

  <form action="cartas-7-2.php" method="get">
<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

    <p><input type="submit" name="accion" value="reiniciar"></p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
