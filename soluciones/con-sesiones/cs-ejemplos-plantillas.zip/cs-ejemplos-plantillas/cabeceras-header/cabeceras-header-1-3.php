<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>header 1-3. Cabeceras. Ejemplos. PHP. Bartolomé Sintes Marco. www.mclibre.org</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
  <p>Esta es la página 3.</p>

  <p>La redirección <strong>SÍ</strong> se ha realizado.</p>

  <p><a href="cabeceras-header-1-1.php">Volver a la página 1</a></p>
</body>
</html>
