<?php
print "<p>Intento fallido de redirección</p>\n";
header("Location:http://www.example.com");
