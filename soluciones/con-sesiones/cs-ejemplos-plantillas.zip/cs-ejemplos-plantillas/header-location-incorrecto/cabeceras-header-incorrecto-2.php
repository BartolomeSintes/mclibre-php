<p>Intento fallido de redirección</p>
<?php
header("Location:http://www.example.com");
