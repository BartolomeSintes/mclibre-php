<?php
/**
 * Sesiones (1) 6-2 - sesiones-1-6-2.php
 *
 * @author    Bartolomé Sintes Marco <bartolome.sintes+mclibre@gmail.com>
 * @copyright 2026 Bartolomé Sintes Marco
 * @license   http://www.gnu.org/licenses/agpl.txt AGPL 3 or later
 * @version   2026-01-27
 * @link      http://www.mclibre.org
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// Accedemos a la sesión
session_name("sesiones-1-6");
session_start();

// Si falta una de las dos variables de sesión, reiniciamos los valores
if (!isset($_SESSION["cartas"], $_SESSION["mensaje"])) {
    $_SESSION["cartas"]  = rand(3, 10);
    $_SESSION["mensaje"] = "  <p>Quedan $_SESSION[cartas] cartas. Haga clic en el dibujo para eliminar una carta.</p>\n";
}

// Función de recogida de datos
function recoge($key, $type = "")
{
    if (!is_string($key) && !is_int($key) || $key == "") {
        trigger_error("Function recoge(): Argument #1 (\$key) must be a non-empty string or an integer", E_USER_ERROR);
    } elseif ($type !== "" && $type !== []) {
        trigger_error("Function recoge(): Argument #2 (\$type) is optional, but if provided, it must be an empty array or an empty string", E_USER_ERROR);
    }
    $tmp = $type;
    if (isset($_REQUEST[$key])) {
        if (!is_array($_REQUEST[$key]) && !is_array($type)) {
            $tmp = trim(htmlspecialchars($_REQUEST[$key]));
        } elseif (is_array($_REQUEST[$key]) && is_array($type)) {
            $tmp = $_REQUEST[$key];
            array_walk_recursive($tmp, function (&$value) {
                $value = trim(htmlspecialchars($value));
            });
        }
    }
    return $tmp;
}

// Recogemos la orden de quitar una carta
$quita = recoge("quita");

// Si hemos recibido la orden de quitar una carta ...
if ($quita == "quita") {
    // reducimos el número de cartas a mostrar guardado
    $_SESSION["cartas"] -= 1;
    // Si el número de cartas a mostrar guardado era cero y al reducirlo se hace negativo ...
    if ($_SESSION["cartas"] < 0) {
        // lo generamos al azar
        $_SESSION["cartas"] = rand(3, 10);
    }
    // Guardamos el mensaje correspondiente al número de cartas
    if ($_SESSION["cartas"] == 0) {
        $_SESSION["mensaje"] = "  <p>No quedan cartas. Haga clic en el dibujo para volver a poner cartas.</p>\n";
    } elseif ($_SESSION["cartas"] == 1) {
        $_SESSION["mensaje"] = "  <p>Queda $_SESSION[cartas] sola carta. Haga clic en el dibujo para eliminarla.</p>\n";
    } else {
        $_SESSION["mensaje"] = "  <p>Quedan $_SESSION[cartas] cartas. Haga clic en el dibujo para eliminar una carta.</p>\n";
    }
}

// Volvemos a la primera página
header("Location:sesiones-1-6-1.php");
