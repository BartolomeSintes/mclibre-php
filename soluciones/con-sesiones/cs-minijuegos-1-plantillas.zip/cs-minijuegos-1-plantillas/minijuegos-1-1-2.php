<?php
/**
 * Sesiones Minijuegos (1) 1 - minijuegos-1-1-2.php
 *
 * @author Escriba aquí su nombre
 *
 */

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";
