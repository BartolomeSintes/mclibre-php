<?php
/**
 * Sesiones Minijuegos (1) 3 - minijuegos-1-3-2.php
 *
 * @author Escriba aquí su nombre
 *
 */

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";
