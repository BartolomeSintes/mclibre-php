<?php
/**
 * Sesiones Minijuegos (1) 6 - minijuegos-1-6-2.php
 *
 * @author Escriba aquí su nombre
 *
 */

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";
