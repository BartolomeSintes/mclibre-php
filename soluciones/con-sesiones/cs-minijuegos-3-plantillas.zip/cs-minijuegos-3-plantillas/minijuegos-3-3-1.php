<?php
/**
 * Sesiones Minijuegos (3) 3 - minijuegos-3-3-1.php
 *
 * @author Escriba aquí su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Quita cartas en orden.
    Minijuegos (3). Sesiones.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Quita cartas en orden</h1>

  <form action="minijuegos-3-3-2.php" method="get">
    <p>Haga clic en las cartas en orden numérico creciente:</p>

<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
    <p><input type="submit" name="accion" value="Reiniciar"></p>
  </form>

  <footer>
  <p>Escriba aquí su nombre</p>
</footer>
</body>
</html>
