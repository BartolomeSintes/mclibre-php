<?php
/**
 * Sesiones Minijuegos (3) 4 - minijuegos-3-4-1.php
 *
 * @author Escriba aquí su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Alcanzar puntuación.
    Minijuegos (3). Sesiones.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>El juego infinito de dados: alcanzar puntuación</h1>

  <form action="minijuegos-3-4-2.php" method="get">
<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
  </form>

  <footer>
  <p>Escriba aquí su nombre</p>
</footer>
</body>
</html>
