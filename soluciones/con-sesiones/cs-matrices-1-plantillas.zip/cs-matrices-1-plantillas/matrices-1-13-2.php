<?php
/**
 * Sesiones Matrices (1) 13-2 - Elimine dibujos en orden - matrices-1-13-2.php
 *
 * @author Escriba aquí su nombre
 *
 */

print "    <p class=\"aviso\">Ejercicio incompleto</p>\n";
