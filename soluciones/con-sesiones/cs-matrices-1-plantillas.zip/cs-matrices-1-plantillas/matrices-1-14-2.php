<?php
/**
 * Descubra dibujos - matrices-1-14-2.php
 *
 * @author Escriba aquí su nombre
 *
 */

print "    <p class=\"aviso\">Ejercicio incompleto</p>\n";
