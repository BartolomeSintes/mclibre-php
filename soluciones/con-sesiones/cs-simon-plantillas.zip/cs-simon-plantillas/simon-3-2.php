<?php
/**
 * Simon (3) - simon-3-2.php
 *
 * @author Escriba aquí su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Simon (3).
    Minijuegos. Sesiones.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Simon (3)</h1>

  <form action="simon-3-3.php" method="get">
    <p>Haga clic en los colores:</p>

    <table>
      <tr>
        <td>
          <button type="submit" name="eleccion" value="red">
            <svg version="1.1" xmlns="http://www.w3.org/2000/svg"
                 width="50" height="50" viewBox="0 0 50 50" style="background-color: red">
            </svg>
          </button>
        </td>
        <td>
          <button type="submit" name="eleccion" value="yellow">
            <svg version="1.1" xmlns="http://www.w3.org/2000/svg"
                 width="50" height="50" viewBox="0 0 50 50" style="background-color: yellow">
            </svg>
          </button>
        </td>
      </tr>
      <tr>
        <td>
          <button type="submit" name="eleccion" value="blue">
            <svg version="1.1" xmlns="http://www.w3.org/2000/svg"
                 width="50" height="50" viewBox="0 0 50 50" style="background-color: blue">
            </svg>
          </button>
        </td>
        <td>
          <button type="submit" name="eleccion" value="green">
            <svg version="1.1" xmlns="http://www.w3.org/2000/svg"
                 width="50" height="50" viewBox="0 0 50 50" style="background-color: green">
            </svg>
          </button>
        </td>
      </tr>
    </table>

    <p><input type="submit" name="eleccion" value="Reiniciar"></p>
  </form>

<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
