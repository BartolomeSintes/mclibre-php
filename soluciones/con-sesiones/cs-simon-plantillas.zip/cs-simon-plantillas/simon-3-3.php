<?php
/**
 * Simon (3) - simon-3-3.php
 *
 * @author Escriba aquí su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";
