<?php
/**
 * Simon (3) - simon-3-1.php
 *
 * @author Escriba aquí su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Simon (3).
    Minijuegos. Sesiones.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Simon (3)</h1>

  <p>Secuencia a reproducir:</p>
<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
  <form action="simon-3-2.php" method="get">
    <p>Haga clic para comenzar el juego:</p>

    <p><input type="submit" name="eleccion" value="Comenzar"></p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
