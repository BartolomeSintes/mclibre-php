<?php
/**
 * Palabras repetidas (Formulario) - matrices-2-2-1.php
 *
 * @author Escriba aquí su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Palabras repetidas (Formulario).
    Matrices (2). Sesiones.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Palabras repetidas (Formulario)</h1>

  <p>Escriba una palabra en cada caja de texto y le diré si ha repetido alguna.</p>

  <form action="matrices-2-2-2.php" method="get">
<?php

print "    <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

    <p>
      <input type="submit" value="Contar">
      <input type="reset">
    </p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
