<?php
// print "    <p class=\"aviso\">Ejercicio incompleto</p>\n";

function cabecera($texto, $menu)
{
    print "<!DOCTYPE html>\n";
    print "<html lang=\"es\">\n";
    print "  <head>\n";
    print "    <meta charset=\"utf-8\" />\n";

    // print "    <p class=\"aviso\">Ejercicio incompleto</p>\n";

    print "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />\n";
    print "    <link href=\"mclibre_php_soluciones_proyectos.css\" rel=\"stylesheet\" type=\"text/css\" />\n";
    print "  </head>\n";
    print "\n";
    print "  <body>\n";
    print "    <header>\n";

    print "      <p class=\"aviso\">Ejercicio incompleto</p>\n";

    print "\n";
    print "      <nav>\n";
    print "        <ul>\n";

    print "          <p class=\"aviso\">Ejercicio incompleto</p>\n";

    print "        </ul>\n";
    print "      </nav>\n";
    print "    </header>\n";
    print "\n";
    print "    <main>\n";
}

function pie()
{
    print "    </main>\n";
    print "  </body>\n";
    print "</html>";
}
