<?php
/**
 * Bases de datos 2-1 - index.php
 *
 * @author Escriba aquí su nombre
 */

require_once "biblioteca.php";

cabecera("Inicio", MENU_PRINCIPAL);

pie();
