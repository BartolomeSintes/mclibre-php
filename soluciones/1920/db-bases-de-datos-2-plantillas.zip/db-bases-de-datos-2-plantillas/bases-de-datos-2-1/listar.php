<?php
/**
 * Bases de datos 2-1 - listar.php
 *
 * @author Escriba aquí su nombre
 */

require_once "biblioteca.php";

$db = conectaDb();
cabecera("Listar", MENU_VOLVER);

$consulta = "SELECT * FROM $dbTabla";
$result = $db->query($consulta);

print "    <p>Listado completo de registros:</p>\n";
print "\n";
print "    <table class=\"conborde franjas\">\n";
print "      <thead>\n";
print "        <tr>\n";
print "          <th>Nombre</th>\n";
print "          <th>Apellidos</th>\n";
print "        </tr>\n";
print "      </thead>\n";
print "      <tbody>\n";
foreach ($result as $valor) {
    print "        <tr>\n";
    print "          <td>$valor[nombre]</td>\n";
    print "          <td>$valor[apellidos]</td>\n";
    print "        </tr>\n";
}
print "      </tbody>\n";
print "    </table>\n";

$db = null;
pie();
