<?php
/**
 * Bases de datos 2-1 - borrar-2.php
 *
 * @author Escriba aquí su nombre
 */

require_once "biblioteca.php";

$db = conectaDb();
cabecera("Borrar 2", MENU_VOLVER);

$id = recoge("id", []);

foreach ($id as $indice => $valor) {
    $consulta = "DELETE FROM $dbTabla
    WHERE id=:indice";
    $result = $db->prepare($consulta);
    if ($result->execute([":indice" => $indice])) {
        print "    <p>Registro borrado correctamente.</p>\n";
    } else {
        print "    <p>Error al borrar el registro.</p>\n";
    }
}

$db = null;
pie();
