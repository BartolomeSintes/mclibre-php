<?php
/**
 * Bases de datos 2-1 - borrar-todo-2.php
 *
 * @author Escriba aquí su nombre
 *
 */

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";
