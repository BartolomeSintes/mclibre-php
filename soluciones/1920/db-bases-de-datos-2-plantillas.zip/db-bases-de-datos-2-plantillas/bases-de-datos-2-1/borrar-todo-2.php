<?php
/**
 * Bases de datos 2-1 - borrar-todo-2.php
 *
 * @author Escriba aquí su nombre
 */

require_once "biblioteca.php";

if (!isset($_REQUEST["si"])) {
    header("Location:index.php");
    exit();
}

$db = conectaDb();
cabecera("Borrar todo 2", MENU_VOLVER);
borraTodo($db, $tablaAgenda, $consultaCreaTabla);

$db = null;
pie();
