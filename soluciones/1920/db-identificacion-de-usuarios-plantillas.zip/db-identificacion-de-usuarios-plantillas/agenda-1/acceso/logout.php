<?php
/**
 * Identificación de usuarios (2) - Agenda (1) - logout.php
 *
 * @author Escriba aquí su nombre
 */

print "<!-- Ejercicio incompleto -->\n";
