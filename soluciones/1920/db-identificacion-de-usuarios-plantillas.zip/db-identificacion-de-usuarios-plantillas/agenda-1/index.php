<?php
/**
 * Identificación de usuarios (2) - Agenda (1) - index.php
 *
 * @author Escriba aquí su nombre
 */

require_once "biblioteca.php";

cabecera("Inicio", MENU_PRINCIPAL);

pie();
