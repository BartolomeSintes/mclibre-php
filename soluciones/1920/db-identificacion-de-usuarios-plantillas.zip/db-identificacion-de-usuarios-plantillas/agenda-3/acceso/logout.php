<?php
/**
 * Identificación de usuarios (1) - Agenda (3) - acceso/logout.php
 *
 * @author Escriba aquí su nombre
 */

require_once "../comunes/biblioteca.php";

session_name(SESSION_NAME);
session_start();
session_destroy();
header("location:../index.php");
