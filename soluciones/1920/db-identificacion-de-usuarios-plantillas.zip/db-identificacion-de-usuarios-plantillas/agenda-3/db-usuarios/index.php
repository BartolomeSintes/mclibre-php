<?php
/**
 * Identificación de usuarios (1) - Agenda (3) - db-usuarios/index.php
 *
 * @author Escriba aquí su nombre
 */

require_once "../comunes/biblioteca.php";

session_name(SESSION_NAME);
session_start();
if (!isset($_SESSION["conectado"])) {
    header("Location:../index.php");
    exit;
}

cabecera("Inicio", MENU_AGENDA, 1);

pie();
