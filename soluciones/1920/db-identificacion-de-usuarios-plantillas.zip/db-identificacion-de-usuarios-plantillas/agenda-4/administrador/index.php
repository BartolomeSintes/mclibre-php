<?php
/**
 * Identificación de usuarios - Agenda (4) - administrador/index.php
 *
 * @author Escriba aquí su nombre
 */

require_once "../comunes/biblioteca.php";

session_name(SESSION_NAME);
session_start();
if (!isset($_SESSION["conectado"])) {
    header("Location:../index.php");
    exit;
}

cabecera("Administrador - Inicio", MENU_ADMINISTRADOR, 1);

pie();
