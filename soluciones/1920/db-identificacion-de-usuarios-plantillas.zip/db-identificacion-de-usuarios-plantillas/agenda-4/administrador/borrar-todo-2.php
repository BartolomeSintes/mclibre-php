<?php
/**
 * @author Escriba aquí su nombre
 */

require_once "../comunes/biblioteca.php";

session_name(SESSION_NAME);
session_start();
if (!isset($_SESSION["conectado"])) {
    header("Location:../index.php");
    exit;
}

if (!isset($_REQUEST["si"])) {
    header("Location:index.php");
    exit();
}

$db = conectaDb();

cabecera("Administrador - Borrar todo 2", MENU_ADMINISTRADOR, 1);

borraTodo($db, $tablas, $consultasCreaTabla);

$db = null;
pie();
