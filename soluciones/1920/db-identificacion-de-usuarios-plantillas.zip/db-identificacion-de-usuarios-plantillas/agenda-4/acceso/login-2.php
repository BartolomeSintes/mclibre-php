<?php
/**
 * Identificación de usuarios - Agenda (4) - acceso/login-1.php
 *
 * @author Escriba aquí su nombre
 */

require_once "../comunes/biblioteca.php";

session_name(SESSION_NAME);
session_start();
if (isset($_SESSION["conectado"])) {
    header("Location:../index.php");
    exit();
}

$usuario  = recoge("usuario");
$password = recoge("password");

$db = conectaDb();

if (!$usuario) {
    header("Location:login-1.php?aviso=Error: Nombre de usuario no permitido");
    exit();
}

$consulta = "SELECT * FROM $tablaUsuarios
    WHERE usuario=:usuario";
$result = $db->prepare($consulta);
$result->execute([":usuario" => $usuario]);
if (!$result) {
    header("Location:login-1.php?aviso=Error: Error en la consulta");
    exit();
}

$valor = $result->fetch();
if ($valor["password"] != encripta($password)) {
    header("Location:login-1.php?aviso=Error: Nombre o contraseña incorrecta");
    exit();
}

$_SESSION["conectado"] = true;
$db = null;
header("Location:../index.php");
exit();
