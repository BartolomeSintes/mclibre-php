<?php
/**
 * Identificación de usuarios - Agenda (2) - acceso/login-1.php
 *
 * @author Escriba aquí su nombre
 */

require_once "../comunes/biblioteca.php";

session_name(SESSION_NAME);
session_start();
$_SESSION["conectado"] = true;
header("location:../index.php");
