<?php
/**
 * Identificación de usuarios (2) - Agenda (2) - acceso/logout.php
 *
 * @author Escriba aquí su nombre
 */

require_once "../comunes/biblioteca.php";

session_name(SESSION_NAME);
session_start();
session_destroy();
header("location:../index.php");
