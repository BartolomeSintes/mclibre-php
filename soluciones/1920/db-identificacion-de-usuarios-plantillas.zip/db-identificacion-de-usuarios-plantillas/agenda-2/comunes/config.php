<?php
/**
 * Identificación de usuarios (2) - Agenda (2) - comunes/config.php
 *
 * @author Escriba aquí su nombre
 */

// Base de datos utilizada por el programa: MYSQL o SQLITE

$dbMotor = SQLITE;     // Valores posibles: MYSQL o SQLITE

// Configuración para MYSQL

define("MYSQL_HOST", "mysql:host=localhost");          // Nombre de host
define("MYSQL_USER", "");                              // Nombre de usuario
define("MYSQL_PASSWORD", "");                          // Contraseña de usuario
define("MYSQL_DATABASE", "identificacion_2_agenda_1"); // Nombre de la base de datos
define("MYSQL_TABLE", "agenda");                       // Nombre de la tabla

// Configuración para SQLite

define("SQLITE_DATABASE", "/tmp/mclibre/identificacion-2-agenda-1.sqlite"); // Ubicación de la base de datos
define("SQLITE_TABLE", "agenda");                                           // Nombre de la tabla

// Configuración Tabla Agenda

define("MAX_REG_TABLE", 20);  // Número máximo de registros en la tabla
$tamNombre    = 40;           // Tamaño de la columna Nombre
$tamApellidos = 60;           // Tamaño de la columna Apellidos
$tamTelefono  = 10;           // Tamaño de la columna Teléfono
$tamCorreo    = 50;           // Tamaño de la columna Correo

// Método de envío de formularios

define("FORM_METHOD", GET);         // Valores posibles: GET o POST

// Hoja de estilo

define("COLOR", 27);                // Color básico de la aplicación (0 - 360)

// Nombre de sesión

define("SESSION_NAME", "agenda-1"); // Nombre de sesión
