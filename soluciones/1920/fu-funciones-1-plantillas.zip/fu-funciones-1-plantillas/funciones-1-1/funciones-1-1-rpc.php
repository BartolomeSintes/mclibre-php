<?php
/**
 * Convertidor de distancias (1) JSON-RPC - funciones-1-1-rpc.php
 *
 * @author    Escriba aquí su nombre
 *
 */

// ATENCIÓN: ESTE PROGRAMA NO ESIGUE EXACTAMENTE EL PROTOCOLO JSON-RPC

function convierte($num, $uniOri, $uniFin) {
    // La unidad intermedia es el metro
    $numeroIntermedio = 0;
    if ($uniOri == "km") {
        $numeroIntermedio = $num * 1000;
    } elseif ($uniOri == "m") {
        $numeroIntermedio = $num;
    } elseif ($uniOri == "cm") {
        $numeroIntermedio = $num / 100;
    }

    if ($uniFin == "km") {
        $numeroFinal = $numeroIntermedio / 1000;
    } elseif ($uniFin == "m") {
        $numeroFinal = $numeroIntermedio;
    } elseif ($uniFin == "cm") {
        $numeroFinal = $numeroIntermedio * 100;
    }
    return $numeroFinal;
}

$validParams = ["km", "m", "cm"];

$peticionOk = false;
if ($_REQUEST["method"] == "convertir") {
    if (in_array($_REQUEST["params"]["from"], $validParams)) {
        if (in_array($_REQUEST["params"]["into"], $validParams)) {
            $peticionOk = true;
        }
    }
}

if ($peticionOk == true) {
    $result = convierte($_REQUEST["params"]["value"],$_REQUEST["params"]["from"], $_REQUEST["params"]["into"]);
    print "{\"jsonrpc\" : \"2.0\", \"result\" : $result, \"id\" : $_REQUEST[id] }";
} else {
    print "{\"jsonrpc\" : \"2.0\", \"error\" : -1, \"id\" : $_REQUEST[id] }";
}
