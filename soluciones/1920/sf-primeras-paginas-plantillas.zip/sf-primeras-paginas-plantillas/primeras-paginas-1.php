<?php
/**
 * Primeras páginas. Sin formularios. 1 - primeras-paginas-1.php
 *
 * @author    Escriba su nombre
 *
 */

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>