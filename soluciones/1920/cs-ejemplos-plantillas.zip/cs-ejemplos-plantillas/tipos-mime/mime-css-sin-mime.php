<?php
//header("Content-type: text/css");
$color = rand(0, 360);
print "body {\n";
print "  background-color: hsl($color, 50%, 90%);\n";
print "  color: hsl($color, 50%, 30%);\n";
print "}\n";
?>
