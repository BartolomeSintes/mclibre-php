<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Buffer y redirecciones (1). Cabeceras. Ejemplos. PHP. Escriba aquí su nombre</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
  <p><a href="cabeceras-buffer-2.php">Probar programa</a></p>
</body>
</html>
