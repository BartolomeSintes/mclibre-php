﻿<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>BOM y redirecciones</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>

<body>
  <p>Esta es la página 3.</p>

  <p>La redirección <strong>SÍ</strong> se ha realizado.</p>

  <p><a href="bom-test-con-bom-1.php">Volver al principio</a></p>
</body>
</html>
