<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Buffer y redirecciones (3). Cabeceras. Ejemplos. PHP. Escriba aquí su nombre</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
  <p>La redirección <strong>SÍ</strong> se ha realizado.</p>

  <p><a href="cabeceras-buffer-1.php">Volver al principio</a></p>
</body>
</html>
