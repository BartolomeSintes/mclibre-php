<?php
header("Location:cabeceras-header-1-3.php");
print "<p>La redirección <strong>NO</strong> se ha realizado</p>";
print "<p><a href=\"cabeceras-header-1-1.php\">Volver a la página 1</a></p>";
