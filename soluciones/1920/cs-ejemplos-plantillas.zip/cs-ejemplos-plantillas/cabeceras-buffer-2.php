<?php
$buffer = 1;
ob_start(null, $buffer);
print "<p>Tamaño del buffer: $buffer</p>";
header("Location:cabeceras-buffer-3.php");
print "<p>La redirección <strong>NO</strong> se ha realizado.</p>\n";
print "<p><a href=\"cabeceras-buffer-1.php\">Volver al principio</a></p>\n";
