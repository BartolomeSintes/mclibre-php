<?php
/**
 * Memorión (1) - memorion-1-2.php
 *
 * @author    Escriba aquí su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>