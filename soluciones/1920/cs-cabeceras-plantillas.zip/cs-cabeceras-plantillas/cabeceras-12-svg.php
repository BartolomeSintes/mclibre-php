<?php
/**
 * Imagen - cabeceras-12-svg.php
 *
 * @author Escriba aquí su nombre
 *
 */

print "    <p class=\"aviso\">Ejercicio incompleto</p>\n";
