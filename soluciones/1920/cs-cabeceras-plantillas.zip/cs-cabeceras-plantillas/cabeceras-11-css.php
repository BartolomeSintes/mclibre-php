<?php
/**
 * Hoja de estilo  - cabeceras-11-css.php
 *
 * @author    Escriba aquí su nombre
 *
 */

print "/* Ejercicio incompleto */\n";

?>

footer {
  border-top: black 1px solid;
  margin-top: 2em;
}

footer cite {
  font-weight: bold;
}
