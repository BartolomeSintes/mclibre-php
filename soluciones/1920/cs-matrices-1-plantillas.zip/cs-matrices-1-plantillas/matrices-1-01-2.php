<?php
/**
 * Sesiones (2) 12 - matrices-1-01-2.php
 *
 * @author    Escriba aquí su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
