<?php
/**
 * Encuesta (Formulario) - matrices-1-23-1.php
 *
 * @author    Escriba aquí su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Encuesta (Formulario).
    foreach (1). Sesiones.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Encuesta (Formulario)</h1>

<?php

print "/* Ejercicio incompleto */\n";

?>

  <form action="matrices-1-23-2.php" method="get">
    <table>
      <tbody>

<?php

print "/* Ejercicio incompleto */\n";

?>
      </tbody>
    </table>

    <p>
      <input type="submit" value="Contar">
      <input type="reset" value="Borrar">
    </p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>