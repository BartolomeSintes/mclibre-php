<?php
print "<!DOCTYPE html>\n";
print "<html lang=\"es\">\n";
print "<head>\n";
print "  <meta charset=\"utf-8\">\n";
print "  <title>\n";
print "    Visual Studio Code. Puesta en marcha.\n";
print "    Ejercicios. PHP. Bartolomé Sintes Marco. www.mclibre.org\n";
print "  </title>\n";
print "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n";
print "</head>\n";
print "\n";
print "<body>\n";
print "  <h1>Puesta en marcha. Visual Studio Code 1</h1>\n";
print "\n";
print "<p>Compruebe que está página se muestra correctamente en el navegador.</p>\n";
print "</body>\n";
print "</html>\n";
