<?
/*
Programa de prueba de PHP CS Fixer
*/
$a     =        25    ;
$b =    $a     +      $a*2 ;
