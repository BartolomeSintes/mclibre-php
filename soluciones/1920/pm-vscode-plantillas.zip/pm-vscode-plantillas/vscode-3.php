<?php
define("TEST", 99.9, true);
