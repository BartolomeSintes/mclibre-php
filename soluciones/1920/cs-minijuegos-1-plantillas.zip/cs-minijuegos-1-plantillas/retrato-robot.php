<?php
/**
 * Retrato Robot - retrato-robot.php
 *
 * @author Escriba aquí su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Retato Robot. Minijuegos (1).
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
  <style>
    table { border-collapse: collapse; ; margin-left: auto; margin-right: auto; }
    td { padding: 0; }
    img { vertical-align: bottom; }
  </style>
</head>
<body>

  <h1>Retrato Robot</h1>

  <form action="retrato-robot.php" method="get">
    <table>
      <tbody>
<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
      </tbody>
    </table>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
