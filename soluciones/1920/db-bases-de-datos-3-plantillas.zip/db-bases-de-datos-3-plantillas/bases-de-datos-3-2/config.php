<?php
/**
 * Bases de datos 3-2 - config.php
 *
 * @author Escriba aquí su nombre
 */

// Base de datos utilizada por el programa: MYSQL o SQLITE

$dbMotor = SQLITE;     // Valores posibles: MYSQL o SQLITE

// Configuración para MYSQL

define("MYSQL_HOST", "mysql:host=localhost");        // Nombre de host
define("MYSQL_USER", "");                            // Nombre de usuario
define("MYSQL_PASSWORD", "");                        // Contraseña de usuario
define("MYSQL_DATABASE", "mclibre_base_datos_3_2");  // Nombre de la base de datos
define("MYSQL_TABLE_AGENDA", "tabla");               // Nombre de la tabla

// Configuración para SQLite

define("SQLITE_DATABASE", "/home/barto/mclibre/tmp/mclibre/mclibre-base-datos-3-2.sqlite");  // Ubicación de la base de datos
define("SQLITE_TABLE_AGENDA", "tabla");                                                             // Nombre de la tabla

// Configuración Tabla Agenda

define("MAX_REG_TABLE", 20);  // Número máximo de registros en la tabla
$tamAgendaNombre    = 40;           // Tamaño de la columna Nombre
$tamAgendaApellidos = 60;           // Tamaño de la columna Apellidos

// Método de envío de formularios

define("FORM_METHOD", GET);   // Valores posibles: GET o POST

// Hoja de estilo

define("COLOR", 27);          // Color básico de la aplicación (0 - 360)
