<?php
/**
 * Bases de datos 3-2 - index.php
 *
 * @author    Escriba aquí su nombre
 *
 */

require_once "biblioteca.php";

cabecera("Inicio", MENU_PRINCIPAL);

pie();
