<?php
/**
 * Bases de datos 1-4 - borrar-2.php
 *
 * @author Escriba aquí su nombre
 *
 */

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";
