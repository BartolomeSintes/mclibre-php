<?php
/**
 * Bases de datos 1-3 - listar.php
 *
 * @author Escriba aquí su nombre
 *
 */

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";
