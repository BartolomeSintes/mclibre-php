<?php
/**
 * Puntería 1-1 - punteria-1-dibujo.php
 *
 * @author    Escriba su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
