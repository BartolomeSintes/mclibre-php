<?php
/**
 * Puntería 1-2 - punteria-1-2.php
 *
 * @author    Escriba su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Puntería 1 (Resultado). Minijuegos (1).
    Escriba su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Puntería 1 (Resultado)</h1>

<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

  <p><a href="punteria-1-1.php">Volver al formulario.</a></p>

  <footer>
    <p>Escriba su nombre</p>
  </footer>
</body>
</html>
