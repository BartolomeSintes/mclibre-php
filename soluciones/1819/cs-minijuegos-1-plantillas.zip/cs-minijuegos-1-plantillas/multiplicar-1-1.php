<?php
/**
 * Multiplicar 1-1 - multiplicar-1-1.php
 *
 * @author    Escriba su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Multiplicar 1 (Formulario). Minijuegos (1).
    Escriba su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
  <style>input { text-align: right; }</style>
</head>

<body>
  <h1>Multiplicar 1 (Formulario)</h1>

  <form action="multiplicar-1-2.php" method="get">
    <p>Escriba el resultado de la siguiente multiplicación:</p>

<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

    <p>
      <input type="submit" value="Corregir">
      <input type="reset" value="Borrar">
    </p>
  </form>

  <footer>
    <p>Escriba su nombre</p>
  </footer>
</body>
</html>
