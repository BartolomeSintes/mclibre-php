<?php
/**
 * Minijuegos: Tragaperras (2) - tragaperras-2-2.php
 *
 * @author    Escriba su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
