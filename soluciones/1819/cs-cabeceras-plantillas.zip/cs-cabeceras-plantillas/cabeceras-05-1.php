<?php
/**
 * Formulario 5-1 - cabeceras-05-1.php
 *
 * @author    Escriba su nombre
 *
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>
    Formulario 5 (Formulario).
    Cabeceras. Sesiones.
    Escriba su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color" />
</head>

<body>
  <h1>Formulario 5 (Formulario)</h1>

  <form action="cabeceras-05-2.php" method="get">

<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

    <p>
      <input type="submit" value="Comprobar" />
      <input type="reset" value="Borrar" />
    </p>
  </form>

  <footer>
    <p>Escriba su nombre</p>
  </footer>
</body>
</html>
