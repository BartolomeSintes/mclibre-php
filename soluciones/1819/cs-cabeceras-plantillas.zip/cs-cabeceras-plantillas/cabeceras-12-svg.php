<?php
/**
 * Imagen - cabeceras-12-svg.php
 *
 * @author    Escriba su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
