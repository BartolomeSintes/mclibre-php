<?php
/**
 * Bases de datos 3-2 - index.php
 *
 * @author    Escriba su nombre
 *
 */

require_once "biblioteca.php";

cabecera("Inicio", MENU_PRINCIPAL);

pie();
