<?php
/**
 * Memorión (2) - memorion-2-4.php
 *
 * @author    Escriba su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
