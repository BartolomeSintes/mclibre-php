<?php
/**
 * Memorión (1) - memorion-1-2.php
 *
 * @author    Escriba su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>