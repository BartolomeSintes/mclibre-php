<?php
/**
 * Menús 2 - pagina-3.php
 *
 * @author    Escriba su nombre
 *
 */

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";
