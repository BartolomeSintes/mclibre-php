<?php
/**
 * Menús 3 - pagina-2-2.php
 *
 * @author    Escriba su nombre
 *
 */

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";
