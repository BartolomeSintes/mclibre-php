<?php
/**
 * Menús 3 - index.php
 *
 * @author    Escriba su nombre
 *
 */

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";
