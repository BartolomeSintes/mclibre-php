<?php
/**
 * Menús 6 - desconectar.php
 *
 * @author    Escriba su nombre
 *
 */

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";
