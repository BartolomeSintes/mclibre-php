<?php
/**
 * Bases de datos 1-5 - buscar-1.php
 *
 * @author    Escriba su nombre
 *
 */

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";
