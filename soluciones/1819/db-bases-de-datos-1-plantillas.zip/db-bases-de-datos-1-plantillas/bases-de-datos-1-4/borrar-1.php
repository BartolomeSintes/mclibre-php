<?php
/**
 * Bases de datos 1-4 - borrar-1.php
 *
 * @author    Escriba su nombre
 *
 */

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";
