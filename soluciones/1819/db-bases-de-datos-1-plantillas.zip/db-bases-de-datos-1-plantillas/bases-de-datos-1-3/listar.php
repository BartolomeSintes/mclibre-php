<?php
/**
 * Bases de datos 1-3 - listar.php
 *
 * @author    Escriba su nombre
 *
 */

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";
