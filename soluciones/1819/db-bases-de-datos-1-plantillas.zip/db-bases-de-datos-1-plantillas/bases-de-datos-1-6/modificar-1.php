<?php
/**
 * Bases de datos 1-6 - modificar-1.php
 *
 * @author    Escriba su nombre
 *
 */

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";
