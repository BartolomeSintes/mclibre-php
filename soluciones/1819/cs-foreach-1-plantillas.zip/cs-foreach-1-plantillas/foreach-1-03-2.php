<?php
/**
 * Elimine dibujos en orden - foreach-1-03-2.php
 *
 * @author    Escriba su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";
