<?php
/**
 * Elimine dibujos - foreach-1-01-2.php
 *
 * @author    Escriba su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";
