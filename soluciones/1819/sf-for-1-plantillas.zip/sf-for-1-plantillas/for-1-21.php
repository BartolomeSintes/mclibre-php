<?php
/**
 * for (1) 21 - for-1-21.php
 *
 * @author    Escriba su nombre
 *
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>
    Diana.
    for (1). Sin formularios.
    Escriba su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link href="mclibre-php-ejercicios.css" rel="stylesheet" title="Color" />
</head>

<body>
  <h1>Diana</h1>

  <p>Actualice la página para mostrar una nueva tirada.</p>

<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

  <footer>
    <p>Escriba su nombre</p>
  </footer>
</body>
</html>
