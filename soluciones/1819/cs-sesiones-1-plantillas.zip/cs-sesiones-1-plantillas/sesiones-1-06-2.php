<?php
/**
 * Sesiones (1) 06 - sesiones-1-06-2.php
 *
 * @author    Escriba su nombre
 *
 */

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";
