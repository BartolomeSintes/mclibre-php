<?php
/**
 * Sesiones (1) 05 - sesiones-1-05-2.php
 *
 * @author    Escriba su nombre
 *
 */

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";
