<?php
/**
 * Sesiones (1) 03 - sesiones-1-03-2.php
 *
 * @author    Escriba su nombre
 *
 */

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";
