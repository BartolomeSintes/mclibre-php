<?php
/**
 * Sesiones (1) 04 - sesiones-1-04-2.php
 *
 * @author    Escriba su nombre
 *
 */

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";
