<?php
/**
 * Sesiones (1) 12 - sesiones-1-12-2.php
 *
 * @author    Escriba su nombre
 *
 */

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";
