<?php
/**
 * Convertidor de distancias (1) JSON-RPC- funciones-1-2.php
 *
 * @author    Escriba su nombre
 *
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>
    Convertidor de distancias (1) JSON-RPC (Resultado).
    Funciones (1). Funciones.
    Escriba su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color" />
</head>

<body>
  <h1> Convertidor de distancias (Resultado)</h1>

<?php
function recoge($var)
{
    $tmp = (isset($_REQUEST[$var]))
    ? trim(htmlspecialchars($_REQUEST[$var], ENT_QUOTES, "UTF-8"))
    : "";
    return $tmp;
}

$unidades = ["km", "m", "cm"];

$camino = "http://localhost/apuntes/php/ejercicios/funciones/funciones-1/";

$numero  = recoge("numero");
$inicial = recoge("inicial");
$final   = recoge("final");

$numeroOk  = false;
$inicialOk = false;
$finalOk   = false;

if ($numero == "") {
    print "  <p class=\"aviso\">No ha escrito nada.</p>\n";
    print "\n";
} elseif (!is_numeric($numero)) {
    print "  <p class=\"aviso\">No ha escrito un número.</p>\n";
    print "\n";
} else {
    $numeroOk = true;
}

if (!in_array($inicial, $unidades)) {
    print "  <p class=\"aviso\">No ha elegido una unidad inicial válida.</p>\n";
    print "\n";
} else {
    $inicialOk = true;
}

if (!in_array($final, $unidades)) {
    print "  <p class=\"aviso\">No ha elegido una unidad final válida.</p>\n";
    print "\n";
} else {
    $finalOk = true;
}

if ($numeroOk && $inicialOk && $finalOk) {
    $id = rand();
    $consulta = http_build_query(["jsonrpc" => "2.0", "method" => "convertir", "params" => ["from" => $inicial, "into" => $final, "value" => $numero], "id" => $id]);
    $respuesta = json_decode(file_get_contents("{$camino}funciones-1-rpc.php?$consulta"), true);
    if ($respuesta["id"] == $id) {
        if (isset($respuesta["error"])) {
            print "  <p class=\"aviso\">Error en la petición.</p>\n";
            print "\n";
        } else {
            $resultado = $respuesta["result"];
            print "  <p>$numero $inicial = $resultado $final.</p>\n";
            print "\n";
        }
    } else {
        print "  <p class=\"aviso\">La respuesta no corresponde a la petición.</p>\n";
        print "\n";
    }
}
?>
  <p><a href="funciones-1-rpc-1.php">Volver al formulario.</a></p>

  <footer>
    <p>Escriba su nombre</p>
  </footer>
</body>
</html>
