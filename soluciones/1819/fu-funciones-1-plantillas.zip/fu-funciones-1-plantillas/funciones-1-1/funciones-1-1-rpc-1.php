<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Convertidor de distancias (1) JSON-RPC (Formulario).
    Funciones (1). Funciones.
    Escriba su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Convertidor de distancias (Formulario)</h1>

  <form action="funciones-1-1-rpc-2.php" method="get">
    <p>
      Quiero convertir:
      <input type="number" name="numero" size="40">
      <select name="inicial">
        <option value="km">km</option>
        <option value="m">m</option>
        <option value="cm">cm</option>
      </select>
      a
      <select name="final">
        <option value="km">km</option>
        <option value="m" selected>m</option>
        <option value="cm">cm</option>
      </select>
    </p>

    <p>
      <input type="submit" value="Convertir">
      <input type="reset" value="Borrar">
    </p>
  </form>

  <footer>
    <p>Escriba su nombre</p>
  </footer>
</body>
</html>
