<?php
/**
 * Convertidor de distancias (1) Servicio web - funciones-1-1-biblioteca.php
 *
 * @author    Escriba su nombre
 *
 */

$num    = $_REQUEST["value"];
$uniOri = $_REQUEST["from"];
$uniFin = $_REQUEST["into"];

// La unidad intermedia es el metro
$numeroIntermedio = 0;
if ($uniOri == "km") {
    $numeroIntermedio = $num * 1000;
} elseif ($uniOri == "m") {
    $numeroIntermedio = $num;
} elseif ($uniOri == "cm") {
    $numeroIntermedio = $num / 100;
}

if ($uniFin == "km") {
    $numeroFinal = $numeroIntermedio / 1000;
} elseif ($uniFin == "m") {
    $numeroFinal = $numeroIntermedio;
} elseif ($uniFin == "cm") {
    $numeroFinal = $numeroIntermedio * 100;
}

print $numeroFinal;
