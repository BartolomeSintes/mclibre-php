<?php
/**
 * Sesiones (2) 01 - sesiones-2-02-1.php
 *
 * @author    Escriba su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>
    Formulario de confirmación (Formulario 1).
    Sesiones (2). Sesiones.
    Ejercicios. PHP. Bartolomé Sintes Marco. www.mclibre.org
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color" />
</head>

<body>
  <h1>Formulario de confirmación (Formulario 1)</h1>

  <form action="sesiones-2-02-2.php" method="get">
    <p>Escriba una palabra (con letras mayúsculas, letras minúsculas y números):</p>

<?php

print "<!-- Ejercicio incompleto -->\n";
print "\n";

print "    <p><strong>Palabra:</strong> <input type=\"text\" name=\"palabra1\" size=\"20\" maxlength=\"20\" /></p>\n";
print "\n";

?>
    <p><input type="submit" value="Siguiente" />
      <input type="reset" value="Borrar" /></p>
  </form>

  <footer>
    <p>Escriba su nombre</p>
  </footer>
</body>
</html>
