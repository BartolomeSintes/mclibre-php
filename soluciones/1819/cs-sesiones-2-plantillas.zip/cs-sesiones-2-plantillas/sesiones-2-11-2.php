<?php
/**
 * Sesiones (2) 11 - sesiones-2-11-2.php
 *
 * @author    Escriba su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>
    Comprobación en formulario.
    Sesiones (2) 011 . Sesiones.
    Ejercicios. PHP. Bartolomé Sintes Marco
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color" />
</head>

<body>
  <h1>Comprobación en formulario</h1>

<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

  <p><a href="sesiones-2-11-1.php">Volver al inicio.</a></p>

  <footer>
    <p>Escriba su nombre</p>
  </footer>
</body>
</html>
