<?php
/**
 * Sesiones (2) 11 - sesiones-2-11-1.php
 *
 * @author    Escriba su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>
    Comprobación en formulario.
    Sesiones (2). Sesiones.
    Ejercicios. PHP. Bartolomé Sintes Marco
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" type="text/css" href="mclibre-php-ejercicios.css" title="Color" />
</head>

<body>
  <h1>Comprobación en formulario</h1>

  <form action="sesiones-2-11-2.php" method="get">
<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

    <p>
      <input type="submit" value="Comprobar" />
      <input type="reset" value="Borrar" />
    </p>
  </form>

  <footer>
    <p>Escriba su nombre</p>
  </footer>
</body>
</html>
