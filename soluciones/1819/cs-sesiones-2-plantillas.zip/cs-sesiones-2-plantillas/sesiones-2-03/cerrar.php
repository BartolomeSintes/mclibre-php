<?php
/**
 * Sesiones (2) 03 - cerrar.php
 *
 * @author    Escriba su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
