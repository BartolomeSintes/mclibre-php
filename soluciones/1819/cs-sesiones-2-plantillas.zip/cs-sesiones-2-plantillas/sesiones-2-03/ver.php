<?php
/**
 * Sesiones (2) 03 - ver.php
 *
 * @author    Escriba su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Ver datos.
    Sesiones (2). Sesiones.
    Ejercicios. PHP. Bartolomé Sintes Marco. www.mclibre.org
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Ver datos</h1>

<?php

print "<!-- Ejercicio incompleto -->\n";
print "\n";

?>

  <p><a href="index.php">Volver al inicio.</a></p>

  <footer>
    <p>Escriba su nombre</p>
  </footer>
</body>
</html>
