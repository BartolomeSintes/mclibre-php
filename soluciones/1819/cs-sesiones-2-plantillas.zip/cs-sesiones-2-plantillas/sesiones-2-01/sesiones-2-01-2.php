<?php
/**
 * Sesiones (2) 01 - sesiones-2-01-2.php
 *
 * @author    Escriba su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
