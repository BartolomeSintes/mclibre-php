<?php
/**
 * Sesiones (2) 12 - sesiones-2-12-2.php
 *
 * @author    Escriba su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
