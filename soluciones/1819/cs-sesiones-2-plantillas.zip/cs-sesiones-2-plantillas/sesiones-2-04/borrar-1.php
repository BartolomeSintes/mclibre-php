<?php
/**
 * Sesiones (2) 04 - borrar-1.php
 *
 * @author    Escriba su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>
    Borrar datos (1).
    Sesiones (2). Sesiones.
    Ejercicios. PHP. Bartolomé Sintes Marco
</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" type="text/css" href="mclibre-php-ejercicios.css" title="Color" />
</head>

<body>
  <h1>Borrar datos (1)</h1>

<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

  <p><a href="index.php">Volver al inicio.</a></p>

  <footer>
    <p>Escriba su nombre</p>
  </footer>
</body>
</html>
