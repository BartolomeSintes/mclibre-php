<?php
/**
 * Sesiones (2) 04 - cerrar.php
 *
 * @author    Escriba su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
