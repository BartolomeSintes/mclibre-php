<?php
/**
 * Seleccione dibujos - matrices-1-12-2.php
 *
 * @author    Escriba su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
