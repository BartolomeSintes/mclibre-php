<?php
/**
 * Sesiones (2) 12 - matrices-1-01-2.php
 *
 * @author    Escriba su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
