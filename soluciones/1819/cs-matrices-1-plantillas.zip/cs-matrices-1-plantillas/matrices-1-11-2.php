<?php
/**
 * Elimine dibujos - matrices-1-11-2.php
 *
 * @author    Escriba su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";
