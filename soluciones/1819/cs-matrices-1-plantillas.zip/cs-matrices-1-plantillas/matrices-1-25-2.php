<?php
/**
 * Tabla con casillas de verificación (Resultado) - matrices-1-25-2.php
 *
 * @author    Escriba su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Tabla cuadrada con casillas de verificación (Resultado).
    foreach (1). Sesiones.
    Escriba su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Tabla cuadrada con casillas de verificación (Resultado)</h1>

<?php

print "/* Ejercicio incompleto */\n";

?>
  <p><a href="matrices-1-25-1.php">Volver al formulario.</a></p>

  <footer>
    <p>Escriba su nombre</p>
  </footer>
</body>
</html>
