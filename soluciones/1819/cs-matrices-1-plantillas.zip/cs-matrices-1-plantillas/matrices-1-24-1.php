<?php
/**
 * Hombres y mujeres (Formulario) - matrices-1-24-1.php
 *
 * @author    Escriba su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Hombres y mujeres (Formulario).
    foreach (1). Sesiones.
    Escriba su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Hombres y mujeres (Formulario)</h1>

  <p>Escriba un nombre propio en cada caja de texto y si se trata de un hombre o de una mujer.</p>

  <form action="matrices-1-24-2.php" method="get">
    <table>
      <tbody>

<?php

print "/* Ejercicio incompleto */\n";

?>
      </tbody>
    </table>

    <p>
      <input type="submit" value="Contar">
      <input type="reset" value="Borrar">
    </p>
  </form>

  <footer>
    <p>Escriba su nombre</p>
  </footer>
</body>
</html>
