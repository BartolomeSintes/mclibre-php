<?php
/**
 * Sesiones Minijuegos (3) 2 - minijuegos-3-2-1.php
 *
 * @author Escriba aquí su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Carrera de puntos.
    Sesiones (1). Sesiones.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Carrera de puntos</h1>

  <form action="minijuegos-3-2-2.php" method="get">
    <p>Haga clic en los botones para tirar el dado y mover el punto:</p>

<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

    <p>
      <button type="submit" name="accion" value="empezar">Volver a empezar</button>
    </p>
  </form>

  <footer>
  <p>Escriba aquí su nombre</p>
</footer>
</body>
</html>
