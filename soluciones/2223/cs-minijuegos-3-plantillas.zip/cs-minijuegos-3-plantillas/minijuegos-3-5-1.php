<?php
/**
 * Sesiones Minijuegos (3) 5 - minijuegos-3-5-1.php
 *
 * @author Escriba aquí su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Mueve fichas.
    Minijuegos (3). Sesiones.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
  <style>
      table { border-collapse: collapse; }
      td { border: black 2px solid; width: 60px; height: 60px; }
      button { background-color: transparent; border: none; }
  </style>
</head>

<body>
  <h1>Mueve fichas</h1>

  <p>El objetivo del juego es mover las tres fichas hasta la casilla de la derecha. Elija en cada turno una ficha y se desplazará hacia la meta tantas casillas como marque el dado.</p>

  <form action="minijuegos-3-5-2.php" method="get">

<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
  </form>

  <footer>
  <p>Escriba aquí su nombre</p>
</footer>
</body>
</html>