<?php
/**
 * Sesiones Minijuegos (3) 4 - minijuegos-3-4-2.php
 *
 * @author Escriba aquí su nombre
 *
 */

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";
