<?php
/**
 * @author Escriba aquí su nombre
 */

require_once "biblioteca.php";

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

$nombre    = recoge("nombre");
$apellidos = recoge("apellidos");

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

    print "    <p>Registros encontrados:</p>\n";
    print "\n";
    print "    <table class=\"conborde franjas\">\n";
    print "      <thead>\n";
    print "        <tr>\n";
    print "          <th>Nombre</th>\n";
    print "          <th>Apellidos</th>\n";
    print "        </tr>\n";
    print "      </thead>\n";

    print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

    print "    </table>\n";


print "<p class=\"aviso\">Ejercicio incompleto</p>\n";
