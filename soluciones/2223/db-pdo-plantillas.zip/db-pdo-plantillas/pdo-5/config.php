<?php
/**
 *
 * @author Escriba aquí su nombre
 */

// MYSQL: OPCIONES DE CONFIGURACIÓN DEL PROGRAMA
