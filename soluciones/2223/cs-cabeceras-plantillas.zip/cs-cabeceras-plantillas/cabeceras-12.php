<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Imagen.
    Cabeceras. Sesiones.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Imagen</h1>

  <p><img src="cabeceras-12-svg.php" alt="imagen" width="150" height="150"></p>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
