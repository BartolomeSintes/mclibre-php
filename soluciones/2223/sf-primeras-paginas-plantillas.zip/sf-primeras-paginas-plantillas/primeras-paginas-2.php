<?php
/**
 * Primeras páginas. Sin formularios. 2 - primeras-paginas-2.php
 *
 * @author Escriba aquí su nombre
 *
 */

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
