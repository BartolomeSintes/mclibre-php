<?php
/**
 * Primeras páginas. Sin formularios. 1 - primeras-paginas-1.php
 *
 * @author Escriba aquí su nombre
 *
 */

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>