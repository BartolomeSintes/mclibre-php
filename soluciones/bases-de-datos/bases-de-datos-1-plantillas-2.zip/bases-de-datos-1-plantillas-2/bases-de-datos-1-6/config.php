<?php
/**
 * @author Escriba aquí su nombre
 */

// VARIABLES CONFIGURABLES POR EL ADMINISTRADOR DE LA APLICACIÓN

// Base de datos utilizada por la aplicación

$cfg["dbMotor"] = SQLITE;                                   // Valores posibles: MYSQL o SQLITE

// Configuración para SQLite

$cfg["sqliteDatabase"] = "";            // Ubicación de la base de datos

// Configuración para MySQL

$cfg["mysqlHost"]     = "";             // Nombre de host
$cfg["mysqlUser"]     = "";             // Nombre de usuario
$cfg["mysqlPassword"] = "";             // Contraseña de usuario
$cfg["mysqlDatabase"] = "";             // Nombre de la base de datos

// Tamaño de los campos en la tabla Personas

$cfg["tablaPersonasTamNombre"]    = 40;                     // Tamaño de la columna Personas > Nombre
$cfg["tablaPersonasTamApellidos"] = 60;                     // Tamaño de la columna Personas > Apellidos

// Tamaño de los controles en los formularios

$cfg["formPersonasTamNombre"]    = $cfg["tablaPersonasTamNombre"];     // Tamaño de la caja de texto Personas > Nombre
$cfg["formPersonasTamApellidos"] = $cfg["tablaPersonasTamApellidos"];  // Tamaño de la caja de texto Personas > Apellidos

// Método de envío de formularios

$cfg["formMethod"] = "get";                                 // Valores posibles: get o post
