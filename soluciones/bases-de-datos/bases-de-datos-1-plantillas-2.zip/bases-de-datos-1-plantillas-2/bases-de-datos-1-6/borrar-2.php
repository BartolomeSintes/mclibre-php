<?php
/**
 * @author Escriba aquí su nombre
 */

require_once "biblioteca.php";

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";
