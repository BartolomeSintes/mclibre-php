<?php
/**
 * @author Escriba aquí su nombre
 */

require_once "biblioteca.php";

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

    print "    <form action=\"modificar-2.php\" method=\"$cfg[formMethod]\">\n";
    print "      <p>Indique el registro que quiera modificar:</p>\n";
    print "\n";
    print "      <table class=\"conborde franjas\">\n";
    print "        <thead>\n";
    print "          <tr>\n";
    print "            <th>Modificar</th>\n";
    print "            <th>Nombre</th>\n";
    print "            <th>Apellidos</th>\n";
    print "          </tr>\n";
    print "        </thead>\n";

    print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

    print "      </table>\n";
    print "\n";
    print "      <p>\n";
    print "        <input type=\"submit\" value=\"Modificar registro\">\n";
    print "        <input type=\"reset\" value=\"Reiniciar formulario\">\n";
    print "      </p>\n";
    print "    </form>\n";

    print "<p class=\"aviso\">Ejercicio incompleto</p>\n";
