<?php
/**
 * @author Escriba aquí su nombre
 */

require_once "biblioteca.php";

$borrar = recoge("borrar", default: "No", allowed: ["No", "Sí"]);

if ($borrar != "Sí") {
    header("Location:index.php");
    exit;
}

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";
