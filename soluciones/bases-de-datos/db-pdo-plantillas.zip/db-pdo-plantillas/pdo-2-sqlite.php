<?php
/**
 *
 * @author Escriba aquí su nombre
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>SQLite (2). PDO. Ejercicios (bases de datos). Escriba aquí su nombre</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-proyectos.css" title="Color">
</head>

<body>
  <h1>PDO 2 - SQLite: programa con funciones</h1>

   <main>
<?php

// SQLITE: FUNCIÓN DE CONEXIÓN CON LA BASE DE DATOS

function conectaDb()
{
}

// FUNCIÓN DE BORRADO Y CREACIÓN DE TABLA

function borraTodo()
{
}

// FUNCIÓN DE INSERCIÓN DE REGISTRO

function insertaRegistro($nombre, $apellidos)
{
}

// FUNCIÓN DE CONTEO DE REGISTROS

function cuentaRegistros()
{
}

// FUNCIÓN DE SELECCIÓN DE TODOS LOS REGISTROS

function muestraRegistros()
{
}

// FUNCIÓN DE MODIFICACIÓN DE REGISTRO

function modificaRegistro($id, $nombre, $apellidos)
{
}

// FUNCIÓN DE BORRADO DE REGISTROS

function borraRegistros($id)
{
}

// SQLITE: OPCIONES DE CONFIGURACIÓN DEL PROGRAMA


// PROGRAMA

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
  </main>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
