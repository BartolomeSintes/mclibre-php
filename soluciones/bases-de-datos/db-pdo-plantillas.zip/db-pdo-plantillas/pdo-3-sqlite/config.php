<?php
/**
 *
 * @author Escriba aquí su nombre
 */

// Variables configurables por el administrador de la aplicación
