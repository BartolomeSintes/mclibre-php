<?php
/**
 *
 * @author Escriba aquí su nombre
 */

// SQLITE: OPCIONES DE CONFIGURACIÓN DEL PROGRAMA

