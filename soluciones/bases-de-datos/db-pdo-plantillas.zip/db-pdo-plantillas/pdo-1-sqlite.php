<?php
/**
 * @author Escriba aquí su nombre
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>SQLite (1). PDO. Ejercicios (bases de datos). Escriba aquí su nombre</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-proyectos.css" title="Color">
</head>

<body>
  <h1>PDO 1 - SQLite: programa único</h1>

  <main>
<?php

// PASO 1: Definir las opciones del programa



// PASO 2: Crear el objeto PDO de conexión con la base de datos.



// PASO 3: Borrar la tabla.



// PASO 4: Crear la tabla.



// PASO 5: Insertar un registro en la tabla.



// PASO 6: Mostrar cuántos registros hay en la tabla.



// PASO 7: Mostrar los valores del registro guardado en la tabla.



// PASO 8: Modificar el registro guardado en la tabla.



// PASO 9: Mostrar los valores del registro guardado en la tabla.



// PASO 10: Insertar un segundo registro en la tabla.



// PASO 11: Mostrar cuántos registros hay en la tabla.



// PASO 12: Mostrar los valores de los dos registros guardados en la tabla.



// PASO 13: Borrar el primer registro guardado en la tabla.



// PASO 14: Mostrar los valores del registro guardado en la tabla.

?>
  </main>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
