<?php
/**
 *
 * @author Escriba aquí su nombre
 */

// SQLITE: DEFINICIONES ESPECÍFICAS

