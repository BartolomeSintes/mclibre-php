<?php
/**
 *
 * @author Escriba aquí su nombre
 */

// Constantes configurables por el programador de la aplicación



// Variables configurables por el administrador de la aplicación



// Variables configurables por el programador de la aplicación



// Carga Biblioteca específica de la base de datos utilizada



// Funciones comunes
