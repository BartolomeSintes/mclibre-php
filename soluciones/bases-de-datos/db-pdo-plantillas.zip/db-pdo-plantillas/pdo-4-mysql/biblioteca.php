<?php
/**
 *
 * @author Escriba aquí su nombre
 */

// Variables configurables por el administrador de la aplicación



// Variables configurables por el programador de la aplicación



// FUNCIONES ESPECÍFICAS DE LA BASE DE DATOS MYSQL

// MYSQL: FUNCIÓN DE CONEXIÓN CON LA BASE DE DATOS

function conectaDb()
{
}

// MYSQL: FUNCIÓN DE BORRADO Y CREACIÓN DE TABLA

function borraTodo()
{
}

// FUNCIÓN DE INSERCIÓN DE REGISTRO

function insertaRegistro($nombre, $apellidos)
{
}

// FUNCIÓN DE CONTEO DE REGISTROS

function cuentaRegistros()
{
}

// FUNCIÓN DE SELECCIÓN DE TODOS LOS REGISTROS

function muestraRegistros()
{
}

// FUNCIÓN DE MODIFICACIÓN DE REGISTRO

function modificaRegistro($id, $nombre, $apellidos)
{
}

// FUNCIÓN DE BORRADO DE REGISTROS

function borraRegistros($id)
{
}
