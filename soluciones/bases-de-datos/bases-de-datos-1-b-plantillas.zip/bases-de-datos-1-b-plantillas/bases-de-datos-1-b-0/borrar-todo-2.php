<?php
/**
 * @author Escriba aquí su nombre
 */

require_once "biblioteca.php";

$borrar = recoge("borrar", default: "No", allowed: ["No", "Sí"]);

if ($borrar != "Sí") {
    header("Location:index.php");
    exit;
}

$pdo = conectaDb();

cabecera("Borrar todo 2", MENU_VOLVER);

borraTodo();

pie();
