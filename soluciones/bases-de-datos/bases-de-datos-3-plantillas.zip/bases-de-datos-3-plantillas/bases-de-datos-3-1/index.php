<?php
/**
 * @author Escriba aquí su nombre
 */

print "<!-- Ejercicio incompleto -->\n";