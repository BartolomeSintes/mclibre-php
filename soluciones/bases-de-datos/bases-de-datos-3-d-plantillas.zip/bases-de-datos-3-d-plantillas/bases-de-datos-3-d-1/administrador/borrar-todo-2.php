<?php
/**
 * @author Escriba aquí su nombre
 */

require_once "../comunes/biblioteca.php";
require_once "../comunes/demo.php";

session_name($cfg["sessionName"]);
session_start();

if (!isset($_SESSION["conectado"]) || $_SESSION["nivel"] < NIVEL_ADMINISTRADOR) {
    header("Location:../index.php");
    exit;
}

$borrar = recoge("borrar", default: "No", allowed: ["No", "Sí"]);
$demo   = recoge("demo", default: "No", allowed: ["No", "Sí"]);

if ($borrar != "Sí") {
    header("Location:index.php");
    exit;
}

$pdo = conectaDb();

cabecera("Administrador - Borrar todo 2", MENU_ADMINISTRADOR, PROFUNDIDAD_1);

borraTodo();

if ($demo == "Sí") {
    insertaDemo();
}

pie();
