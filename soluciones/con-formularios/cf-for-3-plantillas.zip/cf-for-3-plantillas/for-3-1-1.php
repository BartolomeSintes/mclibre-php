<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Tabla de una fila (Formulario).
    for (3). Con formularios.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Tabla de una fila (Formulario)</h1>

  <form action="for-3-1-2.php" method="get">
    <p>Escriba un número (0 &lt; número &le; 200) y mostraré una tabla de una
      fila y tantas columnas como indique.
    </p>

    <p><label>Número de columnas: <input type="text" name="columnas" min="1" max="200" value="10"></label></p>

    <p>
      <input type="submit" value="Mostrar">
      <input type="reset">
    </p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
