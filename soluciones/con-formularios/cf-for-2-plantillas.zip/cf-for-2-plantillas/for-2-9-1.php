<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Triángulo de estrellas 5 (Formulario). for (2).
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Triángulo de estrellas 5 (Formulario)</h1>

  <form action="for-2-9-2.php" method="get">
    <p>Escriba el alto (0 &lt; alto &le; 100) y mostraré un triángulo de estrellas de ese tamaño.</p>

    <table>
      <tr>
        <td><strong>Alto:</strong></td>
        <td><input type="number" name="alto" min="1" max="100" value="6"></td>
      </tr>
    </table>

    <p>
      <input type="submit" value="Dibujar">
      <input type="reset">
    </p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>

