<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Letrero 1 (Formulario).
    Controles en formularios (1). Con formularios.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Letrero 1 (Formulario)</h1>

  <form action="controles-formularios-1-6-2.php" method="get">
    <p>Indique el texto y tamaño a mostrar:</p>

    <table>
      <tr>
        <td>Texto:</td>
        <td><textarea name="info[1]" rows="4" cols="40"></textarea></td>
      </tr>
      <tr>
        <td>Tamaño:</td>
        <td><input type="number" name="info[2]" min="20" value="80"></td>
      </tr>
    </table>

    <p>
      <input type="submit" value="Enviar">
      <input type="reset">
    </p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
