<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Ecuación de segundo grado (Formulario).
    Repaso (1). Recapitulación.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Ecuación de segundo grado (Formulario)</h1>

  <form action="segundo-grado-2.php" method="get">
    <p>Dado la ecuación de segundo grado <span style="font-size: 200%">a.x<sup>2</sup> + b.x + c = 0</span>, escriba los valores de los tres coeficientes y resolveré la ecuación:</p>

    <table>
      <tr>
        <td><strong>a:</strong></td>
        <td><input type="number" name="a" step="any"></td>
      </tr>
      <tr>
        <td><strong>b:</strong></td>
        <td><input type="number" name="b" step="any"></td>
      </tr>
      <tr>
        <td><strong>c:</strong></td>
        <td><input type="number" name="c" step="any"></td>
      </tr>
    </table>

    <p>
      <input type="submit" value="Resolver">
      <input type="reset">
    </p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
