<?php
/**
 * Encuesta (Resultado 2) - foreach-1-3-3.php
 *
 * @author Escriba aquí su nombre
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Encuesta (Resultado 2).
    foreach (1).
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Encuesta (Resultado 2)</h1>

<?php
// Funciones auxiliares
function recoge($var, $m = "")
{
    if (!isset($_REQUEST[$var])) {
        $tmp = (is_array($m)) ? [] : "";
    } elseif (!is_array($_REQUEST[$var])) {
        $tmp = trim(htmlspecialchars($_REQUEST[$var], ENT_QUOTES, "UTF-8"));
    } else {
        $tmp = $_REQUEST[$var];
        array_walk_recursive($tmp, function (&$valor) {
            $valor = trim(htmlspecialchars($valor, ENT_QUOTES, "UTF-8"));
        });
    }
    return $tmp;
}

// Recogida de datos SIN verificación
$preguntas    = recoge("preguntas");
$respuestas   = recoge("respuestas");
$b            = recoge("b", []);
$preguntasOk  = true;
$respuestasOk = true;
$bOk          = true;

// Si el número de preguntas y respuestas recibido y los botones radio recibidos con correctos ...
if ($preguntasOk && $respuestasOk && $bOk) {
    print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";
}

// Enlace a la página 2 enviando el control numero con su valor para que pueda
// dibujar la tabla
if ($preguntasOk && $respuestasOk) {
    print "  <p><a href=\"foreach-1-3-2.php?preguntas=$preguntas&amp;respuestas=$respuestas\">Volver a la tabla</a></p>\n";
}

?>

  <p><a href="foreach-1-3-1.php">Volver al formulario inicial.</a></p>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>