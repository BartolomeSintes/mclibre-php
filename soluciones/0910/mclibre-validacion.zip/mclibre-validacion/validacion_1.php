<?php
/**
 * Formulario y resultado en un �nico archivo - validacion_1.php
 * 
 * @author    Bartolom� Sintes Marco <bartolome.sintes+mclibre@gmail.com>
 * @copyright 2010 Bartolom� Sintes Marco
 * @license   http://www.gnu.org/licenses/agpl.txt AGPL 3 or later
 * @version   2010-03-23
 * @link      http://www.mclibre.org
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

function recoge($var)
{ 
    $tmp = (isset($_REQUEST[$var])) ? trim(strip_tags($_REQUEST[$var])) : '';
    if (get_magic_quotes_gpc()) {
        $tmp = stripslashes($tmp);
    }
    $tmp = str_replace('&', '&amp;',  $tmp);
    $tmp = str_replace('"', '&quot;', $tmp);
    return $tmp;
}

function cabecera($texto)
{ print "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?".">
<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\"
  \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">
<html xmlns=\"http://www.w3.org/1999/xhtml\">
<head>
  <meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\" />
  <title>$texto. Validaci�n. Ejercicios. PHP. Bartolom� Sintes Marco</title>
  <link href=\"mclibre_php_soluciones.css\" rel=\"stylesheet\" type=\"text/css\" 
  title=\"Color\" />
</head>\n\n<body>\n<h1>$texto</h1>\n";
}

define('FORM_METHOD',  'get');
define('TAM_NOMBRE',   40);
define('TAM_TELEFONO', 9);
define('TAM_CORREO',   40);

$nombre   = recoge('nombre');
$telefono = recoge('telefono');
$correo   = recoge('correo');

if (isset($_REQUEST['enviar'])) {
    cabecera("Formulario y resultado en un �nico archivo (Resultado)");
    print"  <p>Se han recibido los datos siguientes:</p>
  <p>Nombre:<strong>$nombre</strong></p>
  <p>Tel�fono:<strong>$telefono</strong></p>
  <p>Correo:<strong>$correo</strong></p>    
  <p><a href=\"$_SERVER[PHP_SELF]\">Volver al formulario</a></p>\n";
} else {
    cabecera("Formulario y resultado en un �nico archivo (Formulario)");
    print"<p>Escriba los datos siguientes:</p>\n";
    print "<form action=\"$_SERVER[PHP_SELF]\" method=\"".FORM_METHOD."\">
  <table>\n    <tbody>\n      <tr>\n        <td>Nombre:</td>
        <td><input type=\"text\" name=\"nombre\" size=\"".TAM_NOMBRE."\" 
          maxlength=\"".TAM_NOMBRE."\" />";
    print "</td>\n      </tr>\n      <tr>\n        <td>Tel�fono:</td>
        <td><input type=\"text\" name=\"telefono\" size=\"".TAM_TELEFONO."\" 
          maxlength=\"".TAM_TELEFONO."\" />";
    print "</td>\n      </tr>\n      <tr>\n        <td>Correo:</td>
        <td><input type=\"text\" name=\"correo\" size=\"".TAM_CORREO."\" 
          maxlength=\"".TAM_CORREO."\" />";
    print "</td>\n      </tr>\n    </tbody>\n  </table>
  <p class=\"der\"><input type=\"submit\" name=\"enviar\" value=\"Enviar\" /></p>
</form>\n";
}
print '<address>
  Esta p�gina forma parte del curso "P�ginas web con PHP" disponible en <a
  href="http://www.mclibre.org/">http://www.mclibre.org</a><br />
  Autor: Bartolom� Sintes Marco<br />
  �ltima modificaci�n de esta p�gina: 23 de marzo de 2010
</address>

<p class="licencia">El programa PHP que genera esta p�gina est� bajo 
<a rel="license" href="http://www.gnu.org/licenses/agpl.txt">licencia AGPL 3 o
posterior</a>.</p>
</body>
</html>';
/*
 * 2008-01-22
 * Este print est� con comillas para poder buscar y sustituir el contenido
 * junto con el resto de ficheros.
 * Tambi�n podr�a ponerlo fuera del bloque PHP, pero entonces Eclipse dice
 * que hay un error en la p�gina.
 */
?>
