<?php
/**
 * Blog - anyadir.php
 * 
 * @author    Bartolom� Sintes Marco <bartolome.sintes+mclibre@gmail.com>
 * @copyright 2010 Bartolom� Sintes Marco
 * @license   http://www.gnu.org/licenses/agpl.txt AGPL 3 or later
 * @version   2010-04-28
 * @link      http://www.mclibre.org
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

include('funciones.php');
$db = conectaDb();

// Si la fecha no es correcta, se deja vac�a. 
// Si la fecha es correcta se recoge con recogeFecha
// Es para evitar que si un usuario malicioso env�a una fecha incorrecta
// se guarde con la fecha del d�a de hoy (ya que recogeFecha pone la fecha de 
// hoy si la fecha es incorrecta
$fecha = quitaComillasExteriores(recogeParaConsulta($db, 'fecha'));
if (!checkdate((int)substr($fecha, 5, 2), (int)substr($fecha, 8, 2), 
                    (int)substr($fecha, 0, 4))) {
    $fecha = '';
} else {
    $fecha = recogeFecha($db, 'fecha');
}
$entrada = recogeParaConsulta($db, 'entrada');

cabecera('A�adir', CABECERA_SIN_CURSOR, $fecha);

if ($fecha=="") {
    print "<p>Fecha incorrecta. No se ha guardado el registro.</p>\n";
} elseif ($entrada=="''") {
    print "<p>Hay que escribir algo en la entrada. "
        ."No se ha guardado el registro.</p>\n";
} else {
    $consulta = "SELECT COUNT(*) FROM $dbEntradas";
    $result = $db->query($consulta);
    if (!$result) {
        print "<p>Error en la consulta.</p>\n";
    } elseif ($result->fetchColumn()>=MAX_REG_ENTRADAS) {
        print "<p>Se ha alcanzado el n�mero m�ximo de registros que se pueden "
            ."guardar.</p>\n<p>Por favor, borre alg�n registro antes.</p>\n";
    } else { 
        $consulta = "SELECT COUNT(*) FROM $dbEntradas 
            WHERE fecha='$fecha'";
        $result = $db->query($consulta);
        if (!$result) {
            print "<p>Error en la consulta.</p>\n";
        } elseif ($result->fetchColumn()==0) {
            $consulta = "INSERT INTO $dbEntradas 
                VALUES (NULL, '$fecha', $entrada)";
            if ($db->query($consulta)) {
                print "<p>Registro creado correctamente.</p>\n";
            } else {
                print "<p>Error al crear el registro.<p>\n";
            }
        } else { 
            $consulta = "UPDATE $dbEntradas 
                SET entrada=$entrada 
                WHERE fecha='$fecha'";
           if ($db->query($consulta)) {
                print "<p>Registro creado correctamente.</p>\n";
            } else {
                print "<p>Error al crear el registro.<p>\n";
            }
        }
    }
}

$db = NULL; 
pie();
?>
