<?php
/**
 * Primeras páginas. Sin formularios. 3-2 - primeras-paginas-3-2.php
 *
 * @author Escriba aquí su nombre
 *
 */
?>
<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
  <title>
    Primeras páginas 3-2.
    Primeras páginas. Sin formularios.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="" title="Color">
</head>

<body>
<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
