<?php
/**
 * Primeras páginas. Sin formularios. 3-1 - primeras-paginas-3-1.php
 *
 * @author Escriba aquí su nombre
 *
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="" title="Color">
</head>

<body>
<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
