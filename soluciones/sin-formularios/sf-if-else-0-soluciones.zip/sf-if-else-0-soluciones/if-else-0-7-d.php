<?php
/**
 * if ... else ... (0) 7 D - if-else-0-7-d.php
 *
 * @author    Bartolomé Sintes Marco <bartolome.sintes+mclibre@gmail.com>
 * @copyright 2025 Bartolomé Sintes Marco
 * @license   http://www.gnu.org/licenses/agpl.txt AGPL 3 or later
 * @version   2025-02-08
 * @link      https://www.mclibre.org
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Convertidor de cm a km, m y cm (con comas e "y").
    if .. elseif ... else ... (0). Sin formularios.
    Ejercicios. PHP. Bartolomé Sintes Marco. www.mclibre.org
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Convertidor de centímetros a kilómetros, metros y centímetros (con comas e "y")</h1>

  <p>Actualice la página para mostrar una nueva conversión.</p>

<?php
$centimetros = rand(0, 200000);

$km = intdiv($centimetros, 100000);
$cm = $centimetros % 100000;
$m  = intdiv($cm, 100);
$cm = $cm % 100;

print "  <p>$centimetros centímetros son";

if ($centimetros == 0) {
    print " 0 cm</p>\n";
    print "\n";
} else {
    if ($km != 0) {
        print " $km km";
        if ($m != 0 && $cm == 0 || $m == 0 && $cm != 0) {
            print " y";
        } elseif ($m != 0 || $cm != 0) {
            print ",";
        }
    }

    if ($m != 0) {
        print " $m m";
        if ($cm != 0) {
            print " y";
        }
    }

    if ($cm != 0) {
        print " $cm cm";
    }
    print ".</p>\n";
    print "\n";
}
?>
  <footer>
    <p class="ultmod">
      Última modificación de esta página:
      <time datetime="2025-02-08">8 de febrero de 2025</time>
    </p>

    <p class="licencia">
      Este programa forma parte del curso <strong><a href="https://www.mclibre.org/consultar/php/">Programación
      web en PHP</a></strong> de <a href="https://www.mclibre.org/" rel="author">Bartolomé Sintes Marco</a>.<br>
      El programa PHP que genera esta página se distribuye bajo
      <a rel="license" href="http://www.gnu.org/licenses/agpl.txt">licencia AGPL 3 o posterior</a>.
    </p>
  </footer>
</body>
</html>
