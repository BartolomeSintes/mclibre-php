<?php
/**
 * for (2) 08 - for-2-08.php
 *
 * @author Escriba aquí su nombre
 *
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Arco iris semicircular.
    for (2). Sin formularios.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Arco iris semicircular</h1>

  <p>Actualice la página para mostrar un nuevo dibujo.</p>

<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
