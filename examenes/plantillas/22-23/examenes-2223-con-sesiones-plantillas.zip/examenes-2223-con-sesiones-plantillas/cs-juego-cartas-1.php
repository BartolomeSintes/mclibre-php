<?php
/**
 * Examen - cs-juego-cartas-1.php
 *
 * @author Escriba aquí su nombre
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color" />
</head>

<body>
  <h1>Juego de cartas</h1>

  <p>Haga clic en una de las cartas para cambiarla o en el botón Todas para cambiar las dos. El jugador que sume más puntos gana el punto. El jugador que llegue el primero a 5 puntos, gana la partida.</p>

  <form action="cs-juego-cartas-2.php">

  <?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
    <p><button type="submit" name="accion" value="empezar">Volver a empezar</button></p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
