<?php
/**
 * examen - cs-juego-dados-2.php
 *
 * @author Escriba aquí su nombre
 */

print "<!-- Ejercicio incompleto -->\n";
