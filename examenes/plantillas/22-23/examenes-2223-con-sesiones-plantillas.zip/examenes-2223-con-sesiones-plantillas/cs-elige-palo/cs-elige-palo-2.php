<?php
/**
 * Examen - cs-elige-palo-2.php
 *
 * @author Escriba aquí su nombre
 */

print "<!-- Ejercicio incompleto -->\n";
