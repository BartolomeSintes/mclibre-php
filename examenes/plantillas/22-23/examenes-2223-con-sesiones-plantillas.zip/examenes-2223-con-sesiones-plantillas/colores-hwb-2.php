<?php
/**
 * Colores HWB- colores-hwb-2.php
 *
 * @author Escriba aquí su nombre
 */

print "<!-- Ejercicio incompleto -->\n";
