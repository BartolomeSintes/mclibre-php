<?php
/**
 * Examen - cs-colores-hwb-1.php
 *
 * @author Escriba aquí su nombre
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Colores HWB.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
  <style>
    p.cuadro { text-align: center; line-height: 100px; vertical-align: middle; font-size: 200%; width: 400px; height: 100px; border: black 2px solid;  }
  </style>
</head>

<body>
  <h1>Colores HWB</h1>

  <p>Haga clic en los botones para cambiar el color.</p>

  <form action="cs-colores-hwb-2.php">
<?php

print "    <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
    <table>
      <tr>
        <td>Matiz (Hue):</td>
        <td>
          <button type="submit" name="accion" value="h--">&lt;&lt;</button>
          <button type="submit" name="accion" value="h-">&lt;</button>
          <button type="submit" name="accion" value="h+">&gt;</button>
          <button type="submit" name="accion" value="h++">&gt;&gt;</button>
        </td>
      </tr>
      <tr>
        <td>Blanco (White):</td>
        <td>
          <button type="submit" name="accion" value="w--">&lt;&lt;</button>
          <button type="submit" name="accion" value="w-">&lt;</button>
          <button type="submit" name="accion" value="w+">&gt;</button>
          <button type="submit" name="accion" value="w++">&gt;&gt;</button>
        </td>
      </tr>
      <tr>
        <td>Negro (Black):</td>
        <td>
          <button type="submit" name="accion" value="b--">&lt;&lt;</button>
          <button type="submit" name="accion" value="b-">&lt;</button>
          <button type="submit" name="accion" value="b+">&gt;</button>
          <button type="submit" name="accion" value="b++">&gt;&gt;</button>
        </td>
      </tr>
    </table>

    <p><input type="submit" name="accion" value="Reiniciar"></p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
