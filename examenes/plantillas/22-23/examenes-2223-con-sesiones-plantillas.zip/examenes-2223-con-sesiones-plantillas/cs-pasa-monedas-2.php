<?php
/**
 * examen - cs-pasa-monedas-2.php
 *
 * @author Escriba aquí su nombre
 */

print "<!-- Ejercicio incompleto -->\n";
