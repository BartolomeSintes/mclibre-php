<?php
/**
 * @author Escriba aquí su nombre
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Juego de dados</h1>

  <p>Cada jugador va tirando el dado por turnos. Si el total de puntos acumulado es par, gana un punto el jugador A. Si es impar, gana un punto el jugador B. Gana la partida el primer jugador que saca cinco puntos al otro.</p>

  <form action="juego-dados-1-2.php">
<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
    <p>
      <button type="submit" name="accion" value="tirar">Tirar dado</button>
      <button type="submit" name="accion" value="empezar">Volver a empezar</button>
    </p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
