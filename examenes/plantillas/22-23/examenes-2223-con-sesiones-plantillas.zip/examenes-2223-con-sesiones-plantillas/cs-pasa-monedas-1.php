<?php
/**
 * examen - cd-pasa-monedas-1.php
 *
 * @author Escriba aquí su nombre
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Pasa monedas.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
  <style>
    button { border: black 2px solid; border-top: none; border-bottom-left-radius: 15px; border-bottom-right-radius: 15px; margin-right: 10px;}
  </style>
</head>

<body>
  <h1>Pasa monedas</h1>

  <form action="cs-pasa-monedas-2.php">
<?php

print "    <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
    <p><input type="submit" name="monton" value="Reiniciar"></p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
