<?php
/**
 * examen - cf-cuenta-cartas-altas-1.php
 *
 * @author Escriba aquí su nombre
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Cuenta cartas altas (Formulario).
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Cuenta cartas altas (Formulario)</h1>

  <p>Indique el palo y el número de cartas que tirará cada jugador y el número de cartas que elegirán:</p>

  <form action="cf-cuenta-cartas-altas-2.php" method="get">
    <p>
      Número de cartas total:
      <input type="number" name="cartas" value="7" min="5" max="15" size="5">
    </p>

    <p>
      Número de cartas elegidas:
      <input type="number" name="elegidas" value="3" min="1" max="5" size="5">
    </p>

    <p>
      Jugador A:
      <select name="jugadorA">
        <option value="">...</option>
        <option value="c">Corazones</option>
        <option value="d">Diamantes</option>
        <option value="p">Picas</option>
        <option value="t">Tréboles</option>
      </select>
    </p>

    <p>
      Jugador B:
      <select name="jugadorB">
        <option value="">...</option>
        <option value="c">Corazones</option>
        <option value="d">Diamantes</option>
        <option value="p">Picas</option>
        <option value="t">Tréboles</option>
      </select>
    </p>

    <p>
      <input type="submit" value="Enviar">
      <input type="reset" value="Borrar">
    </p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
