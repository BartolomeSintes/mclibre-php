<?php
/**
 * examen - ruleta-fortuna.php
 *
 * @author Escriba aquí su nombre
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Ruleta de la fortuna.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Ruleta de la fortuna</h1>

  <p>
    <svg width="320" height="220" viewBox="-10 -10 320 220">
      <path d="M 100,100 150,13 A 100,100 0 0,1 200,100 Z" fill="hwb(0 40% 0%)" />
      <path d="M 100,100 200,100 A 100,100 0 0,1 150,187 Z" fill="hwb(60 40% 0%)" />
      <path d="M 100,100 150,187 A 100,100 0 0,1 50,187 Z" fill="hwb(120 40% 0%)" />
      <path d="M 100,100 50,187 A 100,100 0 0,1 0,100 Z" fill="hwb(180 40% 0%)" />
      <path d="M 100,100 0,100 A 100,100 0 0,1 50,13 Z" fill="hwb(240 40% 0%)" />
      <path d="M 100,100 50,13 A 100,100 0 0,1 150,13 Z" fill="hwb(300 40% 0%)" />
      <text x="100" y="37" text-anchor="middle" font-family="sans-serif" font-size="40">1</text>
      <text x="167" y="76" text-anchor="middle" font-family="sans-serif" font-size="40">2</text>
      <text x="167" y="146" text-anchor="middle" font-family="sans-serif" font-size="40">3</text>
      <text x="100" y="192" text-anchor="middle" font-family="sans-serif" font-size="40">4</text>
      <text x="32" y="146" text-anchor="middle" font-family="sans-serif" font-size="40">5</text>
      <text x="32" y="76" text-anchor="middle" font-family="sans-serif" font-size="40">6</text>
      <circle cx="100" cy="100" r="100" stroke="black" stroke-width="4" fill="none" />

<?php

print "    <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
    </svg>
  </p>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
