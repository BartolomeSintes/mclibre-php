<?php
/**
 * @author Escriba aquí su nombre
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Sin título.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Elige palo y número (Formulario)</h1>

  <p>Indique el número de cartas que se jugarán y qué palo y qué número elige cada jugador:</p>

  <form action="cf-elige-palo-numero-2.php" method="get">
    <p>
      Número de cartas:
      <input type="number" name="nCartas" value="7" min="1" max="12" size="4">
    </p>

    <p>
      Jugador A:
      Palo
      <select name="paloA">
        <option value="ninguno"></option>
        <option value="p">Picas</option>
        <option value="c">Corazones</option>
        <option value="d">Diamantes</option>
        <option value="t">Tréboles</option>
      </select>
      Número
      <input type="number" name="numeroA" value="" min="1" max="10" size="3">

    <p>
      Jugador B:
      Palo
      <select name="paloB">
        <option value="ninguno"></option>
        <option value="p">Picas</option>
        <option value="c">Corazones</option>
        <option value="d">Diamantes</option>
        <option value="t">Tréboles</option>
      </select>
      Número
      <input type="number" name="numeroB" value="" min="1" max="10" size="3">
    </p>

    <p>
      <input type="submit" value="Enviar">
      <input type="reset" value="Borrar">
    </p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
