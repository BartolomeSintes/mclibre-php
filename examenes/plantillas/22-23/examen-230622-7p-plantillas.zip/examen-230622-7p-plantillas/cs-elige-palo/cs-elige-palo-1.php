<?php
/**
 * @author Escriba aquí su nombre
 */

print "<!-- Ejercicio incompleto -->\n";
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Sin título.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
  <style>
    td { text-align: center;}
  </style>
</head>

<body>
  <h1>Elige palo (Formulario)</h1>

  <p>Indique qué palo cree que va a salir:</p>

  <form action="cs-elige-palo-2.php" method="get">
    <table>
      <tr>
        <td></td>
        <td>Palo elegido</td>
        <td><input type="submit" name="accion" value="Jugar"></td>
      </tr>
<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
    </table>
  </form>

<footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
