<?php
/**
 * Mini brisca - mini-brisca.php
 *
 * @author Escriba aquí su nombre
 *
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Escriba aquí su nombre.
    Mini brisca. Sin formularios.
    Exámenes. PHP. mclibre.org
    </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Mini brisca</h1>

  <p>Actualice la página para mostrar otra mano.</p>

  <table>
    <tr>
      <th>Jugador 1</th>
      <th>Palo de triunfo</th>
      <th>Jugador 2</th>
    </tr>

<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

<footer>
  <p>Escriba aquí su nombre</p>
</footer>
</body>
</html>
