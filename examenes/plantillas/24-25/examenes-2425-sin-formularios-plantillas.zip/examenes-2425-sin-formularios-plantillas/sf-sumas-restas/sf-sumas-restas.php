<?php
/**
 * Examen Sumas y restas - sf-sumas-restas.php
 *
 * @author Escriba aquí su nombre
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Escriba aquí su nombre.
    Sumas y restas. Sin formularios.
    Exámenes. PHP. mclibre.org
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
  <style>
    table { font-size: 4rem; border-spacing: 20px; text-align: center; }
    td { width: 80px; }
  </style>
</head>

<body>
  <h1>Sumas y restas</h1>

  <p>Esta página muestra entre 5 y 10 números al azar del 1 al 10. La puntuación inicial es el primer número. A continuación cada número se compara con el anterior y se suma si es mayor y se resta si es menor.</p>

<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
