<?php
/**
 * @author Escriba aquí su nombre
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Escriba aquí su nombre.
    Cronómetro. Sin formularios.
    Exámenes. PHP. mclibre.org
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
  <style>
    @font-face {
      font-family: "BlackOpsOne";
      src: url("black-ops-one.woff2");
    }
  </style>
</head>

<body>
  <h1>Cronómetro</h1>

  <p>Actualice la página para reiniciar el cronómetro.</p>

  <p>
    <svg width="320" height="220" viewBox="-10 -10 320 220" style="font-family: 'BlackOpsOne'; font-size: 110px">
    <polygon points="20,0 175,0 200,25 200,130 175,150 20,150 0,130 0,20" fill="black" />
    <rect x="199" y ="90" width="10" height="12" fill="silver" stroke="black" />
    <text x="30" y="15" text-anchor="begin" font-size="12" fill="white">NISUPA</text>
    <polygon points="30,20 170,20 180,30 180,120 170,130 30,130 20,120 20,30" fill="hwb(76 75% 30%)" />
    <polygon points="30,24 170,24 176,30 176,120 170,126 30,126 24,120 24,30" stroke="black" stroke-width="1" fill="none" />
<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
    </svg>
  </p>

<footer>
  <p>Escriba aquí su nombre</p>
</footer>
</body>
</html>
