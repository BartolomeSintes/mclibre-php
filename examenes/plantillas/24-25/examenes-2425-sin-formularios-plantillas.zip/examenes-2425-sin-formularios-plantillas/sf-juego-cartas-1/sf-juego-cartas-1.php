<?php
/**
 * Examen Juego de cartas 1 - sf-juego-cartas-1.php
 *
 * @author Escriba aquí su nombre
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Juego de cartas.
    Sin formularios.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Juego de cartas</h1>

  <p>Actualice la página para mostrar una nueva partida de un juego de cartas. Se juegan entre 1 y 4 turnos. Cada jugador saca tres cartas. Si coincide el número de alguna carta entre los jugadores, gana él. Si no, gana ella. Gana quien gana más turnos.</p>

<?php

print "    <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
