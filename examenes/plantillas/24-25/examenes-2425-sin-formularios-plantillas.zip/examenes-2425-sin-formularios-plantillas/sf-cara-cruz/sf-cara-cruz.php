<?php
/**
 * Examen Cara o cruz - sf-cara-cruz.php
 *
 * @author Escriba aquí su nombre
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Escriba aquí su nombre.
    Cara o cruz. Sin formularios.
    Exámenes. PHP. mclibre.org
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Cara o cruz</h1>

  <p>Dos jugadores tiran una moneda varias veces (de 5 a 9, al azar). En cada baza, si uno de ellos saca "cara" (el símbolo del euro) y el otro no, ese jugador gana la baza. El jugador que gana más bazas, gana la partida.</p>

<?php

print "    <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
