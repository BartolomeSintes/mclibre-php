<?php
/**
 * Examen Solitario de cartas 1 - sf-solitario-cartas-1.php
 *
 * @author Escriba aquí su nombre
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Escriba aquí su nombre.
    Solitario de cartas. Sin formularios.
    Exámenes. PHP. mclibre.org
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Solitario de cartas</h1>

  <p>Actualice la página para mostrar una nueva partida de un soplitario de cartas. Se sacan dos filas de entre 3 y 7 cartas del 1 al 3. Si las cartas correspondientes de las dos filas tienen el mismo número o el mismo palo, se eliminan. Se gana al solitario si se liminan todas las cartas.</p>

<?php

print "    <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
