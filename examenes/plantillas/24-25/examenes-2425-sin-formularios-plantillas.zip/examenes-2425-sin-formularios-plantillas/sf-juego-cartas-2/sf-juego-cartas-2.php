<?php
/**
 * Examen Juego de cartas (2) - sf-juego-cartas-2.php
 *
 * @author Escriba aquí su nombre
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Escriba aquí su nombre.
    Juego de cartas. Sin formularios.
    Exámenes. PHP. mclibre.org
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Juego de cartas</h1>

  <p>Actualice la página para mostrar una nueva partida de un juego de cartas. El jugador A saca cuatro cartas, del 1 al 4. El jugador B saca una carta, del 1 al 4. Si coincide el palo de la carta del jugador B con el palo de alguna carta del jugador A, gana el jugador A. Si coincide el número, gana el jugador B.</p>

<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
