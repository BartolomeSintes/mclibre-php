<?php
/**
 * Examen Juego de dados 2 - sf-juego-dados-2.php
 *
 * @author Escriba aquí su nombre
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Escriba aquí su nombre.
    Juego de dados. Sin formularios.
    Exámenes. PHP. mclibre.org
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Juego de dados</h1>

  <p>Actualice la página para mostrar una nueva partida de un juego de dados. Se juegan entre 3 y 6 turnos. Cada jugador tira un dado. Si ambos son pares o impares, el gato se lleva los puntos. Si uno es par y el otro impar, el ratón se lleva los puntos. Gana quien consigue más puntos.</p>

<?php

print "    <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
