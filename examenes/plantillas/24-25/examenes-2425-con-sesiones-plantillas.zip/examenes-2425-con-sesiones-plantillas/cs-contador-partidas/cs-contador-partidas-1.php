<?php
/**
 * Examen Contador de partidas 1 - cs-contador-partidas-1.php
 *
 * @author Escriba aquí su nombre
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Escriba aquí su nombre.
    Contador de partidas. Con Sesiones.
    Exámenes. PHP. mclibre.org
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
  <style>
    td { padding-right: 20px;}
  </style>
</head>

<body>
  <h1>Contador de partidas</h1>

  <form action="cs-contador-partidas-2.php" method="get">
    <p>Haga clic en los botones para jugar una nueva tirada o partida. Gana la tirada el jugador que saque más puntos. Gana la partida el jugador que gane tres tiradas.</p>

<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
    <p>
      <button type="submit" name="accion" value="tirada">Nueva tirada</button>
      <button type="submit" name="accion" value="partida">Nueva partida</button>
      <button type="submit" name="accion" value="reiniciar">Borrar todo</button>
    </p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>

