<?php
/**
 * Examen Adivine el número 2 - cs-adivine-numero-2.php
 *
 * @author Escriba aquí su nombre
 */

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";
