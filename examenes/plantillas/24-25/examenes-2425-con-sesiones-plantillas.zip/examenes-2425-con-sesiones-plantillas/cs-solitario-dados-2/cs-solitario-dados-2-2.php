<?php
/**
 * Examen Solitario de dados 2 2 - cs-solitario-dados-2-2.php
 *
 * @author Escriba aquí su nombre
 */

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";
