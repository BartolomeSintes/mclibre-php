<?php
/**
 * Juego de cartas 1- cs-cartas-1-2.php
 *
 * @author Escriba aquí su nombre
 */

print "<!-- Ejercicio incompleto -->\n";
