<?php
/**
 * Juego de cartas 1- cs-cartas-1-1.php
 *
 * @author Escriba aquí su nombre
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Escriba aquí su nombre.
    Juego de cartas para tres jugadores. Con Sesiones.
    Exámenes. PHP. mclibre.org
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Juego de cartas para tres jugadores</h1>

  <p>Dos jugadores sacan cada uno una carta al azar del 1 al 4. El que tiene la carta más alta se lleva su valor en puntos. Si las cartas coinciden, el tercer jugador se lleva la suma de los puntos. Gana el jugador que supere antes los 20 puntos. Cuando alguien gana la partida, ya no se pueden sacar nuevas cartas.</p>

  <form action="cs-cartas-1-2.php">
<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
    <p>
      <button type="submit" name="accion" value="jugar">Nuevas cartas</button>
      <button type="submit" name="accion" value="reiniciar">Volver a empezar</button>
    </p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
