<?php
/**
 * Examen Récord de cartas 2 - cs-record-cartas-2.php
 *
 * @author Escriba aquí su nombre
 */

print "<!-- Ejercicio incompleto -->\n";
