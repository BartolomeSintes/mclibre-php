<?php
/**
 * Examen Distribución de dado 1 - cs-distribucion-dado-1.php
 *
 * @author Escriba aquí su nombre
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Escriba aquí su nombre.
    Distribución de dado. Con Sesiones.
    Exámenes. PHP. mclibre.org
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Distribución de dado</h1>

  <form action="cs-distribucion-dado-2.php" method="get">
    <p>Haga clic en el dado para mostrar un nuevo valor. El gráfico muestra la distribución de valores.</p>

<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
    <p>
      <button type="submit" name="accion" value="reiniciar">Volver a empezar</button>
    </p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>

