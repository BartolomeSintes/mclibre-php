<?php
/**
 * Examen Juego de dados (2) 1 - cs-juego-dados-2-1.php
 *
 * @author Escriba aquí su nombre
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Escriba aquí su nombre.
    Juego de dados (2). Con Sesiones.
    Exámenes. PHP. mclibre.org
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Juego de dados</h1>

  <p>Cada jugador tira dos dados. Si ningún jugador saca dos valores iguales o los dos sacan valores iguales, el punto se acumula en la tirada siguiente. Cuando sólo un jugador saca valores iguales, se lleva los puntos acumulados. El primero que gana 20 puntos, gana la partida. Acabada la partida, ya no se pueden tirar más los dados.</p>

  <form action="cs-juego-dados-2-2.php">
<?php

print "    <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
    <p>
      <button type="submit" name="accion" value="tirar">Tirar dados</button>
      <button type="submit" name="accion" value="reiniciar">Volver a empezar</button>
    </p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
