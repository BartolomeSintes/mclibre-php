<?php
/**
 * Examen Bingo 1 - cs-bingo-1.php
 *
 * @author Escriba aquí su nombre
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Escriba aquí su nombre.
    Bingo. Con Sesiones.
    Exámenes. PHP. mclibre.org
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
  <style>
    table { border: black 2px solid; border-collapse: collapse; font-size: 4rem; background-color: hwb(240 80% 0%);}
    td { border: black 2px solid; padding: 4px; }
    table button { font-size: 4rem; padding: 0 10px; }
  </style>
</head>

<body>
  <h1>Bingo</h1>

  <p>Muestre un nuevo número haciendo clic en el botón "Nuevo número". Si hace clic en el número del cartón que coincide con número mostrado, se tapará el número. Al completar una línea o el cartón completo se mostrará una vez el mensaje correspondiente. Haga clic en "Volver a empezar" para mostrar un nuevo cartón.</p>

  <form action="cs-bingo-2.php">
<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
    <p>
      <button type="submit" name="accion" value="nuevo">Nuevo número</button>
      <button type="submit" name="accion" value="reiniciar">Volver a empezar</button>
    </p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
