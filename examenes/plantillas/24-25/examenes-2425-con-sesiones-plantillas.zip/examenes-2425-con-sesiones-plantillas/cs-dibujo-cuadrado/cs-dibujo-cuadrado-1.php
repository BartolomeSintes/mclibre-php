<?php
/**
 * Dibujo cuadrado - cs-dibujo-cuadrado-1.php
 *
 * @author Escriba aquí su nombre
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Escriba aquí su nombre.
    Juego de cartas para tres jugadores. Con Sesiones.
    Exámenes. PHP. mclibre.org
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
  <style>
    td { vertical-align: top; }
     td button { width: 30px; height: 30px; border: black 1px solid; }
  </style>
</head>

<body>
  <h1>Dibujo cuadrado</h1>

  <p>Haga clic en el color para cambiar el color del borde o del relleno del cuadrado. Borde y relleno no pueden tener el mismo color.</p>

  <form action="cs-dibujo-cuadrado-2.php">
    <table style="text-align: center;">
      <tr>
        <td>Cuadrado</td>
        <td>Borde</td>
        <td>Relleno</td>
      </tr>
      <tr>
        <td>
          <svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200">
<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
          </svg>
        </td>
        <td>
         <button type="submit" name="borde" value="white" style="background-color: white"></button><br>
         <button type="submit" name="borde" value="red" style="background-color: red"></button><br>
         <button type="submit" name="borde" value="yellow" style="background-color: yellow"></button><br>
         <button type="submit" name="borde" value="green" style="background-color: green"></button><br>
         <button type="submit" name="borde" value="blue" style="background-color: blue"></button><br>
         <button type="submit" name="borde" value="black" style="background-color: black"></button>
        </td>
        <td>
         <button type="submit" name="relleno" value="white" style="background-color: white"></button><br>
         <button type="submit" name="relleno" value="red" style="background-color: red"></button><br>
         <button type="submit" name="relleno" value="yellow" style="background-color: yellow"></button><br>
         <button type="submit" name="relleno" value="green" style="background-color: green"></button><br>
         <button type="submit" name="relleno" value="blue" style="background-color: blue"></button><br>
         <button type="submit" name="relleno" value="black" style="background-color: black"></button>
        </td>
      </tr>
    </table>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
