<?php
/**
 * Examen Cerca y lejos (Formulario) - cf-cerca-lejos-1.php
 *
 * @author Escriba aquí su nombre
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Escriba aquí su nombre.
    Cerca y lejos (Formulario). Con formularios.
    Exámenes. PHP. mclibre.org
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Cerca y lejos (Formulario 1)</h1>

  <form action="cf-cerca-lejos-2.php" method="get">
    <p>Escriba tres números entre 0 y 500:</p>

    <table>
      <tbody>
        <tr>
          <td>Menor:</td>
          <td><input type="number" name="menor" min="0" max="500" value="100"></td>
        </tr>
        <tr>
          <td>Mediano:</td>
          <td><input type="number" name="mediano" min="0" max="500" value="300"></td>
        </tr>
        <tr>
          <td>Mayor:</td>
          <td><input type="number" name="mayor" min="0" max="500" value="400"></td>
        </tr>
      </tbody>
    </table>

    <p>
      <input type="submit" value="Enviar">
      <input type="reset" value="Borrar">
    </p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
