<?php
/**
 * Examen Cartas distintas (Formulario) - cf-cartas-distintas-1.php
 *
 * @author Escriba aquí su nombre
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Escriba aquí su nombre.
    Cartas distintas (Formulario). Con formularios.
    Exámenes. PHP. mclibre.org
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Cartas distintas (Formulario)</h1>

  <form action="cf-cartas-distintas-2.php" method="get">
    <p>Indique cuántas cartas quiere mostrar y cuántas cartas seguidas sin valores iguales consecutivos se deben obtener para ganar. Las cartas tendrán valores del 1 al 6.</p>

    <table>
      <tr>
        <td><strong>Número de cartas:</strong></td>
        <td><input type="number" name="cantidad" min="5" max="11" value="8"></td>
      </tr>
      <tr>
        <td><strong>Objetivo:</strong></td>
        <td>
          <select name="objetivo">
            <option>Cinco</option>
            <option>Seis</option>
            <option>Siete</option>
          </select>
        </td>
      </tr>
    </table>

    <p>
      <input type="submit" value="Mostrar">
      <input type="reset" value="Borrar">
    </p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
