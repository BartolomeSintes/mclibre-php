<?php
/**
 * Dibujo 3 1 - cf-dibujo-3-1.php
 *
 * @author Escriba aquí su nombre
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Escriba aquí su nombre.
    Dibujo 3 (Formulario). Con formularios.
    Exámenes. PHP. mclibre.org
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Dibujo 3 (Formulario)</h1>

  <form action="cf-dibujo-3-2.php" method="get">
    <p>Elija el radio de los círculos interiores (entre 25 y 100px) y su color.</p>

    <table>
      <tr>
        <td><strong>Radio del círculo:</strong></td>
        <td><input type="number" name="radio" min="25" max="100" value="50"></td>
      </tr>
      <tr>
        <td><strong>Color:</strong></td>
        <td>
          <select name="color">
            <option value="">...</option>
            <option value="red">Rojo</option>
            <option value="yellow">Amarillo</option>
            <option value="green">Verde</option>
            <option value="blue">Azul</option>
          </select>
        </td>
      </tr>
    </table>

    <p>
      <input type="submit" value="Mostrar">
      <input type="reset" value="Borrar">
    </p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
