<?php
/**
 * Puntos en cartas - puntos-cartas.php
 *
 * @author Escriba aquí su nombre
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Puntos en cartas.
    Sin formularios.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Puntos en cartas</h1>

  <p>Cada jugador saca 7 cartas (que se pueden repetir). Además se sacan dos cartas "ganadoras". Si el número de una carta (no el palo) de un jugador coincide con alguna de las dos cartas, el jugador acumula el valor de la carta en puntos. El jugador que acumula más puntos, gana.</p>

<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
