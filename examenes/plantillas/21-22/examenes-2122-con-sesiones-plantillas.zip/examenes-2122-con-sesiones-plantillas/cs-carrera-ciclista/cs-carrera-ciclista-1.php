<?php
/**
 * Examen - cs-carrera-ciclista-1.php
 *
 * @author Escriba aquí su nombre
 */

print "  <!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Carrera ciclista (Formulario).
    Con sesiones.
    Exámenes. PHP. Bartolomé Sintes Marco
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Carrera ciclista</h1>

  <form action="cs-carrera-ciclista-2.php" method="get">

<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
    <p>
      <input type="submit" name="accion" value="Lanzar dado">
      <input type="submit" name="accion" value="Reiniciar">
    </p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
