<?php
/**
 * @author Escriba aquí su nombre
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Sin título.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Escogen cartas</h1>

  <p>Haga clic en la cara de un animal para seleccionar la carta o haga clic en la carta para cambiarla.</p>

  <form action="escogen-cartas-2.php">
<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
