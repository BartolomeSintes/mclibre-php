<?php
/**
 * @author Escriba aquí su nombre
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Sin título.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Creciendo</h1>

  <p>Haga clic en Siguiente para mostrar un nuevo valor al azar de 0 a 1000. Si el valor aumenta, el <i>emoji</i> se hará más grande. Si no, volverá al tamaño inicial.</p>

  <form action="creciendo-2.php">
<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
    <p>
      <input type="submit" name="accion" value="Siguiente">
      <input type="submit" name="accion" value="Reiniciar">
    </p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
