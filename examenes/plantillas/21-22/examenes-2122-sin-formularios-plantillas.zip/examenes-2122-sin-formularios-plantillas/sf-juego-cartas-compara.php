<?php
/**
 * Examen - sf-juego-cartas-compara.php
 *
 * @author Escriba aquí su nombre
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Juego de cartas.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Juego de cartas</h1>

  <p>Actualice la página para ver una nueva partida. Una vez ordenadas las cartas, se comparan las cartas una a una y el jugador que tiene la de mayor valor gana dos puntos (en caso de empate, cada jugador gana un punto).</p>

  <?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
