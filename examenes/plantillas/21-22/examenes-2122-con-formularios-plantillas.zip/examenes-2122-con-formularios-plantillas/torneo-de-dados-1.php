<?php
/**
 * @author Escriba aquí su nombre
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Sin título.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Torneo de dados (Formulario)</h1>

  <p>Indique cuántas partidas se jugarán en este torneo:</p>

  <form action="torneo-de-dados-2.php" method="get">
    <p>
      Partidas:
      <input type="number" name="partidas" value="3" min="1" max="10">
    </p>

    <p>
      Nombre jugadora:
      <select name="jugadora">
        <option></option>
        <option>Bárbara</option>
        <option>Daara</option>
        <option>María</option>
        <option>Natalia</option>
      </select>
    </p>

    <p>
      Nombre jugador:
      <select name="jugador">
        <option></option>
        <option>Carlos</option>
        <option>Emilio</option>
        <option>Jorge</option>
        <option>Pablo</option>
      </select>
    </p>

    <p>
      <input type="submit" value="Enviar">
      <input type="reset" value="Borrar">
    </p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
