<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Dados contra dados (Formulario).
    Con formularios.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Dados contra dados (Formulario)</h1>

  <p>Indique cuántos dados quiere tirar cada jugador:</p>

  <form action="cf-dados-contra-dados-2.php" method="get">
    <p>
      Jugador A:
      <input type="text" name="jugadorA" size="5" maxlength="4">
    </p>

    <p>
      Jugador B:
      <select name="jugadorB">
        <option value="1">Uno</option>
        <option value="2">Dos</option>
        <option value="3">Tres</option>
        <option value="4">Cuatro</option>
        <option value="5">Cinco</option>
        <option value="6">Seis</option>
        <option value="7">Siete</option>
        <option value="8">Ocho</option>
        <option value="9">Nueve</option>
        <option value="10">Diez</option>
      </select>
    </p>

    <p>
      <input type="submit" value="Enviar">
      <input type="reset" value="Borrar">
    </p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
