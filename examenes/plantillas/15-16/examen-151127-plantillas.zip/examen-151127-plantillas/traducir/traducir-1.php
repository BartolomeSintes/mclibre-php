<?php
$textos = [
  1 => ["Formulario", "Form"],
  2 => ["Escriba una palabra", "Write a word"],
  3 => ["Comprobar", "Check"],
  4 => ["Borrar", "Delete"],
  5 => ["Ha escrito", "You have written"]
];

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

<footer>
  <p>Escriba su nombre</p>
</footer>
</body>

</html>