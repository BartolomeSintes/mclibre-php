<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Restaurante (Formulario 3).
    Escriba su nombre
  </title>
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
<h1>Restaurante (Formulario 3)</h1>

<?php

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

<p><a href="palabras-1.html">Volver al formulario inicial.</a></p>

  <footer>
    <p>Escriba su nombre</p>
  </footer>
</body>
</html>