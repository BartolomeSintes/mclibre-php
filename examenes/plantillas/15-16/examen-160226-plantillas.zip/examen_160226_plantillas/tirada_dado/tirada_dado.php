<?php

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Tirada de dados digital.
    Escriba su nombre
  </title>
  <link href="mclibre_php_soluciones.css" rel="stylesheet" type="text/css" title="Color">
</head>

<body>
<h1>Tirada de dados digital</h1>

<?php

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

  <footer>
    <p>Escriba su nombre</p>
  </footer>
</body>
</html>