<?php
$textos = array(
    1 => array("Formulario", "Form"),
    2 => array("Escriba una palabra", "Write a word"),
    3 => array("Comprobar", "Check"),
    4 => array("Borrar", "Delete"),
    5 => array("Ha escrito", "You have written")
);

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

  <footer>
    <p>Escriba su nombre</p>
  </footer>
</body>
</html>