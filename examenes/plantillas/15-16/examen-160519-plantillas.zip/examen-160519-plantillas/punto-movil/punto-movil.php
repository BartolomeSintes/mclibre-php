<?php

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

?><!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Mover punto.
    Escriba su nombre
  </title>
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
<h1>Punto móvil</h1>

<?php

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

  <footer>
    <p>Escriba su nombre</p>
  </footer>
</body>
</html>