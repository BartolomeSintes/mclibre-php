<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Palabras (Resultado).
    Escriba su nombre
  </title>
  <link href="mclibre_php_soluciones.css" rel="stylesheet" type="text/css" title="Color">
</head>

<body>
<h1>Palabras (Resultado)</h1>

<?php

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

<p><a href="palabras_1.html">Volver al formulario inicial.</a></p>

  <footer>
    <p>Escriba su nombre</p>
  </footer>
</body>
</html>