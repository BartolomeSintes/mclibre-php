<?php
// print "<p class=\"aviso\">Ejercicio incompleto</p>\n";
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Dado digital.
    Escriba su nombre
  </title>
  <link href="mclibre_php_soluciones.css" rel="stylesheet" type="text/css" title="Color">
</head>

<body>
<h1>Dado digital</h1>

<?php

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

<p>Actualice la página para tirar de nuevo el dado.</p>

  <footer>
    <p>Escriba su nombre</p>
  </footer>
</body>
</html>