<?php

// print "    <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <title>
      Captcha.
      Escriba su nombre
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
  </head>

  <body>
    <h1>Captcha</h1>

<?php

print "    <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
    <p>Por favor, escriba el número que ve en la imagen.</p>

    <p>
      <svg version="1.1" xmlns="http://www.w3.org/2000/svg"
        width="400" height="120" style="background-color: white; border: black 1px solid">

        <filter id="dropShadow">
          <feGaussianBlur in="SourceAlpha" stdDeviation="3" />
          <feOffset dx="2" dy="4" />
          <feMerge>
            <feMergeNode />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>

<?php

// print "    <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
      </svg>

    <form action="captcha-2.php" method="get">
      <p>Número: <input type="text" name="numero" size="10"></p>

      <p><input type="submit" value="Comprobar"></p>
    </form>

    <footer>
      <p>Escriba su nombre</p>
    </footer>
  </body>
</html>