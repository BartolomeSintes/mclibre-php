<?php
/**
 * Dibujitos - dibujitos-1.php
 *
 * @author Escriba aquí su nombre
 *
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Dibujitos (Formulario).
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Dibujitos (Formulario)</h1>

  <p>Elija los elementos del dibujo:</p>

  <form action="dibujitos-2.php" method="get">
    <table>
      <tr>
        <td>Animales:</td>
        <td><input type="number" name="animNum" min="0" max="10" value="5" style="width: 3em"></td>
        <td>
          <label><input type="radio" name="animTam" value="p">Pequeños</label> -
          <label><input type="radio" name="animTam" value="m">Medianos</label> -
          <label><input type="radio" name="animTam" value="g">Grandes</label>
        </td>
      </tr>
      <tr>
        <td>Transporte:</td>
        <td><input type="number" name="tranNum" min="0" max="10" value="5" style="width: 3em"></td>
        <td>
          <label><input type="radio" name="tranTam" value="p">Pequeños</label> -
          <label><input type="radio" name="tranTam" value="m">Medianos</label> -
          <label><input type="radio" name="tranTam" value="g">Grandes</label>
        </td>
      </tr>
      </table>

    <p>
      <input type="submit" value="Enviar">
      <input type="reset" value="Borrar">
    </p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
