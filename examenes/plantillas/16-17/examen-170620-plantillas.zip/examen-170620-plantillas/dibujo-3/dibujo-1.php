<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <title>
      Dibujo (Formulario).
      Escriba su nombre
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
  </head>

  <body>
    <h1>Dibujo (Formulario)</h1>

    <p>Elija las características del dibujo:</p>

    <form action="dibujo-2.php" method="get">
      <table>
        <tr>
          <td>Número de elementos:</td>
          <td><input type="number" name="elementos" min="1" max="25" value="5" style="width: 3em"></td>
        </tr>
        <tr>
          <td>Color:</td>
          <td><input type="color" name="color"></td>
        </tr>
       </table>

      <p>
        <input type="submit" value="Enviar">
        <input type="reset" value="Borrar">
      </p>
    </form>

    <footer>
      <p>Escriba su nombre</p>
    </footer>
  </body>
</html>
