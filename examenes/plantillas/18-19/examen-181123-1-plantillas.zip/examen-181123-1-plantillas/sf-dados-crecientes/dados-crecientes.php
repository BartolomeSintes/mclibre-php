<?php
/**
 * Juego de dados- dados-crecientes.php
 *
 * @author    Escriba aquí su nombre
 *
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Dados crecientes. Juego de dados.
    Sin formularios.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Juego de dados - Dados crecientes</h1>

  <p>Actualice la página para mostrar otra partida.</p>

  <table>
    <tr>
      <th colspan="2">Jugador 1</th>
      <th colspan="2">Jugador 2</th>
    </tr>
<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
