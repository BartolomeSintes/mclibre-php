<?php
/**
 * Récord- record-cartas-2.php
 *
 * @author    Escriba aquí su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
