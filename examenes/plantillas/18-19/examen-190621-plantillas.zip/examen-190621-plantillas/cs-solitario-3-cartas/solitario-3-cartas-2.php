<?php
/**
 * Solitario de tres cartas- solitario-3-cartas-2.php
 *
 * @author    Escriba su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>