<?php
/**
 * Elige cartas - elige-cartas-1.php
 *
 * @author Escriba aquí su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Elige cartas. Sesiones.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
  <style>
  button { background-color: white; padding: 0; border: none;}
  </style>
</head>

<body>
  <h1>Elige cartas</h1>

  <p>Haga clic en la carta para añadirla al total o haga clic en los botones para mostrar una nueva carta sin añadirla o reiniciar el contador a cero.</p>

  <form action="elige-cartas-2.php">
<?php

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

    <p><input type="submit" name="accion" value="Nueva"></p>

    <p><input type="submit" name="accion" value="Reiniciar"></p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
