<?php
/**
 * Suma o resta- suma-resta-2.php
 *
 * @author    Escriba su nombre
 *
 */

 print "<!-- Ejercicio incompleto -->\n";
