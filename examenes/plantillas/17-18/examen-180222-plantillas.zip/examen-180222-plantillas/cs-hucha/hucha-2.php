<?php
/**
 * Hucha de monedas - hucha-2.php
 *
 * @author    Escriba su nombre
 *
 */

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";