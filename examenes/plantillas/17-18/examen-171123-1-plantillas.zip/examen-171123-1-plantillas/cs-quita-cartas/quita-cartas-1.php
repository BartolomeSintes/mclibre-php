<?php
/**
 * Quita cartas - quita-cartas-1.php
 *
 * @author    Escriba su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Quita cartas.
    Escriba su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="mclibre-php-soluciones.css" rel="stylesheet" type="text/css" title="Color">
</head>

<body>
  <h1>Quita cartas</h1>

<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

  <form action="quita-cartas-2.php">
    <p>
      <button type="submit" name="quita" value="quita" style="background-color: #eee;">
        <svg version="1.1" xmlns="http://www.w3.org/2000/svg"
          width="210px" height="250px" viewBox="-10 -10 210 250">
          <defs>
            <pattern id="patron-1" x="0" y="0" width="10" height="10" patternUnits="userSpaceOnUse" >
              <rect x="0" y="0" width="10" height="10" fill="hsl(0, 100%, 80%)" />
              <line x1="0" y1="10" x2="10" y2="0" stroke="hsl(0, 100%, 90%)" stroke-width="1" />
              <line x1="0" y1="0" x2="10" y2="10" stroke="hsl(0, 100%, 90%)" stroke-width="1" />
            </pattern>
          </defs>

<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
        </svg>
      </button>
    </p>
  </form>

  <footer>
    <p>Escriba su nombre</p>
  </footer>
</body>
</html>
