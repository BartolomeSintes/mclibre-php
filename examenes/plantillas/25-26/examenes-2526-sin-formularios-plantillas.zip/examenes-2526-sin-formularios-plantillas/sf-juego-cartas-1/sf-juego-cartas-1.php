<?php
/**
 * Examen Juego de cartas 2 - sf-juego-cartas-2.php
 *
 * @author Escriba aquí su nombre
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Escriba aquí su nombre.
    Juego de cartas. Sin formularios.
    Exámenes. PHP. mclibre.org
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Juego de cartas</h1>

  <p>Actualice la página para mostrar una nueva partida de un juego de cartas. Cada jugador muestra dos cartas y una carta indica el valor ganador. La puntuación de cada jugador es la suma de diferencias entre sus cartas y la ganadora (por encima o por debajo). Si alguna carta coincide, el jugador se descuenta un punto, aunque no puede conseguir puntuaciones negativas. El jugador que saca menos puntos, gana. El icono señala al ganador.</p>

<?php

print "    <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
