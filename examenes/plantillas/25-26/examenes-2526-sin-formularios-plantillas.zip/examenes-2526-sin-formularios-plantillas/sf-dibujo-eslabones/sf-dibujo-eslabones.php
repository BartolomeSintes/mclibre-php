<?php
/**
 * Examen Dibujo Eslabones - sf-dibujo-eslabones.php
 *
 * @author Escriba aquí su nombre
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Escriba aquí su nombre.
    Dibujo de eslabones. Sin formularios.
    Exámenes. PHP. mclibre.org
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Dibujo de eslabones</h1>

  <p>Actualice la página para mostrar un nuevo dibujo de dos eslabones cuadrados de un tamaño entre 300 y 900 px (en múltiplos de 3). Las líneas se interrumpen a 10 unidades del cruce.</p>

<?php

print "    <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
