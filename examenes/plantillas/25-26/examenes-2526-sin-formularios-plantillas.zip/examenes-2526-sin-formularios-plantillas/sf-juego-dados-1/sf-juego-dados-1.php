<?php
/**
 * Examen Juego de dados 1 -  sf-juego-dados-1.php
 *
 * @author Escriba aquí su nombre
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Escriba aquí su nombre.
    Juego de dados. Sin formularios.
    Exámenes. PHP. mclibre.org
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Juego de dados</h1>

  <p>En cada turno cada jugador lanza un dado. Gana cada turno el jugador que haya sacado el dado más alto. Gana la partida el jugador que haya ganado más turnos y obtenido más puntos en total.</p>

<?php

print "    <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
