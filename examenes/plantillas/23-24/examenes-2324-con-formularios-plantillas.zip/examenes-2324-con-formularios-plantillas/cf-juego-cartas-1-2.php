<?php
/**
 * Examen - cf-juego-cartas-1-2.php
 *
 * @author Escriba aquí su nombre
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Juego de cartas.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Juego de cartas (Resultado)</h1>

  <p>Dos jugadores sacan de 5 a 10 cartas numeradas del 1 al número de cartas y ordenadas al azar, de palos distintos. Gana el jugador al que le coincida algún valor con la posición si al otro jugador no le ha coincido ningún valor.</p>

<?php

print "    <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
