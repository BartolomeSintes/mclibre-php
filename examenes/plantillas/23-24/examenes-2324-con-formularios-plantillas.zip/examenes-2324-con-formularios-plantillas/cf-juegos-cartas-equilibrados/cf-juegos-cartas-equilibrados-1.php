<?php
/**
 * @author Escriba aquí su nombre
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Sin título.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>¿Juegos de cartas equilibrados? (Formulario)</h1>

  <p>Indique el juego y el número de partidas para comprobar si el juego es equilibrado.</p>

  <form action="cf-juegos-cartas-equilibrados-2.php" method="get">
    <table>
      <tr>
        <td>
          Juego:
          <select name="juego">
            <option value="ninguno"></option>
            <option value="una contra una">Una contra una</option>
            <option value="dos contra una">Dos contra una</option>
          </select>
          Número de partidas:
          <input type="number" name="partidas" min="20" max="200" value="50" size="4">
        </td>
      </tr>
    </table>

    <p>
      <input type="submit" value="Enviar">
      <input type="reset" value="Borrar">
    </p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
