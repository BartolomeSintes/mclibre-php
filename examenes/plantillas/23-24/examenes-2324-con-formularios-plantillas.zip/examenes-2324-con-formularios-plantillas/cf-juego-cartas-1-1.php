<?php
/**
 * Examen - cf-juego-cartas-1-1.php
 *
 * @author Escriba aquí su nombre
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Juego de cartas (Formulario) (Formulario).
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Juego de cartas (Formulario) (Formulario)</h1>

  <p>Indique el palo y el número de cartas de cada uno de los jugadores. Los palos deben ser diferentes y el número de cartas debe encontrarse entre 5 y 10 cartas, ambos incluidos.</p>

  <form action="cf-juego-cartas-1-2.php" method="get">
    <table>
      <tr>
        <td>Jugador A:</td>
        <td>
          Palo:
          <select name="paloA">
            <option value="ninguno"></option>
            <option value="corazones">Corazones</option>
            <option value="diamantes">Diamantes</option>
            <option value="picas">Picas</option>
            <option value="tréboles">Tréboles</option>
          </select>
          Número de cartas:
          <input type="number" name="numeroA" min="5" max="10" value="7" size="4">
        </td>
      </tr>
      <tr>
        <td>Jugador B:</td>
        <td>
          Palo:
          <select name="paloB">
            <option value="ninguno"></option>
            <option value="corazones">Corazones</option>
            <option value="diamantes">Diamantes</option>
            <option value="picas">Picas</option>
            <option value="tréboles">Tréboles</option>
          </select>
          Número de cartas:
          <input type="number" name="numeroB" min="5" max="10" value="7" size="4">
        </td>
      </tr>
    </table>

    <p>
      <input type="submit" value="Enviar">
      <input type="reset" value="Borrar">
    </p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
