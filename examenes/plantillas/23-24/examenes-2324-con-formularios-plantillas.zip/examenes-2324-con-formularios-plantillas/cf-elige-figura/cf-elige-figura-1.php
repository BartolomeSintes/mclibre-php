<?php
/**
 * Examen - cf-elige-figura-1.php
 *
 * @author Escriba aquí su nombre
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Elige figura (Formulario).
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Elige figura (Formulario)</h1>

  <p>Indique el tipo de figura que se dibujará y su tamaño:</p>

  <form action="cf-elige-figura-2.php" method="get">
    <p>
      Forma
      <select name="figura">
        <option value="ninguno"></option>
        <option value="cir">Círculo</option>
        <option value="cua">Cuadrado</option>
      </select>
    </p>

    <p>
      Radio / Lado:
      <input type="number" name="tamano" value="50" step="10" size="4">
    </p>

    <p>
      <input type="submit" value="Enviar">
      <input type="reset" value="Borrar">
    </p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
