<?php
/**
 * Examen - sf-solitario-cartas-1.php
 *
 * @author Escriba aquí su nombre
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Solitario de cartas.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Solitario de cartas</h1>

  <p>Un jugador solitario saca 10 cartas del 1 al 10, al azar, de palos distintos. Si dos cartas pares seguidas son iguales, el jugador gana el solitario (aunque haya cartas impares entre las cartas pares iguales).</p>

<?php

print "    <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
