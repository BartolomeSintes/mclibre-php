<?php
/**
 * @author Escriba aquí su nombre
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Sin título.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
  <style>
    td { padding: 0 20px;}
    button { font-size: 2rem; }
  </style>
</head>

<body>
  <h1>Juego de dados (3)</h1>

  <p>Cada jugador tira cinco dados. Su puntuación es la suma de los valores obtenidos, sin contar el valor más alto y el más bajo.</p>

<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

<footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
