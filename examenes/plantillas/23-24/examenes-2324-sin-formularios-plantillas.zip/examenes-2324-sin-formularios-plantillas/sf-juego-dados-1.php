<?php
/**
 * Examen - juego-dados-1.php
 *
 * @author Escriba aquí su nombre
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Juego de dados.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Juego de dados</h1>

  <p>En cada turno cada jugador lanza un dado. Gana cada turno el jugador que haya acumulado más puntos desde el principio de la partida. Gana la partida el jugador que haya ganado más turnos.</p>

<?php

print "    <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
