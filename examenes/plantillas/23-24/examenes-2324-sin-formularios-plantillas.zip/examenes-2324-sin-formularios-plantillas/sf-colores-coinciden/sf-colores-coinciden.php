<?php
/**
 * @author Escriba aquí su nombre
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Sin título.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
  <style>
    td { width: 60px; height: 60px; border: black 1px solid; }
  </style>
</head>

<body>
  <h1>Colores coinciden</h1>

  <p>Se muestran entre 5 y 10 cuadros de colores uniformemente distribuidos, primero ordenados por matiz y después desordenados, y se indica el número de colores que se muestra en la misma posición.</p>

<?php
print "<!-- Ejercicio incompleto -->\n";

?>

<footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
