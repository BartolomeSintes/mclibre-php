<?php
/**
 * Examen - juego-dados-2.php
 *
 * @author Escriba aquí su nombre
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Juego de dados.
    Sin formularios.
    Exámenes. PHP. Bartolomé Sintes Marco. www.mclibre.org
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Juego de dados</h1>

  <p>Se lanzan 10 dados sobre un terreno de juego repartido en forma de franajas horizontales entre tres jugadoras, representadas por sus rostros. El terreno de cada jugadora es del mismo color que el color de piel de la jugadora. Cada dado puede caer en el terreno de cualquiera de las jugadoras. La puntuación de cada jugadora es la suma de los dados que han caído en su terreno. Gana la partida la jugadora que haya acumulado más puntos. Las medallas muestran la posición final de las jugadoras. En caso de empate, las jugadoras empatadas se llevan la misma medalla.</p>

<?php

print "    <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
