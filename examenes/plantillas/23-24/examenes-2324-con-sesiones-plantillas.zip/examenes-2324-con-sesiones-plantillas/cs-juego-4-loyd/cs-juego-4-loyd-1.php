<?php
/**
 * @author Escriba aquí su nombre
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Sin título.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
  <style>
    table { border-collapse: collapse; }
    td { border: black 1px solid; padding: 0;}
    td button { height: 60px; width: 60px; border: none; background-color: white; font-size: 3rem; }
  </style>
</head>

<body>
  <h1>Juego del 4 (Loyd)</h1>

  <p>Haga clic en una casilla numerada que se desplazará si hay una casilla contigua vacía.</p>

  <form action="cs-juego-4-loyd-2.php" method="get">
    <table>
<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
    </table>

    <p><input type="submit" name="accion" value="Reiniciar"></p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
