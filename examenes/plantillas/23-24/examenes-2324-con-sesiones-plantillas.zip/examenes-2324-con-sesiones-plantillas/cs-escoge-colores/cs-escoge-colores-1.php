<?php
/**
 * @author Escriba aquí su nombre
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Sin título.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
  <style>
    button { width: 60px; height: 60px; }
  </style>
</head>

<body>
  <h1>Escoge colores</h1>

  <p>Haga clic en uno de los cuadros de colores de arriba para colorear los cuadros de abajo. No repita colores ni haga coincidir los colores en los mismos cuadros de arriba y abajo.</p>

  <form action="cs-escoge-colores-2.php" method="get">
    <p>
      <button type="submit" name="accion" value="red" style="background-color: red"></button>
      <button type="submit" name="accion" value="yellow" style="background-color: yellow"></button>
      <button type="submit" name="accion" value="green" style="background-color: green"></button>
      <button type="submit" name="accion" value="blue" style="background-color: blue"></button>
    </p>

    <p>
      <input type="submit" name="accion" value="Reiniciar">
    </p>
  </form>

<?php

print "<!-- Ejercicio incompleto -->\n";

?>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
