<?php
/**
 * @author Escriba aquí su nombre
 */

 print "<!-- Ejercicio incompleto -->\n";
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Sin título.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
  <style>
    td { padding: 0 20px;}
    button { font-size: 2rem; }
  </style>
</head>

<body>
  <h1>Juego de dados: Juego del 15</h1>

  <p>Se tiran dos dados, uno por jugador. Cada jugador va acumulando los puntos obtenidos. Cada jugador puede plantarse cuando quiera y dejará de tirar su dado y acumular puntos. Cuando los dos jugadores se plantan, el ganador es el que se encuentra más cerca de los 15 puntos, sin superarlos.</p>

  <form action="cs-juego-dados-15-2.php">
<?php

print "<!-- Ejercicio incompleto -->\n";

?>
    <p>
      <button type="submit" name="accion" value="tirar">Tirar dados</button>
      <button type="submit" name="accion" value="empezar">Volver a empezar</button>
    </p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
