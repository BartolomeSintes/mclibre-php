<?php
/**
 * Mueve ficha - mueve-ficha-1.php
 *

 * @author Escriba aquí su nombre
 */

 print "<!-- Ejercicio incompleto -->\n";
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Sin título.
    Escriba aquí su nombre
    Exámenes. PHP. mclibre.org
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
</head>

<body>
  <h1>Mueve ficha</h1>

  <p>Elija un dado para avanzar la ficha tantas casillas como indique el dado. El objetivo del juego es caer en la casilla de la ficha negra.</p>

  <form action="mueve-ficha-2.php" method="get">    <p class="mcl-svg-figura">
    <p class="mcl-svg-figura">
      <svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="1150" height="120" viewBox="-35 -10 1150 120">
        <rect x="-25" y="0" width="1050" height="100" stroke-width="2" stroke="black" fill="navajowhite" />
        <text x="0" y="90" font-size="25" text-anchor="middle">0</text>
        <line x1="25" y1="0" x2="25" y2="100" stroke-width="2" stroke="black" />
        <line x1="75" y1="0" x2="75" y2="100" stroke-width="2" stroke="black" />
        <line x1="125" y1="0" x2="125" y2="100" stroke-width="2" stroke="black" />
        <line x1="175" y1="0" x2="175" y2="100" stroke-width="2" stroke="black" />
        <line x1="225" y1="0" x2="225" y2="100" stroke-width="2" stroke="black" />
        <text x="250" y="90" font-size="25" text-anchor="middle">5</text>
        <line x1="275" y1="0" x2="275" y2="100" stroke-width="2" stroke="black" />
        <line x1="325" y1="0" x2="325" y2="100" stroke-width="2" stroke="black" />
        <line x1="375" y1="0" x2="375" y2="100" stroke-width="2" stroke="black" />
        <line x1="425" y1="0" x2="425" y2="100" stroke-width="2" stroke="black" />
        <line x1="475" y1="0" x2="475" y2="100" stroke-width="2" stroke="black" />
        <text x="500" y="90" font-size="25" text-anchor="middle">10</text>
        <line x1="525" y1="0" x2="525" y2="100" stroke-width="2" stroke="black" />
        <line x1="575" y1="0" x2="575" y2="100" stroke-width="2" stroke="black" />
        <line x1="625" y1="0" x2="625" y2="100" stroke-width="2" stroke="black" />
        <line x1="675" y1="0" x2="675" y2="100" stroke-width="2" stroke="black" />
        <line x1="725" y1="0" x2="725" y2="100" stroke-width="2" stroke="black" />
        <text x="750" y="90" font-size="25" text-anchor="middle">15</text>
        <line x1="775" y1="0" x2="775" y2="100" stroke-width="2" stroke="black" />
        <line x1="825" y1="0" x2="825" y2="100" stroke-width="2" stroke="black" />
        <line x1="875" y1="0" x2="875" y2="100" stroke-width="2" stroke="black" />
        <line x1="925" y1="0" x2="925" y2="100" stroke-width="2" stroke="black" />
        <line x1="975" y1="0" x2="975" y2="100" stroke-width="2" stroke="black" />
        <text x="1000" y="90" font-size="25" text-anchor="middle">20</text>
<?php

print "<!-- Ejercicio incompleto -->\n";

?>
      </svg>
    </p>

<?php

print "<!-- Ejercicio incompleto -->\n";

?>

    <p>
      <input type="submit" name="accion" value="Reiniciar">
    </p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
