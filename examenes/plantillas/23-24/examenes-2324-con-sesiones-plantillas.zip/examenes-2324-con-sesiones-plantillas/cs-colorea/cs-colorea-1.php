<?php
/**
 * Colorea - cs-colorea-1.php
 *

 * @author Escriba aquí su nombre
 */

 print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Sin título.
    Escriba aquí su nombre
    Exámenes. PHP. www.mclibre.org
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
  <style>
    td { vertical-align: top;}
  </style>
</head>

<body>
  <h1>Colorea</h1>

  <p>Elija un color haciendo clic en uno de los cuadros superiores o coloree un cuadro haciendo clic en uno de los cuadros inferiores:</p>

  <form action="cs-colorea-2.php" method="get">
    <table>
      <tr>
        <td>Elija un color: </td>
        <td>
            <button type="submit" name="accion" value="red" style="height: 40px; width: 40px; background-color: red"></button>
            <button type="submit" name="accion" value="yellow" style="height: 40px; width: 40px; background-color: yellow"></button>
            <button type="submit" name="accion" value="green" style="height: 40px; width: 40px; background-color: green"></button>
            <button type="submit" name="accion" value="blue" style="height: 40px; width: 40px; background-color: blue"></button>
            <button type="submit" name="accion" value="white" style="height: 40px; width: 40px; background-color: white"></button>
        </td>
      </tr>
      <tr>
        <td>Elija un cuadro:</td>
        <td>
<?php

print "<!-- Ejercicio incompleto -->\n";

?>
        </td>
      </tr>
    </table>

    <p><input type="submit" name="accion" value="Reiniciar"></p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
