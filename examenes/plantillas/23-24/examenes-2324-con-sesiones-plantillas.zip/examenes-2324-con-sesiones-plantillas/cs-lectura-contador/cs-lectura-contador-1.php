<?php
/**
 * @author Escriba aquí su nombre
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Sin título.
    Escriba aquí su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
  <style>
    table { font-size: 5rem; margin: 0;}
    td { text-align: center; line-height: 60px;}
    table button { font-size: 2rem; margin: 5px 10px 0; vertical-align: top;}
  </style>
</head>

<body>
  <h1>Lectura de contador</h1>

  <p>Pulse los triángulos para modificar el valor numérico.</p>

  <form action="cs-lectura-contador-2.php">
    <table>
      <tr>
        <td><button name="sube" value="1000">&#9651;</button></td>
        <td><button name="sube" value="100">&#9651;</button></td>
        <td><button name="sube" value="10">&#9651;</button></td>
        <td><button name="sube" value="1">&#9651;</button></td>
      </tr>
<?php

print "<!-- Ejercicio incompleto -->\n";

?>
      <tr>
        <td><button name="baja" value="1000">&#9661;</button></td>
        <td><button name="baja" value="100">&#9661;</button></td>
        <td><button name="baja" value="10">&#9661;</button></td>
        <td><button name="baja" value="1">&#9661;</button></td>
      </tr>
    </table>

<?php

print "<!-- Ejercicio incompleto -->\n";

?>
    <p><input type="submit" name="accion" value="Reiniciar"></p>
  </form>

  <footer>
    <p>Escriba aquí su nombre</p>
  </footer>
</body>
</html>
