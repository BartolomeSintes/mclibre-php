<?php
/**
 * Quita cartas - quita-cartas-2.php
 *
 * @author    Escribe tu nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";
