<?php
/**
 * Suma o resta- suma-resta-2.php
 *
 * @author    Escribe tu nombre
 *
 */

 print "<!-- Ejercicio incompleto -->\n";
