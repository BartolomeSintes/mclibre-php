<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>Pagando (Formulario).
    Escribe tu nombre</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link href="mclibre-php-soluciones.css" rel="stylesheet" type="text/css" title="Color" />
</head>

<body>
  <h1>Pagando (Formulario)</h1>

  <form action="pagando-2.php" method="get">
    <p>Indique la cantidad a pagar y los billetes o monedas que va a utilizar.</p>

    <table>
      <tbody>
        <tr>
          <td><strong>Cantidad a pagar:</strong></td>
          <td><input type="number" name="total" min="0" step="5" value="500" /> euros</td>
        </tr>
        <tr>
          <td><strong>En billetes de:</strong></td>
          <td>
            <select name="b1">
              <option>500</option>
              <option>200</option>
              <option>100</option>
            </select> euros
          </td>
        </tr>
        <tr>
          <td><strong>y billetes:</strong></td>
          <td>
            <select name="b2">
              <option>50</option>
              <option>20</option>
              <option>10</option>
              <option>5</option>
            </select> euros
          </td>
        </tr>
      </tbody>
    </table>

    <p>
      <input type="submit" value="Mostrar" />
      <input type="reset" value="Borrar" />
    </p>
  </form>

  <footer>
    <p>Escribe tu nombre</p>
  </footer>
</body>
</html>
