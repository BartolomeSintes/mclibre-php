<?php
/**
 * Elige cartas - elige-cartas-2.php
 *
 * @author    Escribe tu nombre
 *
 */

 print "<!-- Ejercicio incompleto -->\n";

