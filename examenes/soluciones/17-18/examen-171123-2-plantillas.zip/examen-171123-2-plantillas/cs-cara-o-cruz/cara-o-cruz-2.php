<?php
/**
 * Cara o cruz - cara-o-cruz-2.php
 *
 * @author    Escribe tu nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";
