<?php
/**
 * Cara o cruz - cara-o-cruz-1.php
 *
 * @author    Escriba su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Cara o cruz.
    Escriba su nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="mclibre-php-soluciones.css" rel="stylesheet" type="text/css" title="Color">
</head>

<body>
  <h1>Cara o cruz</h1>

  <p>Haga clic en uno de los botones:</p>

  <form action="cara-o-cruz-2.php">
    <p>
      <input type="submit" name="siguiente" value="Lanzar moneda">
      <input type="submit" name="siguiente" value="Volver a empezar">
    </p>
  </form>

  <table style="text-align: center;">
    <tr>
      <th>Jugador A</th>
      <th>Resultado</th>
      <th>Jugador B</th>
    </tr>
<?php

print "  <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
  </table>

  <footer>
    <p>Escriba su nombre</p>
  </footer>
</body>
</html>