<?php

// print "    <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <title>
      Adivine el número
      Escriba su nombre
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="mclibre_php_soluciones.css" rel="stylesheet" type="text/css" title="Color">
  </head>

  <body>
    <h1>Adivine el número</h1>

<?php

print "    <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>
    <p>Intente adivinar el número que he pensado entre 1 y 100.</p>

    <form action="adivine_numero_2.php" method="get">
      <p>Número: <input type="text" name="numero" size="10"></p>

      <p><input type="submit" value="Comprobar"></p>
    </form>

    <footer>
    <p>Escriba su nombre</p>
  </footer>
</body>
</html>