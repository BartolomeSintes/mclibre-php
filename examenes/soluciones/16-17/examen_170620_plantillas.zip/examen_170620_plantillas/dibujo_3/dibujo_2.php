<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <title>
      Dibujo (Resultado).
      Escriba su nombre
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="mclibre_php_soluciones.css" rel="stylesheet" type="text/css" title="Color">
  </head>

  <body>
    <h1>Dibujo (Resultado)</h1>

<?php

print "    <p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

    <p><a href="dibujo_1.php">Volver al formulario.</a></p>

    <footer>
      <p>Escriba su nombre</p>
    </footer>
  </body>
</html>
