<?php
$textos = array(
    1 => array("Formulario", "Form"),
    2 => array("Escriba una palabra", "Write a word"),
    3 => array("Comprobar", "Check"),
    4 => array("Borrar", "Delete"),
    5 => array("Ha escrito", "You have written")
);    

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

<footer>
  <p class="ultmod">
    Última modificación de esta página: 
    <time datetime="2015-11-05">5 de noviembre de 2015</time></p>
</footer>
</body>
</html>