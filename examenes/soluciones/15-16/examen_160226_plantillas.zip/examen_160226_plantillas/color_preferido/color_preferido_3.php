<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>Color preferido (Resultado).
    Exámenes. Programación web en PHP. Bartolomé Sintes Marco</title>
  <link href="mclibre_php_soluciones.css" rel="stylesheet" type="text/css" title="Color" />
</head>

<body>
<h1>Color preferido (Resultado)</h1>

<?php

print "<p class=\"aviso\">Ejercicio incompleto</p>\n";

?>

<p><a href="color_preferido_1.html">Volver al formulario inicial.</a></p>

<footer>
  <p class="ultmod">
    Última modificación de esta página:
    <time datetime="2016-02-25">25 de febrero de de 2016</time></p>

  <p class="licencia">
    Este programa forma parte del curso <a href="http://www.mclibre.org/consultar/php/">
    <cite>Programación web en PHP</cite></a> por <cite>Bartolomé Sintes Marco</cite>.<br />
    El programa PHP que genera esta página está bajo
    <a rel="license" href="http://www.gnu.org/licenses/agpl.txt">licencia AGPL 3 o posterior</a></p>
</footer>
</body>
</html>