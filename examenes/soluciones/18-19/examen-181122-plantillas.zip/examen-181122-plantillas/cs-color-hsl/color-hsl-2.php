<?php
/**
 * Colores HSL- color-hsl-2.php
 *
 * @author    Escriba su nombre
 *
 */

print "<!-- Ejercicio incompleto -->\n";

?>
